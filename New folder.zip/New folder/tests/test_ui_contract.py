"""Deterministic UI behavior checks against the shipped JavaScript, without network."""
import json
import re
import shutil
import subprocess
import unittest
from html.parser import HTMLParser
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
NODE = shutil.which("node")

DOM = r"""
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
function element(tag = 'div') {
  const classes = new Set();
  const node = {
    tagName: tag.toUpperCase(), innerText: '', textContent: '', value: '', style: {}, dataset: {},
    children: [], attributes: {}, listeners: {}, listenerLists: {}, disabled: false,
    classList: {
      add(...names) { names.forEach(name => classes.add(name)); },
      remove(...names) { names.forEach(name => classes.delete(name)); },
      contains(name) { return classes.has(name); },
      toggle(name, force) { if (force) classes.add(name); else classes.delete(name); }
    },
    addEventListener(name, callback) {
      if (!this.listenerLists[name]) this.listenerLists[name] = [];
      this.listenerLists[name].push(callback);
      this.listeners[name] = event => this.listenerLists[name].forEach(listener => listener(event));
    },
    appendChild(child) { this.children.push(child); },
    replaceChildren() { this.children = []; },
    setAttribute(name, value) { this.attributes[name] = String(value); },
    focus() { this.focused = true; if (this.ownerDocument) this.ownerDocument.activeElement = this; },
    getClientRects() { return this.style.display === 'none' ? [] : [{}]; },
    contains(other) { return other === this || this.children.includes(other) || (other && other.parentElement ? this.contains(other.parentElement) : false); },
    closest(selector) {
      if (selector === 'a' && this.tagName === 'A') return this;
      if (selector === '[inert]') return this.inert ? this : this.parentElement ? this.parentElement.closest(selector) : null;
      return null;
    },
    querySelectorAll(selector) {
      if (selector === 'article[data-id]') return (this.nodes || []).filter(child => child.tagName === 'ARTICLE' && 'id' in child.dataset);
      if (selector === '[data-event-index]') return (this.nodes || []).filter(child => 'eventIndex' in child.dataset);
      return [];
    },
    removeAttribute(name) { delete this[name]; delete this.attributes[name]; }
  };
  Object.defineProperty(node, 'innerHTML', {
    get() { return this.html || ''; },
    set(html) {
      this.html = html;
      this.children = [];
      this.nodes = Array.from(html.matchAll(/<([a-z][a-z0-9]*)\b([^>]*)>/gi), match => {
        const child = element(match[1]);
        for (const attribute of match[2].matchAll(/\b(data-id|data-event-index)="([^"]*)"/g)) {
          const key = attribute[1] === 'data-id' ? 'id' : 'eventIndex';
          child.dataset[key] = attribute[2].replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
        }
        return child;
      });
    }
  });
  return node;
}
function environment() {
  const elements = new Map(), callbacks = [], intervals = [], pins = [];
  const windowEvents = new Map(), documentEvents = new Map();
  const document = {
    readyState: 'loading', body: element(), head: element('head'), documentElement: {dataset: {enableGeo: 'false'}},
    getElementById(id) { if (!elements.has(id)) { const node = element(); node.id = id; node.ownerDocument = document; elements.set(id, node); } return elements.get(id); },
    createElement(tag) { const node = element(tag); node.ownerDocument = document; return node; },
    querySelectorAll(selector) { return selector === '[data-hotspot-count]' ? pins : []; },
    addEventListener(name, callback) { if (name === 'DOMContentLoaded') callbacks.push(callback); if (!documentEvents.has(name)) documentEvents.set(name, []); documentEvents.get(name).push(callback); }
  };
  const context = {
    document, URL, console: { error() {}, warn() {}, log() {} },
    setTimeout() {}, clearInterval() {},
    setInterval(callback) { intervals.push(callback); return intervals.length; },
    requestAnimationFrame(callback) { callback(); },
    addEventListener(name, callback) { if (!windowEvents.has(name)) windowEvents.set(name, []); windowEvents.get(name).push(callback); }
  };
  context.window = context;
  vm.createContext(context);
  return {context, elements, callbacks, intervals, pins, windowEvents, documentEvents, get: id => document.getElementById(id)};
}
"""


@unittest.skipUnless(NODE, "Node.js is required for UI runtime checks")
class TestUIContract(unittest.TestCase):
    def run_js(self, script):
        result = subprocess.run(
            [NODE, "-e", DOM + "\n" + script], cwd=ROOT,
            text=True, encoding="utf-8", capture_output=True, timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return result.stdout

    def test_war_xlsx_rows_reach_all_default_engines_and_a_real_timeline_lane(self):
        self.run_js(r"""
const env = environment();
env.context.self = env.context;
vm.runInContext(fs.readFileSync('static/vendor/sheetjs/xlsx.mini.min.js', 'utf8'), env.context);
vm.runInContext(fs.readFileSync('static/js/xlsx-worker.js', 'utf8'), env.context);
const categories = ['ธุรกิจ', 'เศรษฐกิจ', 'การเงิน', 'การเมือง', 'คริปโต', 'สงคราม'];
const rows = [['Date', 'Category', 'Description', 'Provider', 'Source Link', 'Published At'],
  ...categories.map((category, index) => ['2026-11-01', category, 'headline ' + category, 'Al Jazeera', 'https://www.aljazeera.com/news/example-' + index, `2026-11-01 ${String(index + 1).padStart(2, '0')}:00:00`]),
  ['2026-11-01', 'สงคราม', 'Oilprice war headline', 'Oilprice', 'https://oilprice.com/Energy/example.html', '2026-11-01 07:00:00']];
const XLSX = env.context.XLSX, book = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(book, XLSX.utils.aoa_to_sheet(rows), 'Factnews');
const parsed = env.context.parseFactnews(XLSX.write(book, {bookType: 'xlsx', type: 'array'}));
assert.equal(parsed.events.length, 7);
assert.equal(parsed.category_counts['สงคราม'], 2);
assert.equal(parsed.geo_scenarios.length, 0);
assert.equal(parsed.events.find(event => event.provider === 'Oilprice').source_url, 'https://oilprice.com/Energy/example.html');
for (const file of ['feed', 'timeline', 'minimap']) vm.runInContext(fs.readFileSync(`static/js/${file}.js`, 'utf8'), env.context);
const ctx = new Proxy({measureText: text => ({width: String(text).length * 6}), createLinearGradient: () => ({addColorStop() {}})}, {get(target, key) { return key in target ? target[key] : () => {}; }});
for (const id of ['warTimeline', 'warMinimap']) {
  const canvas = env.get(id); canvas.getContext = () => ctx; canvas.clientWidth = 1000; canvas.clientHeight = 450;
}
vm.runInContext('TimelineEngine.prototype.bindEvents = function() {}; MinimapEngine.prototype.bindEvents = function() {};', env.context);
const timeline = vm.runInContext("new TimelineEngine('warTimeline', 'warTimelineContainer', 'warTooltip')", env.context);
const minimap = vm.runInContext("new MinimapEngine('warMinimap', 'warMiniContainer', 'warViewport', 'warLeft', 'warRight')", env.context);
const feed = vm.runInContext("new FeedEngine('warFeed', 'warCounter')", env.context);
const start = parsed.min_timestamp - 3600000, end = parsed.max_timestamp + 3600000;
timeline.setData(parsed.events, start, end);
minimap.setData(parsed.events, start, end);
feed.setEvents(parsed.events); feed.setFilters(feed.activeCategories, '', start, end);
assert.deepEqual(Array.from(timeline.categoryNames), categories);
for (const engine of [timeline, minimap, feed]) assert.deepEqual(Array.from(engine.activeCategories), categories);
assert.equal(timeline.getFilteredEvents().length, 7);
assert.equal(minimap.getFilteredEvents().length, 7);
assert.equal(env.get('warCounter').innerText, '7 ข่าว');
assert.equal(timeline._renderedNodes.filter(node => node.category === 'สงคราม').length, 2, 'War must be drawn in its own lane');
for (const engine of [timeline, minimap]) {
  engine.setFilters(['สงคราม'], '');
  assert.equal(engine.getFilteredEvents().length, 2);
  engine.setFilters(categories, '');
  assert.equal(engine.getFilteredEvents().length, 7);
}
feed.setFilters(['สงคราม'], '', start, end);
assert.equal(env.get('warCounter').innerText, '2 ข่าว');
assert.equal(env.get('warFeed').querySelectorAll('article[data-id]').length, 2);
assert.match(env.get('warFeed').innerHTML, /⚔️/);
assert.match(env.get('warFeed').innerHTML, /#FDBA74/);
feed.setFilters(categories, '', start, end);
assert.equal(env.get('warCounter').innerText, '7 ข่าว');
""")

    def test_war_dropdown_chips_modal_and_reset_preserve_old_categories_with_geo_off(self):
        self.run_js(r"""
(async () => {
  const env = environment(), engines = [];
  const categories = ['ธุรกิจ', 'เศรษฐกิจ', 'การเงิน', 'การเมือง', 'คริปโต', 'สงคราม'];
  const stamp = Date.parse('2026-11-01T12:00:00+07:00');
  const events = [...categories, 'สงคราม'].map((category, index) => ({id: 'news-' + index, timestamp: stamp + index * 1000,
    title: 'headline ' + category, category, provider: index === 6 ? 'Oilprice' : 'Al Jazeera', source_url: index === 6 ? 'https://oilprice.com/Energy/example.html' : 'https://www.aljazeera.com/news/example'}));
  // Keep this category fixture inside the clock-based initial 24-hour window.
  env.context.Date = class extends Date { static now() { return stamp + 3600000; } };
  class Engine {
    constructor(id) { this.id = id; engines.push(this); }
    setData(events) { this.events = events; } setWindow() {} render() {} setSelectedEvent() {}
    setFilters(categories) { this.activeCategories = new Set(categories); }
  }
  Object.assign(env.context, {TimelineEngine: Engine, MinimapEngine: Engine});
  env.context.fetch = async url => ({ok: true, json: async () => url === '/api/events' ? {
    events, min_timestamp: stamp - 3600000, max_timestamp: stamp + 3600000,
    freshness: {status: 'fresh', source_mode: 'live'}, geo_scenarios: []
  } : {candles: [], freshness: {status: 'fresh'}}});
  vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
  vm.runInContext(fs.readFileSync('static/js/app.js', 'utf8'), env.context);
  await env.callbacks[0]();
  const chips = () => env.get('categoryChipsContainer').children;
  assert.equal(chips().length, 6);
  assert.match(chips()[5].innerHTML, /⚔️.*สงคราม.*>2</);
  assert.equal(env.get('feedCounterBadge').innerText, '7 ข่าว');
  assert.equal(engines[0].events.length, 7);
  assert.equal(engines[1].events.length, 7);
  const dropdown = env.get('categorySelect');
  dropdown.value = 'สงคราม'; dropdown.listeners.change({target: dropdown});
  for (const engine of engines) assert.deepEqual(Array.from(engine.activeCategories), ['สงคราม']);
  assert.equal(env.get('feedCounterBadge').innerText, '2 ข่าว');
  env.context.openDetailModal(events[6]);
  assert.equal(env.get('modalCategoryBadge').textContent, '⚔️ สงคราม');
  assert.equal(env.get('modalCategoryBadge').style.color, '#FDBA74');
  assert.equal(env.get('modalProviderText').innerText, 'Oilprice');
  assert.equal(env.get('modalDirectSourceBtn').href, 'https://oilprice.com/Energy/example.html');
  env.context.closeDetailModal();
  chips()[5].onclick(); // Clicking the sole selected category restores every category.
  for (const engine of engines) assert.deepEqual(Array.from(engine.activeCategories), categories);
  assert.equal(dropdown.value, 'all');
  assert.equal(env.get('feedCounterBadge').innerText, '7 ข่าว');
  dropdown.value = 'การเมือง'; dropdown.listeners.change({target: dropdown});
  assert.equal(env.get('feedCounterBadge').innerText, '1 ข่าว');
  env.context.resetFilters();
  for (const engine of engines) assert.deepEqual(Array.from(engine.activeCategories), categories);
  assert.equal(env.get('feedCounterBadge').innerText, '7 ข่าว');
  env.context.toggleOnlyCategory('สงคราม');
  assert.equal(env.get('feedCounterBadge').innerText, '2 ข่าว');
  dropdown.value = 'all'; dropdown.listeners.change({target: dropdown});
  assert.equal(env.get('feedCounterBadge').innerText, '7 ข่าว');
  assert.equal(env.get('tabWorldMapBtn').hidden, true);
  assert.equal(env.get('worldMapTabContent').inert, true);
  assert.equal(env.context.document.head.children.length, 0);
})().catch(error => { console.error(error); process.exitCode = 1; });
""")

    def test_war_category_markup_and_semantic_theme_are_consistent(self):
        html = (ROOT / 'static/index.html').read_text(encoding='utf-8')
        self.assertIn('<option value="สงคราม">⚔️ เฉพาะหมวด: สงคราม</option>', html)
        self.assertIn('6 หมวดหมู่ + Benchmark BTC', html)
        self.assertNotIn('5 หมวดหมู่ + Benchmark BTC', html)
        definition = "'สงคราม': { color: '#FDBA74', tint: 'rgba(253, 186, 116, 0.12)', border: 'rgba(253, 186, 116, 0.3)', icon: '⚔️' }"
        for name in ('app', 'timeline', 'feed'):
            self.assertIn(definition, (ROOT / f'static/js/{name}.js').read_text(encoding='utf-8'))

    def test_worldmap_dates_window_counts_markers_and_empty_filters(self):
        self.run_js(r"""
const env = environment();
vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
const markerIcons = [];
env.context.L = {
  divIcon(options) { markerIcons.push(options.html); return options; },
  marker() { return { on() {}, bindTooltip() {} }; }
};
vm.runInContext(fs.readFileSync('static/js/worldmap.js', 'utf8'), env.context);
const map = env.context.worldMapEngine;
map.markersLayer = { clearLayers() { markerIcons.length = 0; }, addLayer() {} };
map.renderHotspots();
assert.ok(markerIcons.every(icon => />\s*—\s*</.test(icon)));
const pin = element(); pin.dataset.hotspotCount = 'hormuz'; env.pins.push(pin);
const event = (id, time, title) => ({id, timestamp: Date.parse(time), title, category: 'การเมือง', source_url: 'https://example.test/' + id});
const old = event('OLD', '2026-10-01T00:00:00+07:00', 'อิหร่าน OLD');
const before = event('BEFORE', '2026-10-11T23:59:59+07:00', 'อิหร่าน BEFORE');
const border = event('BORDER', '2026-10-11T17:00:00Z', 'อิหร่าน BORDER');
const last = {...event('LAST', '2026-11-01T23:59:59+07:00', 'ยูเครน LAST'), category: 'สงคราม'};
map.setData([old, before, border, last, {timestamp: 0}, {timestamp: 'bad'}]);
assert.deepEqual(Array.from(map.availableDates), ['2026-10-01', '2026-10-11', '2026-10-12', '2026-11-01']);
assert.equal(env.get('worldMapDateSelect').children.length, 4);
assert.equal(env.get('worldMapDateSelect').value, '2026-11-01');
assert.equal(env.get('rolling21DateRangeLabel').innerText, '2026-10-12 ถึง 2026-11-01');
assert.equal(env.get('rolling21CountBadge').innerText, '2 ข่าว');
assert.equal(env.get('geoFeedCountBadge').innerText, '2 ข่าว');
assert.equal(env.get('mapVisibleCountBadge').innerText, '2 / 2');
assert.equal(env.get('mapWarSignalsBadge').innerText, '50%');
assert.equal(map.hotspots[0].count, 1);
assert.equal(pin.textContent, 1);
assert.match(markerIcons[0], />\s*1\s*</);
assert.match(env.get('geoFeedList').innerHTML, /BORDER/);
assert.doesNotMatch(env.get('geoFeedList').innerHTML, /OLD|BEFORE/);
assert.match(env.get('relatedSignalsList').innerHTML, /BORDER/);
assert.doesNotMatch(env.get('relatedSignalsList').innerHTML, /BEFORE|OLD|LAST/);
assert.equal(env.get('scenarioOpenSourceBtn').href, 'https://example.test/BORDER');
map.onDateSelectChange('1900-01-01');
assert.equal(map.selectedAnchorDate, '2026-10-01');
map.stepDate(-1);
assert.equal(map.selectedAnchorDate, '2026-10-01');
assert.equal(env.get('worldMapPreviousDate').disabled, true);
map.stepDate(1);
assert.equal(map.selectedAnchorDate, '2026-10-11');
map.onDateSelectChange('2026-10-15');
assert.equal(map.selectedAnchorDate, '2026-10-12');
const newer = event('NEW', '2026-11-02T12:00:00+07:00', 'อิหร่าน NEW');
map.setData([old, before, border, last, newer]);
assert.equal(map.selectedAnchorDate, '2026-10-12');
map.resetToLatestDate();
assert.equal(map.selectedAnchorDate, '2026-11-02');
map.stepDate(1);
assert.equal(map.selectedAnchorDate, '2026-11-02');
map.initFallbackMap();
assert.match(env.get('leafletMap').innerHTML, /data-hotspot-count="hormuz"[^>]*>1<\/div>/);
map.setCategory('crypto');
assert.equal(env.get('geoFeedCountBadge').innerText, '0 ข่าว');
assert.doesNotMatch(env.get('geoFeedList').innerHTML, /OLD|BORDER|LAST|NEW/);
assert.equal(map.hotspots[0].count, 0);
assert.equal(pin.textContent, 0);
assert.equal(env.get('scenarioOpenSourceBtn').style.display, 'none');
assert.equal(env.get('relatedSignalsCount').innerText, '0 ข่าว');
map.setData([]);
assert.equal(env.get('worldMapDateSelect').disabled, true);
assert.equal(env.get('rolling21CountBadge').innerText, '0 ข่าว');
assert.equal(env.get('mapVisibleCountBadge').innerText, '0 / 0');
assert.equal(env.get('mapHotspotsCountBadge').innerText, '0 โซน');
assert.equal(env.get('worldMapNextDate').disabled, true);
""")

    def test_api_freshness_and_periodic_get_only_and_manual_failures(self):
        self.run_js(r"""
(async () => {
  const env = environment(), requests = [];
  let filterCalls = 0;
  class Engine {
    setData() {} setEvents() {} setFilters() { filterCalls++; } setWindow() {} render() {}
  }
  Object.assign(env.context, { TimelineEngine: Engine, MinimapEngine: Engine, FeedEngine: Engine, WorldMapEngine: Engine });
  const stamp = Date.parse('2026-11-01T12:00:00+07:00');
  let news = {status: 'fresh', source_mode: 'live', stale: false, checked_at: '2026-11-01T05:00:00Z', last_live_success_at: '2026-11-01T05:00:00Z'};
  let prices = {status: 'fresh', source: 'cache', stale: false, last_candle_time: stamp};
  let syncFailure = null, eventsFailure = false, pricesFailure = false;
  env.context.fetch = async (url, options = {}) => {
    requests.push({url, method: options.method || 'GET'});
    if (url === '/api/sync') {
      if (syncFailure === 'network') throw Error('offline');
      return {ok: !syncFailure, status: 503};
    }
    if (url === '/api/events') return {
      ok: !eventsFailure, json: async () => ({events: [{timestamp: stamp, title: 'test', category: 'การเมือง'}], min_timestamp: stamp - 3600000, max_timestamp: stamp, freshness: news})
    };
    if (url.startsWith('/api/prices?')) return {ok: !pricesFailure, json: async () => ({candles: [], freshness: prices})};
    throw Error('Unexpected request: ' + url);
  };
  vm.runInContext(fs.readFileSync('static/js/app.js', 'utf8'), env.context);
  await env.callbacks[0]();
  assert.equal(env.get('realtimeLabel').innerText, 'Realtime');
  assert.equal(env.get('realtimeIndicator').dataset.state, 'fresh');
  assert.equal(env.get('realtimeDot').classList.contains('animate-pulse'), true);
  assert.match(env.get('lastModifiedBadge').innerText, /ข่าว: สด.*ราคา: สด/);
  assert.equal(requests.filter(request => request.method === 'POST').length, 0);
  async function refresh() { for (let second = 0; second < 60; second++) await env.intervals[0](); }
  news = {...news, status: 'degraded', cache_write_error: 'disk'};
  await refresh();
  assert.match(env.get('freshnessStatus').textContent, /ทำงานได้บางส่วน/);
  assert.notEqual(env.get('realtimeLabel').innerText, 'Realtime');
  news = {...news, status: 'stale', stale: true, source_mode: 'cache_fallback'};
  prices = {...prices, status: 'stale', stale: true, source: 'cache_fallback'};
  await refresh();
  assert.match(env.get('freshnessStatus').textContent, /ข่าว: แคชสำรอง.*ราคา: แคชสำรอง/);
  assert.equal(env.get('realtimeDot').classList.contains('animate-pulse'), false);
  prices = {status: 'unavailable', source: 'none', stale: true, last_candle_time: null};
  await refresh();
  assert.match(env.get('freshnessStatus').textContent, /ราคา: ไม่มีข้อมูล \(ไม่ทราบเวลา\)/);
  assert.equal(requests.filter(request => request.method === 'POST').length, 0);
  syncFailure = 'http';
  await env.context.triggerManualSync();
  assert.match(env.get('syncToastText').innerText, /ซิงค์ข้อมูลไม่สำเร็จ/);
  assert.equal(env.get('syncToast').classList.contains('opacity-100'), true);
  assert.equal(env.get('refreshBtn').classList.contains('animate-spin'), false);
  syncFailure = 'network';
  await env.context.triggerManualSync();
  assert.match(env.get('syncToastText').innerText, /ซิงค์ข้อมูลไม่สำเร็จ/);
  syncFailure = null;
  await env.context.triggerManualSync();
  assert.match(env.get('syncToastText').innerText, /แคชสำรอง/);
  assert.equal(requests.filter(request => request.method === 'POST').length, 3);
  news = {status: 'fresh', source_mode: 'live', last_live_success_at: '2026-11-01T05:00:00Z'};
  prices = {status: 'fresh', source: 'binance', last_candle_time: stamp};
  await env.context.triggerManualSync();
  assert.match(env.get('syncToastText').innerText, /อัปเดตข้อมูลล่าสุดเรียบร้อย/);
  assert.equal(env.get('realtimeLabel').innerText, 'Realtime');
  pricesFailure = true;
  await refresh();
  assert.match(env.get('freshnessStatus').textContent, /ราคา: เชื่อมต่อไม่สำเร็จ/);
  eventsFailure = true;
  await refresh();
  assert.match(env.get('freshnessStatus').textContent, /ข่าว: เชื่อมต่อไม่สำเร็จ/);
  assert.notEqual(env.get('realtimeLabel').innerText, 'Realtime');
  const category = env.get('categorySelect');
  assert.equal(category.listenerLists.change.length, 1, 'Periodic and manual refresh must not accumulate category handlers');
  filterCalls = 0;
  category.value = 'การเมือง';
  category.listeners.change({target: category});
  assert.equal(filterCalls, 3, 'One category change updates each of the three engines exactly once');
})().catch(error => { console.error(error); process.exitCode = 1; });
""")

    def test_cloudflare_adapter_integration_preserves_refresh_manual_sync_and_fallback(self):
        self.run_js(r"""
(async () => {
  const env = environment();
  class Engine { setData() {} setEvents() {} setFilters() {} setWindow() {} render() {} }
  Object.assign(env.context, {TimelineEngine: Engine, MinimapEngine: Engine, FeedEngine: Engine, WorldMapEngine: Engine});
  let eventCalls = 0, priceCalls = 0, syncCalls = 0, stale = false;
  const stamp = Date.parse('2026-11-01T12:00:00+07:00');
  env.context.WriteTimeData = {
    async events(payload) {
      assert.equal(payload.client_mode, 'browser-xlsx-v1'); eventCalls++;
      return {events:[{id:'one',title:'Factnews',category:'การเมือง',timestamp:stamp}],min_timestamp:stamp-3600000,max_timestamp:stamp,
        freshness:{status:stale?'stale':'fresh',source_mode:stale?'cache_fallback':'live',stale,last_live_success_at:'2026-11-01T05:00:00Z'}};
    },
    async prices(payload, query) {
      assert.equal(payload.client_mode,'browser-xlsx-v1'); assert.equal(query.symbol,'BTCUSDT'); priceCalls++;
      return {candles:[],freshness:{status:'fresh',source:'binance',last_candle_time:stamp}};
    }
  };
  env.context.fetch = async url => {
    if (url==='/api/sync') syncCalls++;
    return {ok:true,json:async()=>({client_mode:'browser-xlsx-v1',refetch:true})};
  };
  vm.runInContext(fs.readFileSync('static/js/app.js','utf8'),env.context);
  await env.callbacks[0]();
  assert.equal(eventCalls,1); assert.equal(priceCalls,1); assert.equal(env.get('totalCountBadge').innerText,1);
  await env.context.triggerManualSync();
  assert.equal(syncCalls,1); assert.equal(eventCalls,2);
  stale=true;
  for(let second=0;second<60;second++) await env.intervals[0]();
  assert.equal(eventCalls,3); assert.equal(priceCalls,3); assert.equal(syncCalls,1);
  assert.match(env.get('freshnessStatus').textContent,/แคชสำรอง/);
})().catch(error=>{console.error(error);process.exitCode=1;});
""")

    def test_status_regions_are_accessible(self):
        class Elements(HTMLParser):
            def __init__(self):
                super().__init__()
                self.by_id = {}

            def handle_starttag(self, tag, attrs):
                attrs = dict(attrs)
                if "id" in attrs:
                    self.by_id[attrs["id"]] = attrs

        parser = Elements()
        parser.feed((ROOT / "static/index.html").read_text(encoding="utf-8"))
        for element_id in ("freshnessStatus", "syncToast"):
            self.assertEqual(parser.by_id[element_id]["role"], "status")
            self.assertEqual(parser.by_id[element_id]["aria-live"], "polite")
        self.assertTrue(parser.by_id["worldMapDateSelect"]["aria-label"])

    def test_hostile_sheet_text_scenario_markup_and_urls_are_inert(self):
        output = self.run_js(r"""
const env = environment();
vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
const hostile = '<script>alert(`x`)</script><img src=x onerror="alert(1)">\'"` &';
const urls = ['javascript:alert(1)', 'data:text/html,<script>alert(1)</script>', 'java\nscript:alert(1)', 'https://example.test/?q=" onclick="alert(1)&x=1', 'HTTPS://example.test/safe'];
const events = urls.map((url, index) => ({
  id: 'evt-' + index + hostile, timestamp: Date.parse('2026-11-01T12:00:00+07:00'),
  title: 'อิหร่าน ' + hostile, summary: hostile, details: hostile,
  category: hostile, provider: hostile, source_name: hostile, source_url: url, display_time: hostile
}));
env.context.events = events;
const feed = vm.runInContext('new FeedEngine("testFeed", "testCounter", () => {})', env.context);
feed.setEvents(events);
feed.setFilters([hostile], 'img', 1, Number.MAX_SAFE_INTEGER);
const feedHtml = env.get('testFeed').innerHTML;
assert.match(feedHtml, /<mark\b/);
assert.doesNotMatch(feedHtml, /<script|<img|\sonclick\s*=\s*["']/i);
feed.setFilters([hostile], '<iframe onload="alert(1)">', 1, Number.MAX_SAFE_INTEGER);
const emptyHtml = env.get('testFeed').innerHTML;
vm.runInContext(fs.readFileSync('static/js/worldmap.js', 'utf8'), env.context);
const map = env.context.worldMapEngine;
let tooltips = [];
env.context.L = {
  divIcon(options) { return options; },
  marker() { return {on() {}, bindTooltip(html) { tooltips.push(html); }}; }
};
map.markersLayer = {clearLayers() { tooltips = []; }, addLayer() {}};
map.setData(events, [{id: 'hormuz', name: hostile, region: hostile, tension_level: hostile,
  event_a: hostile, energy_impact: hostile, inflation_impact: hostile, equities_impact: hostile,
  safe_haven_impact: hostile, action_portfolio: hostile, action_hedge: hostile,
  action_supply_chain: hostile, action_crypto: hostile, event_b: hostile, deescalation_impact: hostile}]);
const scenarioA = env.get('scenarioMatrixBody').innerHTML;
const related = env.get('relatedSignalsList').innerHTML;
const geo = env.get('geoFeedList').innerHTML;
assert.equal(env.get('scenarioOpenSourceBtn').href, undefined);
map.setScenarioMode('deescalation');
const scenarioB = env.get('scenarioMatrixBody').innerHTML;
const cards = env.get('relatedSignalsList').querySelectorAll('[data-event-index]');
let opened = null;
env.context.openDetailModal = event => { opened = event; };
env.context.getSelection = () => ({isCollapsed: false, anchorNode: cards[0], focusNode: cards[0]});
cards[0].listeners.click({target: cards[0]});
assert.equal(opened, null);
env.context.getSelection = () => ({isCollapsed: true});
cards[0].listeners.click({target: cards[0]});
assert.equal(opened, events[0]);
opened = null;
env.context.getSelection = () => ({isCollapsed: false, anchorNode: cards[0], focusNode: cards[0]});
cards[0].listeners.keydown({target: cards[0], key: 'Enter', preventDefault() {}});
assert.equal(opened, events[0]);
const fragments = [feedHtml, emptyHtml, related, geo, scenarioA, scenarioB, env.get('scenarioSignalTags').innerHTML, ...tooltips];
for (const html of fragments) assert.doesNotMatch(html, /<script|<img|<iframe|\sonclick\s*=\s*["']/i);
assert.equal(env.context.safeNewsUrl('javascript:alert(1)'), '');
assert.equal(env.context.safeNewsUrl('data:text/html,evil'), '');
assert.equal(env.context.safeNewsUrl('//example.test'), '');
assert.equal(env.context.safeNewsUrl('https://example.test'), 'https://example.test/');
console.log(JSON.stringify(fragments));
""")

        class SafeMarkup(HTMLParser):
            def handle_starttag(parser, tag, attrs):
                self.assertNotIn(tag, {"script", "img", "iframe", "svg", "object"})
                for name, value in attrs:
                    self.assertFalse(name.lower().startswith("on"), (name, value))
                    if name == "href":
                        self.assertTrue(value.startswith(("https://", "http://")), value)

        for fragment in json.loads(output):
            parser = SafeMarkup()
            parser.feed(fragment)
            parser.close()

    def test_feed_582_results_are_batched_reachable_and_keyboard_selectable(self):
        self.run_js(r"""
const env = environment();
vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
const feed = vm.runInContext('new FeedEngine("largeFeed", "largeCounter", event => { window.selected = event; })', env.context);
const events = Array.from({length: 582}, (_, index) => ({
  id: 'evt-' + index, timestamp: index + 1, title: 'headline ' + index,
  summary: 'common needle', category: index % 2 ? 'การเมือง' : 'เศรษฐกิจ', provider: 'source'
}));
feed.setEvents(events);
const categories = ['การเมือง', 'เศรษฐกิจ'];
feed.setFilters(categories, '', 1, 582);
const list = env.get('largeFeed');
const count = () => list.querySelectorAll('article[data-id]').length;
assert.equal(env.get('largeCounter').innerText, '582 ข่าว');
assert.equal(count(), 40);
let more = list.children.find(child => child.tagName === 'BUTTON');
assert.equal(more.type, 'button');
assert.equal(more.attributes['aria-controls'], 'largeFeed');
more.listeners.click();
assert.equal(count(), 80);
assert.equal(list.querySelectorAll('article[data-id]')[40].focused, true);
let clicks = 1;
while ((more = list.children.find(child => child.tagName === 'BUTTON'))) {
  more.listeners.click();
  assert.ok(++clicks <= 15, 'All remaining results must be reachable');
}
assert.equal(count(), 582);
const card = list.querySelectorAll('article[data-id]')[0];
env.context.getSelection = () => ({isCollapsed: false, anchorNode: card, focusNode: card});
card.listeners.click({target: card});
assert.equal(env.context.selected, undefined, 'Completing a text selection must not open the modal');
env.context.getSelection = () => ({isCollapsed: true});
card.listeners.click({target: card});
assert.equal(env.context.selected.id, 'evt-581', 'An ordinary click still opens the card');
env.context.selected = null;
env.context.getSelection = () => ({isCollapsed: false, anchorNode: card, focusNode: card});
card.listeners.keydown({target: card, key: ' ', preventDefault() {}});
assert.equal(env.context.selected.id, 'evt-581');
assert.equal(card.classList.contains('active-selected'), true);
feed.setFilters(categories, 'needle', 1, 582);
assert.equal(count(), 40);
assert.equal(env.get('largeCounter').innerText, '582 ข่าว');
feed.setFilters(['การเมือง'], '', 1, 582);
assert.equal(count(), 40);
assert.equal(env.get('largeCounter').innerText, '291 ข่าว');
feed.setFilters(categories, '', 1, 10);
assert.equal(count(), 10);
assert.equal(env.get('largeCounter').innerText, '10 ข่าว');
""")

    def test_modal_preserves_hostile_text_and_rejects_unsafe_source_urls(self):
        self.run_js(r"""
(async () => {
  const env = environment();
  class Engine { setData() {} setEvents() {} setFilters() {} setWindow() {} render() {} setSelectedEvent() {} }
  Object.assign(env.context, {TimelineEngine: Engine, MinimapEngine: Engine, WorldMapEngine: Engine});
  env.context.fetch = async url => ({ok: true, json: async () => url === '/api/events'
    ? {events: [], min_timestamp: 1, max_timestamp: 2} : {candles: []}});
  vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
  vm.runInContext(fs.readFileSync('static/js/app.js', 'utf8'), env.context);
  await env.callbacks[0]();
  const hostile = '<script>alert(`x`)</script><img src=x onerror="alert(1)">\'"`';
  const event = {id: 'evil', timestamp: 1, title: hostile, summary: hostile,
    details: hostile + '\nnext line\n\nsecond paragraph', category: hostile, provider: hostile, source_url: 'javascript:alert(1)'};
  env.context.openDetailModal(event);
  assert.equal(env.get('modalTitle').innerText, hostile);
  assert.equal(env.get('modalCategoryBadge').textContent, '🏢 ' + hostile);
  assert.equal(env.get('modalProviderText').innerText, hostile);
  assert.equal(env.get('modalDetails').children.length, 2);
  assert.equal(env.get('modalDetails').children[0].textContent, hostile + '\nnext line');
  assert.equal(env.get('modalDetails').innerHTML, '');
  for (const id of ['modalProviderLink', 'modalSourceLink', 'modalDirectSourceBtn']) assert.equal(env.get(id).href, undefined);
  env.context.openDetailModal({...event, source_url: 'https://example.test/?q=" onerror="alert(1)'});
  for (const id of ['modalProviderLink', 'modalSourceLink', 'modalDirectSourceBtn']) assert.match(env.get(id).href, /^https:\/\//);
  assert.equal(env.get('modalDirectSourceBtn').textContent, '🌐 เปิดอ่านเว็บข่าวจริง (' + hostile + ') ↗');
  env.context.openDetailModal({...event, source_url: 'data:text/html,<script>alert(1)</script>'});
  assert.equal(env.get('modalDirectSourceBtn').href, undefined);
})().catch(error => { console.error(error); process.exitCode = 1; });
""")

    def test_timeline_single_and_cluster_tooltips_escape_payloads_and_keep_clicks(self):
        output = self.run_js(r"""
const env = environment();
vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
vm.runInContext(fs.readFileSync('static/js/timeline.js', 'utf8'), env.context);
env.get('testCanvas').getContext = () => ({});
env.get('testContainer').getBoundingClientRect = () => ({left: 0, top: 0, width: 800, height: 400});
const timeline = vm.runInContext('new TimelineEngine("testCanvas", "testContainer", "testTooltip", event => { window.opened = event; }, () => {})', env.context);
const hostile = '<script>alert(`x`)</script><img src=x onerror="alert(1)">\'"` &';
const event = {id: 'hostile', timestamp: 1, title: hostile, category: hostile,
  source_name: hostile, source_url: 'javascript:alert(1)'};
const tooltip = env.get('testTooltip');
timeline.showTooltip(event, 20, 30);
const single = tooltip.innerHTML;
assert.doesNotMatch(single, /<script|<img|\son\w+\s*=\s*["']/i);
assert.doesNotMatch(single, /↗/);
assert.match(single, /&lt;script&gt;/);
timeline.hoveredItem = event;
tooltip.listeners.click();
assert.equal(env.context.opened, event);
const cluster = {isCluster: true, count: 2, timestamp: 1, events: [event, {...event, id: 'second'}]};
timeline.showTooltip(cluster, 20, 30);
const grouped = tooltip.innerHTML;
assert.doesNotMatch(grouped, /<script|<img|\son\w+\s*=\s*["']/i);
assert.match(grouped, /&lt;script&gt;/);
timeline.hoveredItem = cluster;
tooltip.listeners.click();
assert.equal(env.context.opened, event);
timeline.showTooltip({...event, source_url: 'data:text/html,<script>alert(1)</script>'}, 20, 30);
assert.doesNotMatch(tooltip.innerHTML, /↗/);
timeline.showTooltip({...event, source_url: 'HTTPS://example.test/?q=" onerror="alert(1)'}, 20, 30);
assert.match(tooltip.innerHTML, /↗/);
assert.equal(tooltip.style.left, '35px');
assert.equal(tooltip.classList.contains('hidden'), false);
env.get('testContainer').getBoundingClientRect = () => ({left: 0, top: 0, width: 300, height: 400});
timeline.showTooltip(event, 200, 30);
assert.equal(tooltip.style.left, '8px');
console.log(JSON.stringify([single, grouped, tooltip.innerHTML]));
""")

        class TooltipMarkup(HTMLParser):
            def handle_starttag(parser, tag, attrs):
                self.assertNotIn(tag, {"script", "img", "iframe", "svg", "object"})
                self.assertFalse(any(name.lower().startswith("on") for name, _ in attrs))

        for fragment in json.loads(output):
            parser = TooltipMarkup()
            parser.feed(fragment)
            parser.close()

    def test_dialog_focus_trap_escape_background_and_focus_restore(self):
        self.run_js(r"""
(async () => {
  const env = environment();
  class Engine { setData() {} setEvents() {} setFilters() {} setWindow() {} render() {} setSelectedEvent() {} }
  Object.assign(env.context, {TimelineEngine: Engine, MinimapEngine: Engine, WorldMapEngine: Engine});
  env.context.fetch = async url => ({ok: true, json: async () => url === '/api/events' ? {events: [], min_timestamp: 1, max_timestamp: 2} : {candles: []}});
  vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
  vm.runInContext(fs.readFileSync('static/js/app.js', 'utf8'), env.context);
  await env.callbacks[0]();
  const modal = env.get('eventDetailModal'), close = env.get('modalCloseBtn'), last = env.get('modalLastButton');
  close.parentElement = modal; last.parentElement = modal;
  modal.querySelectorAll = () => [close, last];
  const background = env.get('background'), priorInert = env.get('priorInert');
  priorInert.inert = true;
  env.context.document.body.children = [background, priorInert, modal];
  env.context.document.body.style.overflow = 'auto';
  const opener = env.get('invokingCard'); opener.focus();
  env.context.openDetailModal({id: 'one', timestamp: 1, title: 'News'});
  assert.equal(env.context.document.activeElement, close);
  assert.equal(background.inert, true);
  assert.equal(env.context.document.body.style.overflow, 'hidden');
  const keydown = env.windowEvents.get('keydown')[0];
  let prevented = 0;
  last.focus(); keydown({key: 'Tab', shiftKey: false, preventDefault() { prevented++; }});
  assert.equal(env.context.document.activeElement, close);
  close.focus(); keydown({key: 'Tab', shiftKey: true, preventDefault() { prevented++; }});
  assert.equal(env.context.document.activeElement, last);
  background.focus(); env.documentEvents.get('focusin')[0]({target: background});
  assert.equal(env.context.document.activeElement, close);
  keydown({key: 'Escape', preventDefault() { prevented++; }});
  assert.equal(modal.classList.contains('hidden'), true);
  assert.equal(env.context.document.activeElement, opener);
  assert.equal(background.inert, undefined);
  assert.equal(priorInert.inert, true);
  assert.equal(env.context.document.body.style.overflow, 'auto');
  assert.equal(prevented, 3);
})().catch(error => { console.error(error); process.exitCode = 1; });
""")

    def test_timeline_keyboard_pan_zoom_selection_and_activation(self):
        self.run_js(r"""
const env = environment(), HOUR = 3600000;
vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
vm.runInContext(fs.readFileSync('static/js/timeline.js', 'utf8'), env.context);
env.get('keysCanvas').getContext = () => ({});
const timeline = vm.runInContext('new TimelineEngine("keysCanvas", "keysContainer", "keysTooltip", event => { window.opened = event; }, (start, end) => { window.changed = [start, end]; })', env.context);
timeline.render = () => {};
timeline.minTime = 0; timeline.maxTime = 24 * HOUR; timeline.viewStart = 6 * HOUR; timeline.viewEnd = 12 * HOUR;
timeline.events = [{id: 'a', timestamp: 7 * HOUR, title: '<img onerror=bad>', category: 'การเมือง'}, {id: 'b', timestamp: 8 * HOUR, title: 'second', category: 'การเมือง'}];
const key = value => env.get('keysCanvas').listeners.keydown({key: value, preventDefault() {}});
key('ArrowRight'); assert.ok(timeline.viewStart > 6 * HOUR);
key('ArrowLeft'); assert.equal(timeline.viewStart, 6 * HOUR);
key('+'); assert.ok(timeline.viewEnd - timeline.viewStart < 6 * HOUR);
key('-'); assert.equal(timeline.viewEnd - timeline.viewStart, 6 * HOUR);
key('ArrowDown'); assert.equal(timeline.selectedEvent.id, 'a');
key('ArrowDown'); assert.equal(timeline.selectedEvent.id, 'b');
key('ArrowUp'); assert.equal(timeline.selectedEvent.id, 'a');
key('Enter'); assert.equal(env.context.opened.id, 'a');
assert.match(env.get('navigationStatus').textContent, /<img onerror=bad>/);
assert.equal(env.get('navigationStatus').innerHTML, '');
key('Home'); assert.equal(timeline.viewStart, 0);
key('End'); assert.equal(timeline.viewEnd, 24 * HOUR);
assert.equal(env.context.changed[1], 24 * HOUR);
""")

    def test_minimap_keyboard_pointer_mouse_touch_and_cancel(self):
        self.run_js(r"""
const env = environment(), HOUR = 3600000;
vm.runInContext(fs.readFileSync('static/js/minimap.js', 'utf8'), env.context);
env.get('miniCanvas').getContext = () => ({});
const container = env.get('miniContainer'); container.clientWidth = 300;
container.getBoundingClientRect = () => ({left: 0, width: 300});
const mini = vm.runInContext('new MinimapEngine("miniCanvas", "miniContainer", "miniViewport", "miniLeft", "miniRight", (start, end) => { window.brushed = [start, end]; })', env.context);
mini.minTime = 0; mini.maxTime = 24 * HOUR; mini.viewStart = 6 * HOUR; mini.viewEnd = 12 * HOUR;
const viewport = env.get('miniViewport'), left = env.get('miniLeft'), right = env.get('miniRight');
left.parentElement = viewport; right.parentElement = viewport;
const key = (target, value) => target.listeners.keydown({target, key: value, preventDefault() {}});
key(viewport, 'ArrowRight'); assert.ok(mini.viewStart > 6 * HOUR);
key(left, 'ArrowRight'); assert.ok(mini.viewStart > 6.6 * HOUR);
key(right, 'End'); assert.equal(mini.viewEnd, 24 * HOUR);
assert.equal(right.attributes['aria-valuenow'], String(24 * HOUR));
key(viewport, 'Home'); assert.equal(mini.viewStart, 0);
let captured = null;
viewport.setPointerCapture = id => { captured = id; };
viewport.hasPointerCapture = id => captured === id;
viewport.releasePointerCapture = () => { captured = null; };
const pointer = (type, target, id, x, pointerType = 'touch') => viewport.listeners[type]({target, pointerId: id, clientX: x, pointerType, button: 0, isPrimary: true, preventDefault() {}, stopPropagation() {}});
mini.viewStart = 6 * HOUR; mini.viewEnd = 12 * HOUR;
pointer('pointerdown', viewport, 1, 100);
assert.equal(captured, 1);
pointer('pointermove', viewport, 2, 150); assert.equal(mini.viewStart, 6 * HOUR);
pointer('pointermove', viewport, 1, 125); assert.equal(mini.viewStart, 8 * HOUR);
pointer('pointerup', viewport, 1, 125); assert.equal(mini.isDragging, false); assert.equal(captured, null);
pointer('pointerdown', left, 3, 100, 'mouse');
pointer('pointermove', left, 3, 112.5, 'mouse'); assert.equal(mini.viewStart, 9 * HOUR);
pointer('pointercancel', left, 3, 112.5, 'mouse'); assert.equal(mini.isDragging, false);
pointer('pointerdown', right, 4, 100);
pointer('pointermove', right, 4, 125); assert.equal(mini.viewEnd, 16 * HOUR);
pointer('pointerup', right, 4, 125);
assert.match(env.get('navigationStatus').textContent, /กรอบเวลา/);
env.context.matchMedia = () => ({matches: true});
mini.viewStart = 23.5 * HOUR; mini.viewEnd = 24 * HOUR; mini.updateViewportStyle();
assert.ok(parseFloat(viewport.style.width) >= 132);
assert.ok(parseFloat(viewport.style.left) + parseFloat(viewport.style.width) <= 300);
""")

    def test_responsive_dialog_motion_selection_and_contrast_contract(self):
        html = (ROOT / 'static/index.html').read_text(encoding='utf-8')
        css = (ROOT / 'static/css/style.css').read_text(encoding='utf-8')
        class Markup(HTMLParser):
            def __init__(parser):
                super().__init__()
                parser.elements = {}
            def handle_starttag(parser, tag, attrs):
                attrs = dict(attrs)
                if 'id' in attrs:
                    parser.elements[attrs['id']] = attrs
        parser = Markup()
        parser.feed(html)
        dialog = parser.elements['eventDetailDialog']
        self.assertEqual(dialog['role'], 'dialog')
        self.assertEqual(dialog['aria-modal'], 'true')
        self.assertEqual(dialog['aria-labelledby'], 'modalTitle')
        self.assertEqual(dialog['aria-describedby'], 'modalSummary')
        for control in ('timelineCanvas', 'minimapViewport', 'handleLeft', 'handleRight'):
            self.assertEqual(parser.elements[control]['tabindex'], '0')
            self.assertTrue(parser.elements[control]['aria-label'])
        self.assertEqual(parser.elements['handleLeft']['role'], 'slider')
        self.assertIn('@media (max-width: 767px)', css)
        self.assertIn('min-width: 44px', css)
        self.assertIn('min-height: 44px', css)
        # A bare button minimum loses to `.flex > * { min-width: 0 }`.
        # The touch-only important minimum also clamps Tailwind w-7/h-7 buttons.
        touch_rule = re.search(
            r'@media\s*\(pointer:\s*coarse\),\s*\(max-width:\s*767px\)\s*\{\s*'
            r'(button,[^{]+)\{([^}]+)\}', css,
        )
        self.assertIsNotNone(touch_rule)
        minimum = re.search(r'min-width:\s*(\d+)px\s*!important\s*;', touch_rule.group(2))
        self.assertIsNotNone(minimum)
        self.assertGreaterEqual(int(minimum.group(1)), 44)
        self.assertIn('w-7 h-7', html)
        self.assertIn('flex-wrap: wrap', css)
        self.assertIn('max-height: calc(100dvh - 2rem)', css)
        self.assertIn('user-select: text', css)
        self.assertIn('touch-action: none', css)
        self.assertIn('@media (prefers-reduced-motion: reduce)', css)
        self.assertIn('animation: none !important', css)
        self.assertIn('input::placeholder { color: var(--text-muted)', css)
        self.assertIn('--text-muted: #94a3b8', css)
        def luminance(color):
            values = [int(color[index:index + 2], 16) / 255 for index in (1, 3, 5)]
            linear = [value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4 for value in values]
            return sum(value * weight for value, weight in zip(linear, (0.2126, 0.7152, 0.0722)))
        for surface in ('#0b0e14', '#11151f', '#161c28', '#1e2738'):
            self.assertGreaterEqual((luminance('#94a3b8') + 0.05) / (luminance(surface) + 0.05), 4.5)

    def test_worldmap_flights_respect_reduced_motion(self):
        self.run_js(r"""
const env = environment();
vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
vm.runInContext(fs.readFileSync('static/js/worldmap.js', 'utf8'), env.context);
const map = env.context.worldMapEngine, flights = [];
let reduce = true;
env.context.matchMedia = query => ({matches: reduce && query === '(prefers-reduced-motion: reduce)'});
map.map = {flyTo(center, zoom, options) {flights.push({center, zoom, options});}, getZoom() {return 3;}};
map.selectHotspot(map.hotspots[0], true);
map.focusCurrentEvent(); map.resetView();
assert.ok(flights.every(flight => flight.options.animate === false));
assert.deepEqual(Array.from(flights[2].center), [22, 25]);
assert.equal(flights[2].zoom, 2);
reduce = false; map.focusCurrentEvent();
assert.equal(flights[3].options.animate, true);
assert.equal(flights[3].options.duration, 1.0);
""")

    def test_worldmap_discloses_bounded_feed_against_full_window_count(self):
        self.run_js(r"""
const env = environment();
vm.runInContext(fs.readFileSync('static/js/feed.js', 'utf8'), env.context);
vm.runInContext(fs.readFileSync('static/js/worldmap.js', 'utf8'), env.context);
const map = env.context.worldMapEngine;
const events = Array.from({length: 80}, (_, index) => ({id: 'geo-' + index,
  timestamp: Date.parse('2026-11-01T12:00:00+07:00'), title: 'อิหร่าน ' + index, category: 'การเมือง'}));
map.setData(events);
assert.equal(env.get('geoFeedCountBadge').innerText, 'แสดง 30 จาก 80 ข่าว');
assert.equal((env.get('geoFeedList').innerHTML.match(/<article\b/g) || []).length, 30);
assert.equal(env.get('rolling21CountBadge').innerText, '80 ข่าว');
assert.equal(env.get('mapVisibleCountBadge').innerText, '80 / 80');
assert.equal(map.hotspots[0].count, 80);
map.setCategory('crypto');
assert.equal(env.get('geoFeedCountBadge').innerText, '0 ข่าว');
map.setCategory('all');
assert.equal(env.get('geoFeedCountBadge').innerText, 'แสดง 30 จาก 80 ข่าว');
map.setData(events.slice(0, 5));
assert.equal(env.get('geoFeedCountBadge').innerText, '5 ข่าว');
assert.equal((env.get('geoFeedList').innerHTML.match(/<article\b/g) || []).length, 5);
""")

    def test_daily_scenarios_join_workbook_history_and_render_as_of_selected_date(self):
        self.run_js(r"""
const env = environment(); env.context.self = env.context;
for (const file of ['static/vendor/sheetjs/xlsx.mini.min.js','static/js/xlsx-worker.js','static/js/feed.js','static/js/worldmap.js'])
  vm.runInContext(fs.readFileSync(file,'utf8'),env.context);
const x = env.context.XLSX, book = x.utils.book_new();
function tab(name,header,objects) { x.utils.book_append_sheet(book,x.utils.aoa_to_sheet([header,...objects.map(o=>header.map(h=>o[h]??''))]),name); }
tab('Factnews',['Date','Category','Description'],[{Date:'2026-11-13',Category:'ธุรกิจ',Description:'latest'}]);
const dailyFields='review_id date_ict zone_id zone_th window_start_ict cutoff_at_ict decision analysis_id carry_from_analysis_id decision_reason_th coverage_state source_timing_state prepared_at_ict'.split(' ');
const analysisFields='analysis_id review_id date_ict zone_id headline_th confirmed_facts_th why_new_th escalation_trigger_th escalation_if_then_th deescalation_trigger_th deescalation_if_then_th watch_indicators_th confidence limitations_th prepared_at_ict evidence_ids'.split(' ');
const evidenceFields='evidence_id review_id analysis_id publisher source_date_or_time canonical_url supports_th timing_assessment'.split(' ');
const days = [10,11,12], zones=['HORMUZ','UKRAINE','TAIWAN','RED_SEA'], reviews=[],analyses=[],evidence=[];
const fresh='NEW_SCENARIO', carry='CARRY_FORWARD', quiet='NO_MATERIAL_SIGNAL_IN_CHECKED_SOURCES', gap='EVIDENCE_GAP';
const expected=[[fresh,fresh,quiet,gap],[fresh,carry,quiet,gap],[fresh,fresh,fresh,fresh]];
for(let i=0;i<days.length;i++) for(let j=0;j<zones.length;j++) {
  const zone=zones[j], day=days[i], date='2026-11-'+day, id=day+'-'+zone,decision=expected[i][j];
  const row={review_id:id,date_ict:date,zone_id:zone,zone_th:zone,window_start_ict:'2026-10-21',cutoff_at_ict:date+'T23:59:59+07:00',decision,
    decision_reason_th:'reason '+id,analysis_id:decision===fresh?'a'+id:'',carry_from_analysis_id:decision===carry?'a10-UKRAINE':'',
    prepared_at_ict:'2026-11-13T21:33:15+07:00',coverage_state:'21D_KEY_EVENTS_NOT_EXHAUSTIVE',source_timing_state:'SOURCE_TIMING_SUPPORTED'};
  reviews.push(row);
  if (decision===fresh) analyses.push({...row,headline_th:'headline '+id,confirmed_facts_th:'fact '+id, escalation_trigger_th:'A '+id,
    escalation_if_then_th:'if A '+id, deescalation_trigger_th:'B '+id, deescalation_if_then_th:'if B '+id,
    watch_indicators_th:'watch '+id,limitations_th:'limit '+id,evidence_ids:
    id==='12-TAIWAN' ? 'e10-TAIWAN,e11-TAIWAN,e12-TAIWAN' : id==='10-UKRAINE' ? 'e10-UKRAINE,e12-UKRAINE,e10-HORMUZ' : 'e'+id});
  if (decision!==carry) evidence.push({evidence_id:'e'+id,review_id:id,analysis_id:row.analysis_id,publisher:'source '+id,
    source_date_or_time:date,canonical_url:id==='10-RED_SEA'?'javascript:alert(1)':'https://example.test/'+id,supports_th:'<b>claim</b>'});
}
tab('Scenario_Daily',dailyFields,reviews);tab('Scenario_Analysis',analysisFields,analyses);tab('Scenario_Evidence',evidenceFields,evidence);
const parsed=env.context.parseFactnews(x.write(book,{bookType:'xlsx',type:'array'}));assert.equal(parsed.geo_scenarios.length,12);
const map=env.context.worldMapEngine;map.setData(parsed.events,parsed.geo_scenarios);
assert.equal(map.selectedAnchorDate,'2026-11-12');assert.equal(map.latestReviewDate,'2026-11-12');
for(let i=0;i<days.length;i++) for(let j=0;j<zones.length;j++) {
 const d=days[i], zone=zones[j], id=d+'-'+zone, status=expected[i][j];
 map.onDateSelectChange('2026-11-'+d);map.focusHotspot(zone.toLowerCase().replace(/_/g,''));
 map.setScenarioMode('escalation');const body=env.get('scenarioMatrixBody').innerHTML;
 assert.ok(body.includes('reason '+id));assert.match(body,/จัดทำย้อนหลังเมื่อ/);assert.match(body,/ไม่ครอบคลุมทุกข่าว/);
 assert.doesNotMatch(body,/<b>claim|href="javascript:|เนื้อหาแม่แบบสำรอง/);
 if(status===fresh||status===carry) {
  const origin=status===carry?'10-UKRAINE':id;
  for(const value of ['fact '+origin,'if A '+origin,'watch '+origin,'limit '+origin]) assert.ok(body.includes(value),value);
  assert.ok(body.includes('https://example.test/'+origin));assert.match(body,/target="_blank" rel="noopener noreferrer"/);
  if(origin==='10-UKRAINE') assert.doesNotMatch(body,/example.test\/(12-UKRAINE|10-HORMUZ)/);
  if(status===carry) assert.match(body,/วันที่ของบทวิเคราะห์เดิม/);
  if(id==='12-TAIWAN') for(const earlier of [10,11]) assert.ok(body.includes('example.test/'+earlier+'-TAIWAN'));
  map.setScenarioMode('deescalation');assert.ok(env.get('scenarioMatrixBody').innerHTML.includes('if B '+origin));
 } else {
  assert.equal(env.get('scenBtnEscalation').disabled,true);
  assert.match(body,status===gap?/หลักฐานของวันนี้ยังไม่เพียงพอ/:/ยังไม่พบสัญญาณที่เปลี่ยนการประเมิน/);
 }
}
map.focusHotspot('lithium');assert.match(env.get('scenarioMatrixBody').innerHTML,/ไม่มีผลทบทวนที่บันทึกไว้/);
map.focusHotspot('hormuz');map.resetToLatestDate();assert.equal(map.selectedAnchorDate,'2026-11-13');
assert.match(env.get('scenarioMatrixBody').innerHTML,/ไม่มีผลทบทวนที่บันทึกไว้/);
map.setData(parsed.events,parsed.geo_scenarios);assert.equal(map.selectedAnchorDate,'2026-11-13');
""")

    def test_geo_scenario_initial_markup_names_matched_news_and_what_if(self):
        html = (ROOT / 'static/index.html').read_text(encoding='utf-8')
        link = re.search(r'<a\b[^>]*id="scenarioOpenSourceBtn"[^>]*>(.*?)</a>', html, re.S)
        self.assertIsNotNone(link)
        self.assertIn('ข่าวที่จับคู่ด้วยคำหลัก ↗', link.group(1))
        self.assertNotIn('OPEN SOURCE', link.group(1))
        self.assertIn('สัญญาณข่าวที่จับคู่', html)
        for sample in ['rolling21OverallTrendBadge', 'donutTotalCountBadge', '42%', '($1.18B)']:
            self.assertNotIn(sample, html)
        self.assertIn('id="mapWarSignalsBadge">—</span>', html)
        self.assertIn('id="geoFeedCountBadge">—</span>', html)
        self.assertIn('เลือกพื้นที่เพื่อดูฉากทัศน์', html)
        self.assertIn('ฉากทัศน์ตามผลทบทวนที่บันทึกไว้', html)

    def test_geo_deployment_gate_skips_assets_and_work_off_and_restores_on(self):
        self.run_js(r"""
(async () => {
  for (const enabled of [false, true]) {
    const env = environment(), assets = [], requests = [], engineData = [];
    let geoConstructed = 0, geoRendered = 0, geoInitialized = 0;
    env.context.document.documentElement.dataset.enableGeo = String(enabled);
    const section = env.get('worldMapTabContent');
    section.style.display = 'none'; section.hidden = true; section.inert = true;
    class Engine {
      constructor(id) { this.id = id; }
      setData() { engineData.push(this.id); } setEvents() { engineData.push(this.id); }
      setFilters() {} setWindow() {} render() {}
    }
    class Geo {
      constructor() { geoConstructed++; this.isInitialized = false; }
      setData() { geoRendered++; }
      init() { geoInitialized++; this.isInitialized = true; }
      invalidateSize() {}
    }
    Object.assign(env.context, {TimelineEngine: Engine, MinimapEngine: Engine, FeedEngine: Engine, WorldMapEngine: Geo});
    // Even a pre-existing global must receive no calls when the feature is OFF.
    if (!enabled) env.context.worldMapEngine = new Proxy({}, {get() { return () => { throw Error('Unexpected GEO work while OFF'); }; }});
    env.context.document.head.appendChild = node => {
      assets.push(node.src || node.href);
      if (node.tagName === 'SCRIPT') node.onload();
    };
    env.context.fetch = async (url, options = {}) => {
      requests.push({url, method: options.method || 'GET'});
      return {ok: true, json: async () => url === '/api/events' ? {
        events: [{id: 'one', timestamp: 1000, title: 'Factnews', category: 'การเมือง'}], min_timestamp: 1000, max_timestamp: 2000,
        freshness: {status: 'fresh', source_mode: 'live'}
      } : {candles: [], freshness: {status: 'fresh', source: 'cache'}}};
    };
    vm.runInContext(fs.readFileSync('static/js/app.js', 'utf8'), env.context);
    await env.callbacks[0]();
    assert.ok(engineData.includes('timelineCanvas'));
    assert.ok(engineData.includes('minimapCanvas'));
    assert.ok(engineData.includes('eventsFeedList'));
    const navigation = env.get('tabWorldMapBtn');
    assert.equal(navigation.hidden, !enabled);
    assert.equal(navigation.inert, !enabled);
    if (enabled) {
      assert.deepEqual(assets, ['/static/vendor/leaflet/leaflet.css', '/static/vendor/leaflet/leaflet.js', '/static/js/worldmap.js']);
      assert.equal(geoConstructed, 1);
      assert.equal(geoRendered, 1);
      env.context.switchMainTab('world-map');
      assert.equal(geoInitialized, 1);
      assert.equal(section.style.display, 'flex');
      assert.equal(section.inert, false);
    } else {
      assert.deepEqual(assets, []);
      assert.equal(geoConstructed, 0);
      assert.equal(geoRendered, 0);
      assert.equal(geoInitialized, 0);
      env.context.switchMainTab('world-map');
      assert.equal(section.hidden, true);
      assert.equal(section.inert, true);
      assert.equal(section.style.display, 'none');
      assert.equal(env.get('marketTimelineTabContent').style.display, 'flex');
      assert.equal(env.get('tabStatusSubtitle').textContent, 'Timeline & Factnews Ready');
      for (let second = 0; second < 60; second++) await env.intervals[0]();
      await env.context.triggerManualSync();
      assert.deepEqual(assets, []);
      assert.equal(requests.filter(request => request.method === 'POST').length, 1);
    }
  }
})().catch(error => {console.error(error); process.exitCode = 1;});
""")

    def test_geo_deployment_enables_map_with_lazy_resources(self):
        class DeploymentMarkup(HTMLParser):
            def __init__(parser):
                super().__init__()
                parser.ids = {}
                parser.resources = []
                parser.root = {}
            def handle_starttag(parser, tag, attrs):
                attrs = dict(attrs)
                if tag == 'html':
                    parser.root = attrs
                if 'id' in attrs:
                    parser.ids[attrs['id']] = attrs
                if tag == 'script' and 'src' in attrs:
                    parser.resources.append(attrs['src'])
                if tag == 'link' and 'href' in attrs:
                    parser.resources.append(attrs['href'])
        parser = DeploymentMarkup()
        parser.feed((ROOT / 'static/index.html').read_text(encoding='utf-8'))
        self.assertEqual(parser.root['data-enable-geo'], 'true')
        for element_id in ('tabWorldMapBtn', 'worldMapTabContent'):
            attrs = parser.ids[element_id]
            self.assertIn('hidden', attrs)
            self.assertIn('inert', attrs)
            self.assertIn('display: none', attrs['style'])
        self.assertFalse(any('leaflet' in resource or 'worldmap' in resource for resource in parser.resources))
        for name in ('timeline', 'minimap', 'feed', 'app'):
            self.assertIn(f'/static/js/{name}.js', parser.resources)
        self.assertIn('scenarioMatrixBody', parser.ids, 'Preserve the GEO source markup')

    def test_political_color_contrast_is_consistent_on_tinted_surfaces(self):
        definitions = []
        for name in ('app', 'feed', 'timeline'):
            source = (ROOT / f'static/js/{name}.js').read_text(encoding='utf-8')
            match = re.search(
                r"'การเมือง':\s*\{\s*color:\s*'(#[0-9A-Fa-f]{6})',\s*tint:\s*'rgba\(([^)]+)\)',\s*border:\s*'rgba\(([^)]+)\)'",
                source,
            )
            self.assertIsNotNone(match, name)
            color = match.group(1)
            rgb = tuple(int(color[index:index + 2], 16) for index in (1, 3, 5))
            tint = [float(value.strip()) for value in match.group(2).split(',')]
            border = [float(value.strip()) for value in match.group(3).split(',')]
            self.assertEqual(tuple(tint[:3]), rgb)
            self.assertEqual(tuple(border[:3]), rgb)
            self.assertEqual(tint[3], 0.12)
            definitions.append(color.upper())
        source = (ROOT / 'static/js/worldmap.js').read_text(encoding='utf-8')
        companion = re.search(r"ev.category === 'การเมือง'\)\s*\{\s*catColor = '(#[0-9A-Fa-f]{6})'", source)
        self.assertIsNotNone(companion)
        definitions.append(companion.group(1).upper())
        self.assertEqual(len(set(definitions)), 1)
        color = definitions[0]
        foreground = tuple(int(color[index:index + 2], 16) for index in (1, 3, 5))
        self.assertGreater(foreground[0], max(foreground[1:]), 'Keep the political category red')

        def luminance(rgb):
            channels = [value / 255 for value in rgb]
            channels = [value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4 for value in channels]
            return sum(value * weight for value, weight in zip(channels, (0.2126, 0.7152, 0.0722)))

        # Include normal, hovered, elevated/modal and world-map card surfaces.
        for surface in ('#0b0e14', '#101520', '#11151f', '#111520', '#131722', '#141a26', '#161c28', '#202738', '#20293a', '#0e121a'):
            background = tuple(int(surface[index:index + 2], 16) for index in (1, 3, 5))
            for opacity in (0, 0.12, 21 / 255):
                tinted = tuple(opacity * red + (1 - opacity) * base for red, base in zip(foreground, background))
                contrast = (luminance(foreground) + 0.05) / (luminance(tinted) + 0.05)
                self.assertGreaterEqual(contrast, 4.5, (surface, opacity, contrast))


if __name__ == "__main__":
    unittest.main()
