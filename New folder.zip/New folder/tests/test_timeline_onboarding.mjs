import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import vm from 'node:vm';

// Reuse the existing dependency-free DOM fixture; execute the shipped controllers.
const require = createRequire(import.meta.url);
const root = new URL('../', import.meta.url);
const read = path => readFileSync(new URL(path, root), 'utf8');
const domFixture = read('tests/test_ui_contract.py').match(/DOM = r"""([\s\S]*?)"""/)[1];
const environment = vm.runInNewContext(`${domFixture}\nenvironment;`, { require, URL });
const DAY = 86400000;
const KEY = 'writetime.timelineTour.shownDay.v1';
const NOW = Date.parse('2026-11-03T04:00:00Z');
const storage = (values = new Map()) => ({ values, getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, String(value)) });
const news = (timestamp, extra = {}) => ({ id: 'real-article', timestamp, category: 'ธุรกิจ', title: 'ข่าวทดสอบ', source_url: 'https://example.test/original', ...extra });

async function boot({ now = NOW, events = [news(now - 3600000)], local = storage(), session = storage(), failNews = false } = {}) {
  const env = environment();
  const context = env.context;
  let clock = now;
  let currentEvents = events;
  let scrollY = 0;
  const decorate = node => {
    node.isConnected = true;
    node.getBoundingClientRect = () => node.id === 'timelineTourDialog'
      ? { left: 12, top: 540, right: 378, bottom: 800, width: 366, height: 260 }
      : { left: 20, top: 300 - scrollY, right: 350, bottom: 344 - scrollY, width: 330, height: 44 };
    return node;
  };
  const originalGet = context.document.getElementById;
  context.document.getElementById = id => decorate(originalGet(id));
  context.document.documentElement.clientWidth = 390;
  context.document.activeElement = context.document.body;
  const presets = [24, 72, 168, 336, 0].map(hours => {
    const button = env.get(`preset${hours}`); button.dataset.hours = String(hours); return button;
  });
  context.document.querySelectorAll = selector => {
    if (selector === '.preset-btn') return presets;
    if (selector === '#eventsFeedList article[data-id]') return env.get('eventsFeedList').querySelectorAll('article[data-id]').map(decorate);
    if (selector === '#eventsFeedList article a[href]') {
      const href = env.get('eventsFeedList').innerHTML.match(/<a href="([^"]+)"/);
      if (!href) return [];
      const link = env.get('realSourceLink'); link.href = href[1]; return [link];
    }
    return [];
  };
  const tour = env.get('timelineTourDialog');
  tour.hidden = true;
  ['Next', 'Back', 'Skip', 'Close'].forEach(name => tour.children.push(env.get(`timelineTour${name}Btn`)));
  context.Date = class extends Date { constructor(...args) { super(...(args.length ? args : [clock])); } static now() { return clock; } };
  Object.assign(context, { localStorage: local, sessionStorage: session, innerHeight: 844, scrollBy: ({ top }) => { scrollY = Math.max(0, scrollY + top); } });
  // Keep real engine window/filter methods; replace only drawing and event wiring.
  vm.runInContext(read('static/js/timeline.js').replace('class TimelineEngine', 'class ProductionTimelineEngine'), context);
  vm.runInContext(read('static/js/minimap.js').replace('class MinimapEngine', 'class ProductionMinimapEngine'), context);
  vm.runInContext(read('static/js/feed.js').replace('class FeedEngine', 'class ProductionFeedEngine'), context);
  const Timeline = vm.runInContext('ProductionTimelineEngine', context);
  const Minimap = vm.runInContext('ProductionMinimapEngine', context);
  const Feed = vm.runInContext('ProductionFeedEngine', context);
  let timeline, minimap, feed;
  context.TimelineEngine = function(canvas, container, tooltip, onEventClick, onWindowChange) {
    timeline = Object.assign(Object.create(Timeline.prototype), { canvas: env.get(canvas), container: env.get(container), tooltip: env.get(tooltip), onEventClick, onWindowChange, activeCategories: new Set(['ธุรกิจ', 'เศรษฐกิจ', 'การเงิน', 'การเมือง', 'คริปโต', 'สงคราม']), searchQuery: '', selectedEvent: null, viewStart: 0, viewEnd: 0, render() {} });
    return timeline;
  };
  context.MinimapEngine = function(canvas, container, viewport, left, right, onBrushChange) {
    minimap = Object.assign(Object.create(Minimap.prototype), { canvas: env.get(canvas), container: env.get(container), viewport: env.get(viewport), handleLeft: env.get(left), handleRight: env.get(right), onBrushChange, render() {} });
    minimap.container.clientWidth = 390;
    return minimap;
  };
  context.FeedEngine = function(...args) { feed = new Feed(...args); return feed; };
  context.fetch = async url => {
    if (failNews && url === '/api/events') throw new Error('offline fixture');
    return { ok: true, json: async () => url === '/api/events' ? { events: currentEvents, freshness: { status: 'fresh' } } : { candles: [], freshness: { status: 'fresh' } } };
  };
  vm.runInContext(read('static/js/app.js'), context);
  await env.callbacks[0]();
  return {
    ...env, timeline, minimap, feed, presets, local,
    clock(value) { clock = value; }, events(value) { currentEvents = value; },
    click(name) { env.get(name).listeners.click({ target: env.get(name) }); },
    async refresh() { for (let second = 0; second < 60; second++) await env.intervals[0](); },
    key(key) { const event = { key, preventDefault() { this.prevented = true; } }; (env.windowEvents.get('keydown') || []).forEach(listener => listener(event)); return event; }
  };
}

function assertWindow(env, start, end) {
  for (const engine of [env.timeline, env.minimap, env.feed]) {
    assert.equal(engine.viewStart, start);
    assert.equal(engine.viewEnd, end);
  }
}

test('each fresh load uses exact clock-based 24H for empty, stale and tiny datasets', async () => {
  for (const events of [[], [news(NOW - 40 * DAY)], [news(NOW - 1000)]]) {
    const env = await boot({ events });
    assertWindow(env, NOW - DAY, NOW);
    assert.equal(env.presets[0].attributes['aria-pressed'], 'true');
    assert.equal(env.presets[2].attributes['aria-pressed'], 'false');
    assert.equal(env.get('feedCounterBadge').innerText, events.length && events[0].timestamp > NOW - DAY ? '1 ข่าว' : '0 ข่าว');
    assert.ok(env.timeline.minTime <= NOW - DAY);
    assert.equal(env.timeline.maxTime, NOW);
    assert.ok(!env.get('minimapRangeLabel').textContent.includes('29 ต.ค. 2026'));
  }
  const offline = await boot({ failNews: true });
  assertWindow(offline, NOW - DAY, NOW);
});

test('presets, keyboard pan, filters and refresh preserve a single synchronized window; reset returns current 24H', async () => {
  const env = await boot({ events: [news(NOW - 40 * DAY)] });
  for (const hours of [72, 168, 336]) {
    env.context.setZoomPreset(hours);
    assertWindow(env, NOW - hours * 3600000, NOW);
  }
  env.context.setZoomPreset(0);
  assertWindow(env, NOW - 40 * DAY, NOW);
  env.context.setZoomPreset(168);
  env.clock(NOW + 60000);
  await env.refresh();
  assertWindow(env, NOW - 7 * DAY, NOW);
  assert.equal(env.presets[2].attributes['aria-pressed'], 'true');
  env.timeline.handleKeyboard({ key: 'ArrowLeft', preventDefault() {} });
  const chosen = [env.timeline.viewStart, env.timeline.viewEnd];
  assert.ok(chosen[1] < NOW);
  assert.ok(env.presets.every(button => button.attributes['aria-pressed'] === 'false'));
  env.clock(NOW + DAY);
  env.events([]);
  await env.refresh();
  assertWindow(env, ...chosen);
  env.context.toggleOnlyCategory('คริปโต');
  assertWindow(env, ...chosen);
  env.context.resetTimelineView();
  assertWindow(env, NOW, NOW + DAY);
  assert.equal(env.presets[0].attributes['aria-pressed'], 'true');
  const reloaded = await boot({ now: NOW + DAY, local: env.local });
  assertWindow(reloaded, NOW, NOW + DAY);
});

test('auto tour claims Bangkok day when shown; Skip, close, Escape and finish never repeat on same-day reload', async () => {
  for (const action of ['skip', 'close', 'escape', 'finish']) {
    const local = storage();
    const env = await boot({ local });
    assert.equal(local.values.get(KEY), '2026-11-03');
    assert.equal(env.get('timelineTourDialog').hidden, false);
    assert.equal(env.get('timelineTourCounter').textContent, '1/7');
    assert.equal(env.get('timelineTourBackBtn').disabled, true);
    const reloadWhileOpen = await boot({ local });
    assert.equal(reloadWhileOpen.get('timelineTourDialog').hidden, true, 'The day is claimed before any Skip or Finish action');
    if (action === 'skip') env.click('timelineTourSkipBtn');
    if (action === 'close') env.click('timelineTourCloseBtn');
    if (action === 'escape') assert.equal(env.key('Escape').prevented, true);
    if (action === 'finish') {
      for (let step = 2; step <= 7; step++) { env.click('timelineTourNextBtn'); assert.equal(env.get('timelineTourCounter').textContent, `${step}/7`); }
      assert.equal(env.get('timelineTourNextBtn').textContent, 'เสร็จสิ้น');
      env.click('timelineTourNextBtn');
    }
    assert.equal(env.get('timelineTourDialog').hidden, true);
    assert.equal(env.context.document.activeElement, env.get('timelineTourHelpBtn'));
    const reloaded = await boot({ local });
    assert.equal(reloaded.get('timelineTourDialog').hidden, true);
    reloaded.click('timelineTourHelpBtn');
    assert.equal(reloaded.get('timelineTourDialog').hidden, false);
    reloaded.click('timelineTourNextBtn'); reloaded.click('timelineTourBackBtn');
    assert.equal(reloaded.get('timelineTourCounter').textContent, '1/7');
  }
});

test('Bangkok calendar rollover is simulated exactly at 16:59:59Z / 17:00:00Z', async () => {
  const local = storage();
  const before = await boot({ now: Date.parse('2026-11-03T16:59:59Z'), local });
  assert.equal(local.values.get(KEY), '2026-11-03');
  before.click('timelineTourSkipBtn');
  const sameDay = await boot({ now: Date.parse('2026-11-03T16:59:59.999Z'), local });
  assert.equal(sameDay.get('timelineTourDialog').hidden, true);
  const nextDay = await boot({ now: Date.parse('2026-11-03T17:00:00Z'), local });
  assert.equal(nextDay.get('timelineTourDialog').hidden, false);
  assert.equal(local.values.get(KEY), '2026-11-04');
});

test('malformed or blocked storage is safe; session fallback survives reload; manual help works without storage', async () => {
  const malformed = storage(new Map([[KEY, '{broken json']]));
  const repaired = await boot({ local: malformed });
  assert.equal(repaired.get('timelineTourDialog').hidden, false);
  assert.equal(malformed.values.get(KEY), '2026-11-03');
  const blocked = { getItem() { throw new Error('blocked'); }, setItem() { throw new Error('blocked'); } };
  const session = storage();
  const fallback = await boot({ local: blocked, session });
  assert.equal(fallback.get('timelineTourDialog').hidden, false);
  const reloaded = await boot({ local: blocked, session });
  assert.equal(reloaded.get('timelineTourDialog').hidden, true);
  const recovered = await boot({ local: storage(), session });
  assert.equal(recovered.get('timelineTourDialog').hidden, true, 'Restored local storage must respect a day claimed in session storage');
  const unavailable = await boot({ local: blocked, session: blocked });
  assert.equal(unavailable.get('timelineTourDialog').hidden, true);
  unavailable.click('timelineTourHelpBtn');
  assert.equal(unavailable.get('timelineTourDialog').hidden, false);
  assertWindow(unavailable, NOW - DAY, NOW);
});

test('tour targets real source, explains missing news/link, remains nonmodal and yields to reading', async () => {
  for (const events of [[], [news(NOW - 1000, { source_url: '' })], [news(NOW - 1000)]]) {
    const env = await boot({ events });
    for (let step = 1; step < 5; step++) env.click('timelineTourNextBtn');
    assert.equal(env.get('timelineTourCounter').textContent, '5/7');
    assert.equal(env.get('timelineTourDescription').textContent.includes('ยังไม่มีข่าว'), !events.length);
    env.click('timelineTourNextBtn');
    assert.equal(env.get('timelineTourDescription').textContent.includes('ยังไม่มีลิงก์'), !events[0]?.source_url);
    if (events[0]?.source_url) assert.equal(env.get('realSourceLink').href, events[0].source_url);
    assert.equal(env.context.document.body.inert, undefined);
    if (events.length) {
      env.context.openDetailModal(events[0]);
      assert.equal(env.get('timelineTourDialog').hidden, true);
      assert.equal(env.get('eventDetailModal').classList.contains('hidden'), false);
    }
  }
  const html = read('static/index.html');
  const dialogMarkup = html.match(/<section id="timelineTourDialog"[^>]*>/)[0];
  assert.match(dialogMarkup, /role="dialog"/);
  assert.doesNotMatch(dialogMarkup, /aria-modal="true"/);
  assert.match(read('static/css/style.css'), /\.tour-spotlight\s*\{[^}]*pointer-events:\s*none/);
});
