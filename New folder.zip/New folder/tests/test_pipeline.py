import asyncio
import datetime as dt
import importlib
import io
import json
import os
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch

import openpyxl
import requests
from fastapi.testclient import TestClient

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from app.market_data import MarketDataProvider
from app.parser import FactnewsParser
from app.watcher import FactnewsWatcher

app_module = importlib.import_module("app.main")
HOUR = 3600000
BASE_TIME = int(dt.datetime(2026, 11, 1, tzinfo=dt.timezone.utc).timestamp() * 1000)


def candle(timestamp, close=100):
    return {"time": timestamp, "open": 99.0, "high": 101.0,
            "low": 98.0, "close": float(close), "volume": 10.0}


def response_for(times):
    response = Mock()
    response.raise_for_status.return_value = None
    response.json.return_value = [[t, "99", "101", "98", "100", "10"] for t in times]
    return response


class TestMarketDataPipeline(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.provider = MarketDataProvider(self.directory)
        self.cache_file = self.directory / "klines_BTCUSDT_1h.json"
        self.now_ms = BASE_TIME + 2000 * HOUR
        clock_patch = patch("app.market_data.time.time", return_value=self.now_ms / 1000)
        self.clock = clock_patch.start()
        self.addCleanup(clock_patch.stop)
        network_patch = patch("app.market_data.requests.get", side_effect=AssertionError("Unexpected network call"))
        self.network = network_patch.start()
        self.addCleanup(network_patch.stop)

    def write_cache(self, candles, fetched_at=None):
        payload = candles if fetched_at is None else {
            "version": 1, "candles": candles, "last_candle_fetched_at_ms": fetched_at,
        }
        self.cache_file.write_text(json.dumps(payload), encoding="utf-8")

    def result(self, start, end, **kwargs):
        return self.provider.get_klines_result("BTCUSDT", "1h", start, end, **kwargs)

    def test_stale_cache_fetches_requested_range_and_preserves_history(self):
        self.write_cache([candle(BASE_TIME + i * HOUR) for i in range(60)])
        requested = [BASE_TIME + i * HOUR for i in range(60, 63)]
        self.network.side_effect = None
        self.network.return_value = response_for(requested)
        result = self.result(requested[0], requested[-1])
        self.assertEqual([c["time"] for c in result["candles"]], requested)
        self.assertEqual(self.network.call_args.kwargs["params"]["startTime"], requested[0])
        self.assertEqual(result["freshness"]["status"], "fresh")
        self.assertFalse(result["freshness"]["stale"])
        saved = json.loads(self.cache_file.read_text(encoding="utf-8"))
        self.assertEqual(len(saved["candles"]), 63)
        self.assertEqual(saved["candles"][0]["time"], BASE_TIME)

    def test_covered_cache_is_sorted_deduplicated_and_filtered(self):
        values = [candle(BASE_TIME + i * HOUR) for i in reversed(range(11))]
        values.append(candle(BASE_TIME + 6 * HOUR, close=105))
        self.write_cache(values)
        result = self.result(BASE_TIME + 4 * HOUR + 1, BASE_TIME + 7 * HOUR + 1)
        self.assertEqual([c["time"] for c in result["candles"]], [BASE_TIME + i * HOUR for i in (5, 6, 7)])
        self.assertEqual(result["candles"][1]["close"], 105)
        self.assertEqual(result["freshness"]["source"], "cache")
        self.network.assert_not_called()

    def test_pagination_over_1000_candles_merges_without_losing_history(self):
        self.write_cache([candle(BASE_TIME - HOUR)])
        times = [BASE_TIME + i * HOUR for i in range(1505)]
        self.network.side_effect = [response_for(times[:1000]), response_for(times[1000:])]
        result = self.result(times[0], times[-1])
        self.assertEqual(len(result["candles"]), 1505)
        self.assertEqual(self.network.call_count, 2)
        self.assertEqual(self.network.call_args_list[1].kwargs["params"]["startTime"], times[1000])
        self.assertTrue(result["freshness"]["coverage_complete"])
        saved = json.loads(self.cache_file.read_text(encoding="utf-8"))
        self.assertEqual(len(saved["candles"]), 1506)
        self.assertEqual(saved["candles"][0]["time"], BASE_TIME - HOUR)

    def test_internal_gap_fetches_only_missing_candle(self):
        self.write_cache([candle(BASE_TIME + i * HOUR) for i in (0, 1, 3, 4, 5)])
        self.network.side_effect = None
        self.network.return_value = response_for([BASE_TIME + 2 * HOUR])
        result = self.result(BASE_TIME, BASE_TIME + 4 * HOUR)
        self.assertEqual(len(result["candles"]), 5)
        params = self.network.call_args.kwargs["params"]
        self.assertEqual(params["startTime"], BASE_TIME + 2 * HOUR)
        self.assertEqual(params["endTime"], BASE_TIME + 2 * HOUR)

    def test_failed_fetch_returns_only_overlapping_cache_with_stale_metadata(self):
        self.write_cache([candle(BASE_TIME + i * HOUR) for i in range(4)])
        original = self.cache_file.read_bytes()
        self.network.side_effect = requests.ConnectionError("offline")
        result = self.result(BASE_TIME + 2 * HOUR, BASE_TIME + 6 * HOUR)
        self.assertEqual([c["time"] for c in result["candles"]], [BASE_TIME + i * HOUR for i in (2, 3)])
        freshness = result["freshness"]
        self.assertEqual(freshness["source"], "cache_fallback")
        self.assertEqual(freshness["status"], "stale")
        self.assertFalse(freshness["coverage_complete"])
        self.assertEqual(freshness["fetch_error"], "offline")
        self.assertEqual(freshness["last_candle_time"], BASE_TIME + 3 * HOUR)
        self.assertEqual(self.cache_file.read_bytes(), original)

    def test_failed_fetch_never_returns_out_of_range_history(self):
        self.write_cache([candle(BASE_TIME)])
        self.network.side_effect = requests.ConnectionError("offline")
        result = self.result(BASE_TIME + HOUR, BASE_TIME + 2 * HOUR)
        self.assertEqual(result["candles"], [])
        self.assertEqual(result["freshness"]["status"], "unavailable")
        self.assertIsNone(result["freshness"]["returned_range"]["start_ms"])

    def test_open_candle_ttl_and_refresh_after_close(self):
        now = BASE_TIME + HOUR // 2
        self.clock.return_value = now / 1000
        self.write_cache([candle(BASE_TIME)], fetched_at=now - 30000)
        self.assertEqual(self.result(BASE_TIME, now)["freshness"]["source"], "cache")
        self.network.assert_not_called()
        self.clock.return_value = (now + 61000) / 1000
        self.network.side_effect = None
        self.network.return_value = response_for([BASE_TIME])
        self.assertEqual(self.result(BASE_TIME, now + 61000)["freshness"]["source"], "binance")
        self.clock.return_value = (BASE_TIME + HOUR + 1) / 1000
        self.result(BASE_TIME, BASE_TIME)
        self.assertEqual(self.network.call_count, 2)

    def test_empty_refresh_does_not_claim_expired_open_candle_is_fresh(self):
        self.clock.return_value = (BASE_TIME + HOUR // 2) / 1000
        self.write_cache([candle(BASE_TIME)], fetched_at=BASE_TIME + 1)
        self.network.side_effect = None
        self.network.return_value = response_for([])
        result = self.result(BASE_TIME, BASE_TIME + HOUR // 2)
        self.assertTrue(result["freshness"]["stale"])
        self.assertEqual(result["freshness"]["status"], "stale")

    def test_old_open_tail_is_revalidated_after_a_disjoint_append(self):
        self.clock.return_value = (BASE_TIME + HOUR + 1) / 1000
        self.write_cache([candle(BASE_TIME)], fetched_at=BASE_TIME + 10000)
        self.network.side_effect = [response_for([BASE_TIME + HOUR]), response_for([BASE_TIME])]
        self.result(BASE_TIME + HOUR, BASE_TIME + HOUR)
        result = self.result(BASE_TIME, BASE_TIME)
        self.assertEqual(self.network.call_count, 2)
        self.assertEqual(self.network.call_args.kwargs["params"]["startTime"], BASE_TIME)
        self.assertFalse(result["freshness"]["stale"])

    def test_repeated_page_stops_without_infinite_loop(self):
        times = [BASE_TIME + i * HOUR for i in range(1000)]
        self.network.side_effect = [response_for(times), response_for(times)]
        result = self.result(BASE_TIME, BASE_TIME + 1500 * HOUR)
        self.assertEqual(self.network.call_count, 2)
        self.assertEqual(len(result["candles"]), 1000)
        self.assertIn("did not advance", result["freshness"]["fetch_error"])
        self.assertTrue(result["freshness"]["stale"])

    def test_atomic_write_failure_keeps_original_cache(self):
        self.write_cache([candle(BASE_TIME)])
        original = self.cache_file.read_bytes()
        self.network.side_effect = None
        self.network.return_value = response_for([BASE_TIME + HOUR])
        with patch("app.market_data.os.replace", side_effect=OSError("replace denied")):
            result = self.result(BASE_TIME + HOUR, BASE_TIME + HOUR)
        self.assertEqual(result["freshness"]["cache_write_error"], "replace denied")
        self.assertFalse(result["freshness"]["stale"])
        self.assertEqual(self.cache_file.read_bytes(), original)
        self.assertEqual(list(self.directory.iterdir()), [self.cache_file])

    def test_default_end_is_current_time_and_list_interface_survives(self):
        self.network.side_effect = None
        self.network.return_value = response_for([self.now_ms])
        result = self.provider.get_klines_result(start_ms=self.now_ms)
        self.assertEqual(result["freshness"]["requested_range"]["end_ms"], self.now_ms)
        self.assertEqual(self.network.call_args.kwargs["params"]["endTime"], self.now_ms)
        self.assertIsInstance(self.provider.get_klines(start_ms=self.now_ms, end_ms=self.now_ms), list)

    def test_monthly_and_weekly_alignment(self):
        january = int(dt.datetime(2026, 1, 1, tzinfo=dt.timezone.utc).timestamp() * 1000)
        march = int(dt.datetime(2026, 3, 1, tzinfo=dt.timezone.utc).timestamp() * 1000)
        self.assertEqual(len(self.provider._expected_opens(january, march, "1M")), 3)
        weekly = self.provider._expected_opens(BASE_TIME, BASE_TIME + 7 * 24 * HOUR, "1w")
        self.assertTrue(all(dt.datetime.fromtimestamp(t / 1000, dt.timezone.utc).weekday() == 0 for t in weekly))


class TestFactnewsPipeline(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.excel_path = self.directory / "fixture.xlsx"
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = "Factnews"
        headers = ["Date", "Category", "Description", "Provider", "Source link", "Published at"]
        for column, header in enumerate(headers, 1):
            sheet.cell(row=7, column=column, value=header)
        for index, category in enumerate(("ธุรกิจ", "เศรษฐกิจ", "การเงิน", "การเมือง", "คริปโต"), 8):
            values = [dt.datetime(2026, 11, 1), category, f"หัวเรื่อง {category}\nสรุปจากหลักฐาน",
                      "Factnews AI", f'=HYPERLINK("https://example.com/news/{index}","Fixture News")',
                      dt.datetime(2026, 11, 1, index)]
            for column, value in enumerate(values, 1):
                sheet.cell(row=index, column=column, value=value)
        workbook.save(self.excel_path)
        network_patch = patch("requests.get", side_effect=AssertionError("Tests must not use live services"))
        self.network = network_patch.start()
        self.addCleanup(network_patch.stop)

    def test_parser_loads_categories_and_authentic_hyperlinks(self):
        data = FactnewsParser(self.excel_path).parse(prefer_live=False)
        self.assertEqual(data["status"], "success")
        self.assertEqual(data["total_count"], 5)
        self.assertEqual(set(data["category_counts"]), {"ธุรกิจ", "เศรษฐกิจ", "การเงิน", "การเมือง", "คริปโต"})
        self.assertEqual(data["events"][0]["source_url"], "https://example.com/news/8")
        self.assertEqual(data["events"][0]["source_name"], "Fixture News")

    def test_watcher_cache_and_status(self):
        watcher = FactnewsWatcher(self.excel_path)
        watcher.parser.google_sheet_url = None
        data = watcher.get_data()
        self.assertEqual(len(data["events"]), 5)
        self.assertTrue(watcher.get_status()["file_exists"])
        self.assertEqual(watcher.get_status()["reload_count"], 1)
        self.assertIs(watcher.get_data(), data)

    def test_parser_live_failure_falls_back_to_local_fixture(self):
        self.network.side_effect = requests.ConnectionError("offline fixture")
        data = FactnewsParser(self.excel_path).parse(prefer_live=True)
        self.assertEqual(data["source"], "Local Database Cache")
        self.assertEqual(data["total_count"], 5)

    def test_fastapi_endpoints_preserve_fields_and_return_freshness(self):
        data = FactnewsParser(self.excel_path).parse(prefer_live=False)
        provider = MarketDataProvider(self.directory)
        cached = [candle(BASE_TIME + i * HOUR) for i in range(4)]
        provider._save_cache(self.directory / "klines_BTCUSDT_1h.json", cached, BASE_TIME + 5 * HOUR)
        with patch.object(app_module, "market_data", provider), \
             patch.object(app_module.watcher, "get_data", return_value=data), \
             patch.object(app_module.watcher, "get_status", return_value={"status": "online", "total_events": 5}), \
             patch.object(app_module.watcher, "sync_async", new_callable=AsyncMock, return_value=data) as sync:
            client = TestClient(app_module.app)
            self.assertEqual(client.get("/api/status").json()["total_events"], 5)
            self.assertEqual(client.get("/api/events").json()["total_count"], 5)
            for endpoint in ("/api/sync", "/api/refresh"):
                response = client.post(endpoint)
                self.assertEqual(response.status_code, 200)
                result = response.json()
                self.assertTrue({"status", "message", "source", "total_count", "last_sync_time"}.issubset(result))
                self.assertEqual(result["status"], "success")
                self.assertEqual(result["total_count"], 5)
                self.assertEqual(result["source"], data["source"])
                self.assertEqual(result["last_sync_time"], data["last_sync_time"])
            self.assertEqual(sync.await_count, 2)
            sync.assert_awaited_with(prefer_live=True)
            response = client.get(f"/api/prices?symbol=btcusdt&interval=1h&start_ms={BASE_TIME}&end_ms={BASE_TIME + 2 * HOUR}")
            self.assertEqual(response.status_code, 200)
            prices = response.json()
            self.assertTrue({"symbol", "interval", "count", "candles", "freshness"}.issubset(prices))
            self.assertEqual(prices["symbol"], "BTCUSDT")
            self.assertEqual(prices["count"], 3)
            self.assertFalse(prices["freshness"]["stale"])
            self.assertEqual(client.get("/").status_code, 200)
            self.assertEqual(client.get("/api/prices?interval=bad").status_code, 400)
            self.assertEqual(client.get("/api/prices?symbol=../x").status_code, 400)
            self.assertEqual(client.get("/api/prices?start_ms=10&end_ms=1").status_code, 400)


class TestFactnewsFreshness(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.directory = Path(temporary.name)
        self.excel_path = self.directory / "fixture.xlsx"
        self.original = self.workbook_bytes("Cached fixture")
        self.live = self.workbook_bytes("Live fixture")
        self.excel_path.write_bytes(self.original)
        self.parser = FactnewsParser(self.excel_path)
        network_patch = patch("requests.get")
        self.network = network_patch.start()
        self.addCleanup(network_patch.stop)
        self.network.return_value = Mock(status_code=200, content=self.live)

    @staticmethod
    def workbook_bytes(title=None, headers=True):
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = "Factnews"
        if headers:
            sheet.append([])
            for column, header in enumerate(("Date", "Category", "Description", "Provider"), 1):
                sheet.cell(row=7, column=column, value=header)
        if title:
            for column, value in enumerate((dt.datetime(2026, 11, 1), "คริปโต", title, "Fixture"), 1):
                sheet.cell(row=8, column=column, value=value)
        buffer = io.BytesIO()
        workbook.save(buffer)
        workbook.close()
        return buffer.getvalue()

    def assert_freshness(self, data, mode, status, stale):
        freshness = data["freshness"]
        self.assertTrue({"source_mode", "status", "stale", "checked_at", "last_live_success_at",
                         "cache_updated_at", "fetch_error", "cache_write_error"}.issubset(freshness))
        self.assertEqual(freshness["source_mode"], mode)
        self.assertEqual(freshness["status"], status)
        self.assertEqual(freshness["stale"], stale)
        if mode == "local":
            self.assertIsNone(freshness["checked_at"])
        else:
            self.assertIsNotNone(dt.datetime.fromisoformat(freshness["checked_at"]).tzinfo)
        self.assertIsNotNone(freshness["cache_updated_at"])
        self.assertEqual(list(self.directory.iterdir()), [self.excel_path])
        return freshness

    def test_valid_live_workbook_is_parsed_before_atomic_cache_replace(self):
        real_parse = self.parser._parse_excel_bytes
        real_replace = os.replace
        real_tempfile = tempfile.NamedTemporaryFile
        opened = []
        order = []

        def parse(*args, **kwargs):
            self.assertEqual(self.excel_path.read_bytes(), self.original)
            data = real_parse(*args, **kwargs)
            order.append("parsed")
            return data

        def temporary(**kwargs):
            stream = real_tempfile(**kwargs)
            opened.append(stream)
            return stream

        def replace(source, destination):
            self.assertEqual(order, ["parsed"])
            self.assertEqual(Path(source).parent, self.directory)
            self.assertTrue(opened[0].closed)
            self.assertEqual(Path(source).read_bytes(), self.live)
            fsync.assert_called_once()
            order.append("replaced")
            return real_replace(source, destination)

        with patch.object(self.parser, "_parse_excel_bytes", side_effect=parse), \
             patch("app.parser.tempfile.NamedTemporaryFile", side_effect=temporary), \
             patch("app.parser.os.fsync", wraps=os.fsync) as fsync, \
             patch("app.parser.os.replace", side_effect=replace):
            data = self.parser.parse()
        self.assertEqual(order, ["parsed", "replaced"])
        self.assertEqual(self.excel_path.read_bytes(), self.live)
        self.assertEqual(data["events"][0]["title"], "Live fixture")
        self.assertEqual(data["source"], "Live Realtime Feed")
        freshness = self.assert_freshness(data, "live", "fresh", False)
        self.assertIsNotNone(freshness["last_live_success_at"])
        self.assertIsNone(freshness["fetch_error"])
        self.assertIsNone(freshness["cache_write_error"])

    def test_live_failures_preserve_cache_and_explain_stale_fallback(self):
        failures = (
            (200, b"not an xlsx", None),
            (503, self.live, None),
            (200, b"", None),
            (200, self.workbook_bytes(), None),
            (200, self.workbook_bytes("Unrelated table", headers=False), None),
            (200, self.live, requests.ConnectionError("offline\n" + "x" * 1000)),
        )
        for status, content, error in failures:
            with self.subTest(status=status, content_length=len(content), error=type(error).__name__):
                self.network.side_effect = error
                self.network.return_value = Mock(status_code=status, content=content)
                data = self.parser.parse()
                self.assertEqual(self.excel_path.read_bytes(), self.original)
                self.assertEqual(data["events"][0]["title"], "Cached fixture")
                self.assertEqual(data["source"], "Local Database Cache")
                freshness = self.assert_freshness(data, "cache_fallback", "stale", True)
                self.assertTrue(freshness["fetch_error"])
                self.assertLessEqual(len(freshness["fetch_error"]), 300)
                self.assertNotIn("\n", freshness["fetch_error"])
                self.assertIsNone(freshness["cache_write_error"])
                self.assertIsNone(freshness["last_live_success_at"])

    def test_cache_replace_write_and_fsync_failures_keep_valid_live_result(self):
        real_tempfile = tempfile.NamedTemporaryFile

        def unwritable_temporary(**kwargs):
            stream = real_tempfile(**kwargs)
            stream.write = Mock(side_effect=OSError("write denied"))
            return stream

        failures = (
            patch("app.parser.os.replace", side_effect=OSError("replace denied")),
            patch("app.parser.os.fsync", side_effect=OSError("fsync denied")),
            patch("app.parser.tempfile.NamedTemporaryFile", side_effect=unwritable_temporary),
        )
        for failure in failures:
            with self.subTest(failure=failure.attribute), failure:
                data = self.parser.parse()
                self.assertEqual(self.excel_path.read_bytes(), self.original)
                self.assertEqual(data["source"], "Live Realtime Feed")
                self.assertEqual(data["events"][0]["title"], "Live fixture")
                freshness = self.assert_freshness(data, "live", "degraded", False)
                self.assertIsNotNone(freshness["last_live_success_at"])
                self.assertTrue(freshness["cache_write_error"])
                self.assertIsNone(freshness["fetch_error"])

    def test_explicit_local_read_does_not_claim_a_live_check(self):
        data = self.parser.parse(prefer_live=False)
        self.network.assert_not_called()
        self.assertEqual(self.excel_path.read_bytes(), self.original)
        freshness = self.assert_freshness(data, "local", "local", False)
        self.assertIsNone(freshness["last_live_success_at"])
        self.assertIsNone(freshness["fetch_error"])
        self.assertIsNone(freshness["cache_write_error"])

    def test_live_success_time_survives_later_fallback_and_local_read(self):
        fresh = self.parser.parse()["freshness"]
        self.network.side_effect = requests.ConnectionError("offline")
        fallback = self.parser.parse()["freshness"]
        local = self.parser.parse(prefer_live=False)["freshness"]
        self.assertEqual(fallback["last_live_success_at"], fresh["last_live_success_at"])
        self.assertEqual(local["last_live_success_at"], fresh["last_live_success_at"])
        self.assertIsNone(local["checked_at"])
        self.assertIsNone(FactnewsParser(self.excel_path).parse(False)["freshness"]["last_live_success_at"])

    def test_missing_or_invalid_local_fallback_still_raises(self):
        self.network.side_effect = requests.ConnectionError("offline")
        self.excel_path.unlink()
        with self.assertRaises(FileNotFoundError):
            self.parser.parse()
        self.excel_path.write_bytes(b"invalid local workbook")
        with self.assertRaises(Exception):
            self.parser.parse()
        self.assertEqual(self.excel_path.read_bytes(), b"invalid local workbook")
        self.assertEqual(list(self.directory.iterdir()), [self.excel_path])

    def test_watcher_preserves_status_fields_and_warns_for_stale_or_degraded(self):
        watcher = FactnewsWatcher(self.excel_path)
        existing_fields = {"source", "sync_count", "reload_count", "file_exists", "total_events",
                           "last_sync_time", "sync_interval_seconds", "status", "last_error", "is_syncing"}
        self.network.side_effect = requests.ConnectionError("offline")
        stale = watcher.sync_now()
        status = watcher.get_status()
        self.assertTrue(existing_fields.issubset(status))
        self.assertEqual(status["status"], "warning")
        self.assertEqual(status["last_error"], stale["freshness"]["fetch_error"])
        self.assertEqual(status["freshness"], stale["freshness"])

        self.network.side_effect = None
        fresh = watcher.sync_now()
        self.assertEqual(watcher.get_status()["status"], "online")
        self.assertIsNone(watcher.get_status()["last_error"])
        self.assertEqual(watcher.get_status()["freshness"], fresh["freshness"])

        with patch("app.parser.os.replace", side_effect=OSError("replace denied")):
            degraded = watcher.sync_now()
        self.assertEqual(watcher.get_status()["status"], "warning")
        self.assertEqual(watcher.get_status()["last_error"], degraded["freshness"]["cache_write_error"])
        local = watcher.sync_now(prefer_live=False)
        self.assertEqual(watcher.get_status()["status"], "online")
        self.assertIsNone(watcher.get_status()["last_error"])
        self.assertEqual(watcher.get_status()["freshness"], local["freshness"])


class TestWatcherConcurrency(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.watcher = FactnewsWatcher(Path(temporary.name) / "fixture.xlsx")
        self.data = {"source": "Fixture", "total_count": 5, "last_sync_time": "fixture-time"}
        self.watcher.parser.parse = Mock(return_value=self.data)
        network_patch = patch("requests.get", side_effect=AssertionError("Tests must not use live services"))
        network_patch.start()
        self.addCleanup(network_patch.stop)

    def blocking_parse(self):
        started = threading.Event()
        release = threading.Event()
        self.addCleanup(release.set)

        def parse(prefer_live=True):
            started.set()
            if not release.wait(5):
                raise TimeoutError("Test did not release the blocking parser")
            return self.data

        self.watcher.parser.parse.side_effect = parse
        return started, release

    async def wait_started(self, started):
        self.assertTrue(await asyncio.wait_for(asyncio.to_thread(started.wait, 2), 3))

    async def stop_background(self, task):
        self.watcher.stop()
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)

    async def test_lifespan_performs_one_initial_sync_and_awaits_shutdown(self):
        loop = asyncio.get_running_loop()
        errors = []
        old_handler = loop.get_exception_handler()
        loop.set_exception_handler(lambda loop, context: errors.append(context))
        try:
            with patch.object(app_module, "watcher", self.watcher), \
                 patch.object(app_module, "REALTIME_SYNC_INTERVAL_SECONDS", 3600):
                async with app_module.lifespan(app_module.app):
                    await asyncio.sleep(0)
                    tasks = [task for task in asyncio.all_tasks()
                             if task.get_coro().__name__ == "start_background_watcher"]
                    self.assertEqual(len(tasks), 1)
                    self.assertTrue(self.watcher._is_running)
                    self.watcher.parser.parse.assert_called_once_with(prefer_live=True)
                self.assertTrue(tasks[0].done())
                self.assertTrue(tasks[0].cancelled())
                self.assertFalse(self.watcher._is_running)
                self.assertFalse(self.watcher.get_status()["is_syncing"])
                self.assertEqual(errors, [])
        finally:
            loop.set_exception_handler(old_handler)

    async def test_simultaneous_sync_callers_share_one_completed_result(self):
        started, release = self.blocking_parse()
        callers = [asyncio.create_task(self.watcher.sync_async()) for _ in range(5)]
        try:
            await self.wait_started(started)
            self.assertEqual(self.watcher.parser.parse.call_count, 1)
            self.assertTrue(self.watcher.get_status()["is_syncing"])
        finally:
            release.set()
            results = await asyncio.gather(*callers)
        self.assertTrue(all(result is self.data for result in results))
        self.assertEqual(self.watcher.get_status()["sync_count"], 1)
        self.assertFalse(self.watcher.get_status()["is_syncing"])

    async def test_blocking_parser_does_not_block_independent_event_loop_tick(self):
        started, release = self.blocking_parse()
        sync = asyncio.create_task(self.watcher.sync_async())
        try:
            await self.wait_started(started)
            tick = asyncio.create_task(asyncio.sleep(0, result="tick"))
            self.assertEqual(await asyncio.wait_for(tick, 1), "tick")
            self.assertFalse(sync.done())
            self.assertFalse(release.is_set())
        finally:
            release.set()
            await asyncio.gather(sync, return_exceptions=True)

    async def test_background_and_manual_sync_share_an_inflight_parse(self):
        started, release = self.blocking_parse()
        sleeping = asyncio.Event()
        poll_due = asyncio.Event()
        real_sleep = asyncio.sleep

        async def interval_sleep(seconds):
            self.assertEqual(seconds, 60)
            sleeping.set()
            await poll_due.wait()
            poll_due.clear()

        with patch("app.watcher.asyncio.sleep", new=interval_sleep):
            background = asyncio.create_task(self.watcher.start_background_watcher(60))
            manual = None
            try:
                await asyncio.wait_for(sleeping.wait(), 1)
                self.watcher.parser.parse.assert_not_called()
                manual = asyncio.create_task(self.watcher.sync_async())
                await self.wait_started(started)
                poll_due.set()
                await real_sleep(0)
                self.assertEqual(self.watcher.parser.parse.call_count, 1)
                release.set()
                self.assertIs(await manual, self.data)
            finally:
                release.set()
                if manual is not None:
                    await asyncio.gather(manual, return_exceptions=True)
                await self.stop_background(background)
        self.assertEqual(self.watcher.parser.parse.call_count, 1)
        self.assertTrue(background.done())

    async def test_shutdown_drains_an_inflight_background_sync(self):
        started, release = self.blocking_parse()
        parse = self.watcher.parser.parse.side_effect
        self.watcher.parser.parse.side_effect = lambda **kwargs: (
            self.data if self.watcher.parser.parse.call_count == 1 else parse(**kwargs)
        )
        poll_due = asyncio.Event()
        real_sleep = asyncio.sleep

        async def interval_sleep(seconds):
            await poll_due.wait()
            poll_due.clear()

        with patch.object(app_module, "watcher", self.watcher), \
             patch("app.watcher.asyncio.sleep", new=interval_sleep):
            context = app_module.lifespan(app_module.app)
            await context.__aenter__()
            background = next(task for task in asyncio.all_tasks()
                              if task.get_coro().__name__ == "start_background_watcher")
            shutdown = None
            try:
                poll_due.set()
                await self.wait_started(started)
                shutdown = asyncio.create_task(context.__aexit__(None, None, None))
                await real_sleep(0)
                await real_sleep(0)
                self.assertFalse(shutdown.done())
                self.assertGreater(background.cancelling(), 0)
            finally:
                release.set()
                if shutdown is None:
                    await context.__aexit__(None, None, None)
                else:
                    await asyncio.wait_for(shutdown, 3)
            self.assertTrue(background.done())
            self.assertTrue(background.cancelled())
            self.assertTrue(self.watcher._sync_task.done())
            self.assertFalse(self.watcher._is_running)

    async def test_cancelled_waiter_does_not_cancel_other_sync_callers(self):
        started, release = self.blocking_parse()
        cancelled = asyncio.create_task(self.watcher.sync_async())
        survivor = asyncio.create_task(self.watcher.sync_async())
        try:
            await self.wait_started(started)
            cancelled.cancel()
            await asyncio.sleep(0)
            self.assertFalse(survivor.done())
            self.assertEqual(self.watcher.parser.parse.call_count, 1)
        finally:
            release.set()
            results = await asyncio.gather(cancelled, survivor, return_exceptions=True)
        self.assertIsInstance(results[0], asyncio.CancelledError)
        self.assertIs(results[1], self.data)
        self.assertEqual(self.watcher.parser.parse.call_count, 1)

    async def test_failed_sync_is_shared_and_next_call_can_retry(self):
        self.watcher.parser.parse.side_effect = [ValueError("fixture failure"), self.data]
        results = await asyncio.gather(self.watcher.sync_async(), self.watcher.sync_async(),
                                       return_exceptions=True)
        self.assertTrue(all(isinstance(result, ValueError) for result in results))
        self.assertEqual(self.watcher.parser.parse.call_count, 1)
        self.assertEqual(self.watcher.get_status()["last_error"], "fixture failure")
        self.assertIs(await self.watcher.sync_async(), self.data)
        self.assertEqual(self.watcher.parser.parse.call_count, 2)
        self.assertIsNone(self.watcher.get_status()["last_error"])


if __name__ == "__main__":
    unittest.main()
