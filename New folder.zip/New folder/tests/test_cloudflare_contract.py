"""Path A contracts: fixed streaming Worker and real vendored browser-worker parsing."""
import ast
import base64
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import tomllib
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch
from urllib.parse import parse_qs, urlsplit
import openpyxl

ROOT = Path(__file__).resolve().parent.parent
CF = ROOT / "cloudflare"
NODE = shutil.which("node")
SCRIPT_HASH = "0cb353f830d7288385492c83d277b058ddeac664ca51cf1393aa1fd3e2b70939"
LICENSE_HASH = "4d2a38ac35cda06a555c84074a819d413339cd3691b822cae50f8f322fe01f64"

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class Response:
    def __init__(self, body=None, status=200, headers=None):
        self.body, self.status, self.headers = body, status, headers or {}
    @classmethod
    def json(cls, data, **kwargs):
        result = cls(**kwargs)
        result.data = data
        return result

sdk = ModuleType("workers")
sdk.WorkerEntrypoint, sdk.Response = object, Response
sdk.fetch = AsyncMock(side_effect=AssertionError("Live HTTP forbidden"))
with patch.dict(sys.modules, {"workers": sdk}):
    worker = load_module("cf_worker_contract", CF / "src/worker.py")
build = load_module("cf_build_contract", CF / "build_assets.py")

def fixture():
    import datetime
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Factnews"
    for column, name in enumerate(("Date", "Category", "Description", "Provider", "Source link", "Published at"), 1):
        sheet.cell(7, column, name)
    categories = ("ธุรกิจ", "เศรษฐกิจ", "การเงิน", "การเมือง", "คริปโต")
    for index in range(587):
        values = ("01/11/2026", categories[index % 5], "Title " + str(index) + "\nSummary\nDetail",
                  "Provider", "https://example.test/" + str(index), "2026-11-01T12:00:00+07:00")
        for column, value in enumerate(values, 1):
            sheet.cell(index + 8, column, value)
    sheet.cell(8, 3, '<img src=x onerror="bad">quotes' + chr(96) + chr(39) + "\nSummary\nDetail")
    sheet.cell(8, 5, '=HYPERLINK("https://example.test/canonical?x=1&y=2","Canonical")')
    sheet.cell(9, 5, "Native")
    sheet.cell(9, 5).hyperlink = "https://example.test/native"
    sheet.cell(10, 5, "BBC")
    sheet.cell(11, 5, "Unsafe")
    sheet.cell(11, 5).hyperlink = "javascript:alert(1)"
    sheet.cell(12, 5, "constructor")
    sheet.cell(12, 2, "__proto__")
    sheet.cell(13, 6, None).value = None
    sheet.cell(13, 1, datetime.datetime(2026, 11, 1, 8, 30))
    output = io.BytesIO()
    workbook.save(output)
    workbook.close()
    return output.getvalue()

JS = r"""
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
function parseWorker(buffer,type,extra={}) {
 let answer; const context={ArrayBuffer,Uint8Array,TextDecoder,URL,console};
 context.self=context; context.postMessage=value=>{answer=value;}; vm.createContext(context);
 context.importScripts=path=>vm.runInContext(fs.readFileSync('.'+path,'utf8'),context);
 vm.runInContext(fs.readFileSync('static/js/xlsx-worker.js','utf8'),context);
 context.onmessage({data:{id:1,type,buffer,...extra}}); return answer;
}
function streamed(bytes,declared=bytes.byteLength) {
 let read=false;return {ok:true,headers:{get(){return declared===null?null:String(declared);}},
 body:{getReader(){return {async read(){if(read)return {done:true};read=true;return {done:false,value:bytes};},async cancel(){},releaseLock(){}};}}};
}
function environment() {
 const state={workers:0,terminated:0};
 const context={console,URL,URLSearchParams,AbortController,Uint8Array,ArrayBuffer,TextDecoder,setTimeout,clearTimeout};
 vm.createContext(context);vm.runInContext(fs.readFileSync('static/js/browser-data.js','utf8'),context);
 const factory=()=>{state.workers++;return {postMessage(data,transfer){
 assert.equal(transfer[0],data.buffer);const answer=parseWorker(data.buffer,data.type,data);answer.id=data.id;this.onmessage({data:answer});
 },terminate(){state.terminated++;}};};
 return {context,state,factory};
}
"""

@unittest.skipUnless(NODE, "Node required")
class TestBrowserData(unittest.TestCase):
    def run_js(self, script, content=None):
        prefix = ""
        if content is not None:
            prefix = "const fixture=Uint8Array.from(Buffer.from(" + json.dumps(base64.b64encode(content).decode()) + ",'base64'));"
        result = subprocess.run([NODE], input=JS + prefix + script, cwd=ROOT, text=True, encoding="utf-8", capture_output=True, timeout=40)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_587_row_real_parser_links_thai_dates_categories_and_guards(self):
        self.run_js(r"""
const answer=parseWorker(fixture.buffer,'factnews');assert.equal(answer.error,undefined);
const data=answer.result,byId=Object.fromEntries(data.events.map(event=>[event.id,event]));
assert.equal(data.total_count,587);assert.equal(data.geo_scenarios.length,0);
assert.equal(byId['evt-0001'].source_url,'https://example.test/canonical?x=1&y=2');
assert.equal(byId['evt-0001'].source_name,'Canonical');
assert.ok(byId['evt-0001'].title.includes('<img src=x onerror="bad">'));
assert.equal(byId['evt-0002'].source_url,'https://example.test/native');
assert.equal(byId['evt-0003'].source_url,'https://www.bbc.com/news');
assert.equal(byId['evt-0004'].source_url,'');
assert.ok(byId['evt-0005'].source_url.startsWith('https://www.google.com/search?q='));
assert.equal(data.category_counts['__proto__'],1);
assert.equal(byId['evt-0006'].published_at,'2026-11-01T08:30:00+07:00');
assert.equal(byId['evt-0001'].published_at,'2026-11-01T12:00:00+07:00');
assert.equal(data.freshness.status,'fresh');assert.equal(data.freshness.stale,false);
assert.ok(data.events.every((event,index)=>!index||event.timestamp>=data.events[index-1].timestamp));
assert.match(parseWorker(new ArrayBuffer(0),'factnews').error,/Empty/);
assert.match(parseWorker(new ArrayBuffer(8*1024*1024+1),'factnews').error,/limit/);
assert.match(parseWorker(new ArrayBuffer(1),'unknown').error,/Unknown/);
""", fixture())

    def test_adapter_local_client_fallback_worker_cleanup_and_size_errors(self):
        self.run_js(r"""
(async()=>{
const {context,state,factory}=environment();let fail=false;
const adapter=new context.BrowserDataAdapter(async url=>{assert.equal(url,'/api/raw/events');if(fail)throw Error('offline');return streamed(fixture);},factory);
const local={events:[{id:'local'}]},localPrices={candles:[]};
assert.equal(await adapter.events(local),local);assert.equal(await adapter.prices(localPrices,{}),localPrices);
assert.equal(state.workers,0);
const first=await adapter.events({client_mode:'browser-xlsx-v1'});
assert.equal(first.total_count,587);assert.equal(state.workers,1);assert.equal(state.terminated,1);
fail=true;const fallback=await adapter.events({client_mode:'browser-xlsx-v1'});
assert.equal(fallback.freshness.source_mode,'cache_fallback');assert.equal(fallback.freshness.stale,true);
for(const declared of [8*1024*1024+1,null]) {
 const bytes=declared===null?new Uint8Array(8*1024*1024+1):new Uint8Array(1);
 const oversized=new context.BrowserDataAdapter(async()=>streamed(bytes,declared),factory);
 await assert.rejects(()=>oversized.events({client_mode:'browser-xlsx-v1'}),/limit/);
}
assert.equal(state.workers,1);
let terminated=0;const failed=new context.BrowserDataAdapter(async()=>streamed(new Uint8Array([1])),()=>({postMessage(){this.onerror();},terminate(){terminated++;}}));
await assert.rejects(()=>failed.events({client_mode:'browser-xlsx-v1'}),/worker failed/);assert.equal(terminated,1);
})().catch(error=>{console.error(error);process.exitCode=1;});
""", fixture())

    def test_browser_direct_official_price_url_cors_mapping_and_untrusted_directives(self):
        self.run_js(r"""
(async()=>{
const {context,state,factory}=environment(),HOUR=3600000,BASE=Date.UTC(2026,0,1);
const official='https://data-api.binance.vision/api/v3/klines';let calls=0,fail=false;
const adapter=new context.BrowserDataAdapter(async (url,options)=>{
 calls++;const parsed=new URL(url);
 assert.equal(parsed.origin+parsed.pathname,official);
 assert.equal(options.mode,'cors');assert.equal(options.credentials,'omit');assert.equal(options.redirect,'error');
 assert.equal(options.cache,'no-store');assert.ok(options.signal);
 assert.equal(parsed.searchParams.get('symbol'),'BTCUSDT');assert.equal(parsed.searchParams.get('interval'),'1h');
 assert.equal(parsed.searchParams.get('start_ms'),null);assert.equal(parsed.searchParams.get('end_ms'),null);
 assert.equal(parsed.searchParams.get('limit'),'1000');assert.equal(parsed.searchParams.get('endTime'),String(BASE+1002*HOUR));
 if(fail)throw Error('offline');
 const start=Number(parsed.searchParams.get('startTime')),rows=[];
 for(let stamp=start;stamp<=Math.min(BASE+1002*HOUR,start+999*HOUR);stamp+=HOUR)rows.push([stamp,1,2,0,1,3]);
 return streamed(new TextEncoder().encode(JSON.stringify(rows)));
},factory);
const directive={client_mode:'browser-xlsx-v1',prices_transport:'browser-direct',prices_url:official,raw_prices_url:'/api/raw/prices'};
const query={symbol:'btcusdt',interval:'1h',start_ms:BASE,end_ms:BASE+1002*HOUR};
const result=await adapter.prices(directive,query);assert.equal(result.count,1003);assert.equal(result.freshness.status,'fresh');assert.equal(calls,2);
fail=true;const fallback=await adapter.prices(directive,query);assert.equal(fallback.freshness.source,'cache_fallback');assert.equal(fallback.freshness.stale,true);
const before=calls;
for(const url of ['https://evil.test/api/v3/klines','https://data-api.binance.vision.evil.test/api/v3/klines','http://data-api.binance.vision/api/v3/klines',official+'?url=https://evil.test',official+'#fragment','https://evil.test@data-api.binance.vision/api/v3/klines']) {
 await assert.rejects(()=>adapter.prices({...directive,prices_url:url},query),/Untrusted/);
}
await assert.rejects(()=>adapter.prices({...directive,prices_transport:'arbitrary'},query),/Untrusted/);
assert.equal(calls,before,'Rejected directives must never trigger a fetch');assert.equal(state.workers,state.terminated);
const oversized=new context.BrowserDataAdapter(async()=>streamed(new Uint8Array(1),2*1024*1024+1),factory);
const bounded=await oversized.prices(directive,query);assert.equal(bounded.count,0);assert.match(bounded.freshness.fetch_error,/limit/);
})().catch(error=>{console.error(error);process.exitCode=1;});
""")

    def test_price_pagination_gaps_finite_validation_caps_and_exact_range_fallback(self):
        self.run_js(r"""
(async()=>{
const {context,state,factory}=environment(),HOUR=3600000,BASE=Date.UTC(2026,0,1);let mode='full',calls=0;
const fetcher=async url=>{
 calls++;assert.ok(url.startsWith('/api/raw/prices?'));
 const start=Number(new URL('https://test'+url).searchParams.get('start_ms'));if(mode==='offline')throw Error('offline');
 let rows=[];if(mode==='gap')rows=[[BASE,1,2,0,1,3],[BASE+2*HOUR,1,2,0,1,3]];
 else if(mode==='nan')rows=[[start,1,2,0,'NaN',3]];
 else if(mode==='single')rows=[[start,1,2,0,1,3]];
 else for(let stamp=start;stamp<=Math.min(BASE+1002*HOUR,start+999*HOUR);stamp+=HOUR)rows.push([stamp,1,2,0,1,3]);
 return streamed(new TextEncoder().encode(JSON.stringify(rows)));
};
const adapter=new context.BrowserDataAdapter(fetcher,factory),directive={client_mode:'browser-xlsx-v1'};
const query={symbol:'btcusdt',interval:'1h',start_ms:BASE,end_ms:BASE+1002*HOUR};
const full=await adapter.prices(directive,query);assert.equal(full.count,1003);assert.equal(calls,2);assert.equal(full.freshness.status,'fresh');
mode='offline';const fallback=await adapter.prices(directive,query);assert.equal(fallback.count,1003);assert.equal(fallback.freshness.source,'cache_fallback');
mode='gap';const gap=await adapter.prices(directive,{...query,end_ms:BASE+2*HOUR});assert.equal(gap.freshness.coverage_complete,false);assert.equal(gap.freshness.stale,true);
mode='nan';const nan=await adapter.prices(directive,{...query,end_ms:BASE});assert.equal(nan.count,0);assert.match(nan.freshness.fetch_error,/finite/);
mode='single';calls=0;const bounded=await adapter.prices(directive,{...query,end_ms:BASE+10*HOUR});assert.equal(calls,5);assert.match(bounded.freshness.fetch_error,/limit/);
await assert.rejects(()=>adapter.prices(directive,{...query,interval:'__proto__'}),/Invalid/);
await assert.rejects(()=>adapter.prices(directive,{...query,symbol:'../bad'}),/Invalid/);
assert.equal(state.workers,state.terminated);
})().catch(error=>{console.error(error);process.exitCode=1;});
""")

class TestStreamingWorker(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.http = AsyncMock()
        item = patch.object(worker, "fetch", self.http)
        item.start()
        self.addCleanup(item.stop)
        self.instance = worker.Default()
        self.instance.env = SimpleNamespace(ASSETS=SimpleNamespace(fetch=AsyncMock(return_value="static")))
    async def call(self, path, method="GET"):
        return await self.instance.fetch(SimpleNamespace(url="https://example.test" + path, method=method))
    async def test_directives_status_and_sync_do_not_fetch_or_parse(self):
        for path in ("/api/events", "/api/prices", "/api/status"):
            self.assertEqual((await self.call(path)).data["client_mode"], "browser-xlsx-v1")
        directive = (await self.call("/api/prices")).data
        self.assertEqual(directive["prices_transport"], "browser-direct")
        self.assertEqual(directive["prices_url"], "https://data-api.binance.vision/api/v3/klines")
        self.assertEqual(directive["raw_prices_url"], "/api/raw/prices")
        for path in ("/api/sync", "/api/refresh"):
            self.assertTrue((await self.call(path, "POST")).data["refetch"])
        self.assertEqual(self.http.await_count, 0)
        self.assertEqual((await self.call("/api/sync")).status, 405)
        self.assertEqual((await self.call("/api/nope")).status, 404)
        self.assertEqual(await self.call("/"), "static")
    async def test_fixed_routes_stream_identity_and_query_bounds(self):
        body = object()
        upstream = SimpleNamespace(ok=True, headers={}, body=body, bytes=AsyncMock(side_effect=AssertionError("No reads")),json=AsyncMock(side_effect=AssertionError("No JSON")))
        self.http.return_value = upstream
        self.assertIs((await self.call("/api/raw/events")).body, body)
        self.assertEqual(self.http.await_args.args[0], worker.SHEET_URL)
        self.assertIs((await self.call("/api/raw/prices?symbol=btcusdt&interval=1h&start_ms=1&end_ms=2&limit=1000")).body, body)
        self.assertEqual(worker.BINANCE_URL, "https://data-api.binance.vision/api/v3/klines")
        upstream_url = urlsplit(self.http.await_args.args[0])
        self.assertEqual((upstream_url.scheme, upstream_url.netloc, upstream_url.path),
                         ("https", "data-api.binance.vision", "/api/v3/klines"))
        self.assertEqual(parse_qs(upstream_url.query), {"symbol":["BTCUSDT"], "interval":["1h"],
                         "startTime":["1"], "endTime":["2"], "limit":["1000"]})
        self.assertEqual(worker.MAX_PRICE_BYTES, 2 * 1024 * 1024)
        upstream.bytes.assert_not_awaited(); upstream.json.assert_not_awaited()
        count = self.http.await_count
        for query in ("url=https://evil.test", "limit=1001", "symbol=../bad", "interval=bad", "start_ms=2&end_ms=1", "symbol=A&symbol=B", "x="+"a"*520):
            self.assertEqual((await self.call("/api/raw/prices?"+query)).status, 400)
        self.assertEqual((await self.call("/api/raw/events?url=https://evil.test")).status, 400)
        self.assertEqual(count, self.http.await_count)
    async def test_size_http_and_network_errors_are_non_leaky(self):
        self.http.return_value = SimpleNamespace(ok=True, headers={"content-length":str(8*1024*1024+1)}, body=object())
        self.assertEqual((await self.call("/api/raw/events")).status, 413)
        self.http.return_value = SimpleNamespace(ok=True, headers={"content-length":str(2*1024*1024+1)}, body=object())
        self.assertEqual((await self.call("/api/raw/prices")).status, 413)
        self.http.return_value = SimpleNamespace(ok=False)
        self.assertEqual((await self.call("/api/raw/events")).status, 502)
        self.http.side_effect = RuntimeError("sensitive upstream detail")
        response = await self.call("/api/raw/events")
        self.assertEqual(response.status, 502)
        self.assertNotIn("sensitive", json.dumps(response.data))

class TestBuildAndIntegrity(unittest.TestCase):
    def test_pinned_vendor_license_dependencies_and_no_server_parser(self):
        config = json.loads((CF/"wrangler.jsonc").read_text())
        self.assertEqual(config["compatibility_date"], "2026-10-30")
        # Plain npx Wrangler does not vendor the external Python SDK; use workerd's built-in SDK.
        self.assertEqual(config["compatibility_flags"], ["python_workers", "disable_python_external_sdk"])
        self.assertEqual(config["assets"]["run_worker_first"], ["/api/*"])
        self.assertEqual(tomllib.loads((CF/"pyproject.toml").read_text())["project"]["dependencies"], [])
        self.assertEqual(hashlib.sha256((ROOT/"static/vendor/sheetjs/xlsx.mini.min.js").read_bytes()).hexdigest(), SCRIPT_HASH)
        self.assertEqual(hashlib.sha256((ROOT/"static/vendor/sheetjs/LICENSE").read_bytes()).hexdigest(), LICENSE_HASH)
        self.assertIn("Apache License", (ROOT/"static/vendor/sheetjs/LICENSE").read_text())
        tree = ast.parse((CF/"src/worker.py").read_text())
        modules = [node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
        modules += [alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names]
        self.assertFalse(any(name and name.split('.')[0] in {"openpyxl","factnews","prices","requests","threading","json"} for name in modules))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                self.assertNotIn(node.func.attr, {"bytes","text","arrayBuffer"})
                if node.func.attr == "json":
                    self.assertIsInstance(node.func.value, ast.Name)
                    self.assertEqual(node.func.value.id, "Response")
    def test_allowlist_contains_parser_license_and_excludes_private_inputs(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, output = root/"static", root/"public"
            for name in build.ASSETS:
                path = source/name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b'<html data-enable-geo="false">' if name=="index.html" else b"approved asset")
            for name in (".env","private.xlsx","cache.json","app.py","tests.py"):
                (source/name).write_text("synthetic excluded fixture")
            expected = build.build_assets(source,output)
            actual = sorted(path.relative_to(output).as_posix() for path in output.rglob("*") if path.is_file())
            self.assertEqual(actual,expected); self.assertEqual(len(actual),19)
            for name in ("js/browser-data.js","js/xlsx-worker.js","vendor/sheetjs/LICENSE","vendor/sheetjs/xlsx.mini.min.js"):
                self.assertIn("static/"+name,actual)
            self.assertFalse(any(path.endswith((".xlsx",".env",".py","cache.json")) for path in actual))
            (output/"unrelated.txt").write_text("preserve")
            with self.assertRaises(ValueError): build.build_assets(source,output)

if __name__ == "__main__":
    unittest.main()
