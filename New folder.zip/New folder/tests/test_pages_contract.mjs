import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import worker, { handleRequest } from '../cloudflare/pages/worker.mjs';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const pages = join(root, 'cloudflare', 'pages');
const mode = 'browser-xlsx-v1';
const sheet = 'https://docs.google.com/spreadsheets/d/1JOknhrZ5PPLsOOIIS55sfaUiRAsCvYdy3tFLr1H7CG8/export?format=xlsx';
const binance = 'https://data-api.binance.vision/api/v3/klines';
const request = (path, method = 'GET') => new Request(`https://writetime.pages.dev${path}`, { method });
const noNetwork = () => { throw new Error('Unexpected network'); };
const noAssets = { ASSETS: { fetch() { throw new Error('API must not fall back to HTML'); } } };

test('client directives preserve browser news, direct prices, sync and full status contracts without fetching', async () => {
    const response = await handleRequest(request('/api/status'), noAssets, noNetwork);
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), {
        status: 'client', client_mode: mode, sync_mode: 'browser', source: 'Public Factnews / browser parsing',
        sync_count: null, reload_count: null, file_exists: false, total_events: null, last_sync_time: null,
        sync_interval_seconds: null, is_syncing: false, last_error: null,
    });
    assert.deepEqual(await (await handleRequest(request('/api/events'), noAssets, noNetwork)).json(), { client_mode: mode, raw_events_url: '/api/raw/events' });
    assert.deepEqual(await (await handleRequest(request('/api/prices?symbol=btcusdt&interval=1h&start_ms=0&end_ms=1000&limit=5'), noAssets, noNetwork)).json(), {
        client_mode: mode, prices_transport: 'browser-direct', prices_url: binance, raw_prices_url: '/api/raw/prices',
    });
    for (const path of ['/api/sync', '/api/refresh']) {
        assert.deepEqual(await (await handleRequest(request(path, 'POST'), noAssets, noNetwork)).json(), {
            status: 'success', client_mode: mode, refetch: true, message: 'Browser must refetch public data',
        });
    }
});

test('every known route rejects wrong methods, unknown API routes stay JSON, static fallback remains separate', async () => {
    for (const [path, allowed] of [['/api/status', 'GET'], ['/api/events', 'GET'], ['/api/prices', 'GET'], ['/api/raw/events', 'GET'], ['/api/raw/prices', 'GET'], ['/api/sync', 'POST'], ['/api/refresh', 'POST']]) {
        const response = await handleRequest(request(path, allowed === 'GET' ? 'POST' : 'GET'), noAssets, noNetwork);
        assert.equal(response.status, 405);
        assert.equal(response.headers.get('Allow'), allowed);
        assert.deepEqual(await response.json(), { detail: 'Method Not Allowed' });
    }
    for (const path of ['/api', '/api/', '/api/missing', '/api/static/index.html', '/api/events/']) {
        const response = await handleRequest(request(path), noAssets, noNetwork);
        assert.equal(response.status, 404);
        assert.deepEqual(await response.json(), { detail: 'Not Found' });
    }
    for (const path of ['/', '/static/js/app.js', '/missing', '/apiary']) {
        let seen;
        const response = await handleRequest(request(path), { ASSETS: { fetch(req) { seen = req; return new Response('asset miss', { status: 404 }); } } }, noNetwork);
        assert.equal(new URL(seen.url).pathname, path);
        assert.equal(response.status, 404);
        assert.equal(await response.text(), 'asset miss');
    }
});

test('price validation rejects malformed, duplicate, unsafe and out-of-bound parameters before network work', async () => {
    const invalid = ['url=https://evil.test', 'symbol=BTCUSDT&symbol=ETHUSDT', 'sym%62ol=BTCUSDT&symbol=ETHUSDT', 'symbol=', 'symbol=BTC/USDT', 'symbol=' + 'A'.repeat(31), 'interval=bad', 'interval=1h&interval=1h', 'limit=', 'limit=0', 'limit=1001', 'limit=1.5', 'limit=1e2', 'limit=NaN', 'limit=%', 'start_ms=-1', 'start_ms=253402300800000', 'end_ms=Infinity', 'start_ms=2&end_ms=1', 'startTime=0', 'endTime=1', 'limit=1&limit=2', 'symbol=' + 'A'.repeat(513)];
    for (const path of ['/api/prices', '/api/raw/prices']) {
        for (const query of invalid) {
            const response = await handleRequest(request(`${path}?${query}`), noAssets, noNetwork);
            assert.equal(response.status, 400, `${path}?${query}`);
            assert.deepEqual(await response.json(), { detail: 'Invalid bounded query' });
        }
    }
    for (const [path, method] of [['/api/events', 'GET'], ['/api/status', 'GET'], ['/api/raw/events', 'GET'], ['/api/sync', 'POST'], ['/api/refresh', 'POST']]) {
        const response = await handleRequest(request(`${path}?unexpected=1`, method), noAssets, noNetwork);
        assert.equal(response.status, 400);
    }
});

test('fixed raw proxies preserve streaming bodies, MIME, cache semantics and exact Binance parameter mapping', async () => {
    for (const [path, target, mime] of [
        ['/api/raw/events', sheet, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
        ['/api/raw/prices?symbol=ethusdt&interval=1M&start_ms=0&end_ms=253402300799999&limit=1', `${binance}?symbol=ETHUSDT&interval=1M&limit=1&startTime=0&endTime=253402300799999`, 'application/json'],
        ['/api/raw/prices', `${binance}?symbol=BTCUSDT&interval=1h&limit=1000`, 'application/json'],
    ]) {
        const upstream = new Response('raw upstream bytes', { headers: { 'content-length': '18', 'set-cookie': 'must not forward' } });
        const body = upstream.body;
        upstream.json = upstream.text = upstream.arrayBuffer = () => { throw new Error('Server body parsing forbidden'); };
        const response = await handleRequest(request(path), noAssets, async url => { assert.equal(url, target); return upstream; });
        assert.equal(response.status, 200);
        assert.equal(response.body, body);
        assert.equal(response.headers.get('Content-Type'), mime);
        assert.equal(response.headers.get('Cache-Control'), 'no-store');
        assert.equal(response.headers.get('set-cookie'), null);
        assert.equal(await response.text(), 'raw upstream bytes');
    }
});

test('declared raw size caps and upstream errors return bounded non-leaky JSON', async () => {
    for (const [path, cap] of [['/api/raw/events', 8 * 1024 * 1024], ['/api/raw/prices', 2 * 1024 * 1024]]) {
        const atCap = await handleRequest(request(path), noAssets, async () => new Response('ok', { headers: { 'content-length': String(cap) } }));
        assert.equal(atCap.status, 200);
        const tooLarge = await handleRequest(request(path), noAssets, async () => new Response('too large', { headers: { 'content-length': String(cap + 1) } }));
        assert.equal(tooLarge.status, 413);
        assert.deepEqual(await tooLarge.json(), { detail: 'Upstream body exceeds size limit' });
        for (const fetcher of [async () => { throw new Error('private upstream detail'); }, async () => new Response('private upstream detail', { status: 403 }), async () => new Response('private detail', { headers: { 'content-length': 'bad' } })]) {
            const response = await handleRequest(request(path), noAssets, fetcher);
            assert.equal(response.status, 502);
            assert.deepEqual(await response.json(), { detail: 'Upstream unavailable' });
        }
    }
});

test('Pages default entrypoint ignores execution context as a fetcher argument', async () => {
    const original = globalThis.fetch;
    try {
        globalThis.fetch = async url => { assert.equal(url, sheet); return new Response('xlsx bytes'); };
        const response = await worker.fetch(request('/api/raw/events'), noAssets, { waitUntil() { throw new Error('No background work'); } });
        assert.equal(response.status, 200);
        assert.equal(await response.text(), 'xlsx bytes');
    } finally { globalThis.fetch = original; }
});

test('Pages config and routing are isolated from Python Worker and old deployment host', () => {
    assert.deepEqual(JSON.parse(readFileSync(join(pages, 'wrangler.jsonc'), 'utf8')), { name: 'writetime', pages_build_output_dir: './public', compatibility_date: '2026-10-30' });
    assert.deepEqual(JSON.parse(readFileSync(join(pages, '_routes.json'), 'utf8')), { version: 1, include: ['/api', '/api/*'], exclude: [] });
    const source = readFileSync(join(pages, 'worker.mjs'), 'utf8');
    assert.doesNotMatch(source, /workers\.dev|openpyxl|XLSX|JSON\.parse|setInterval|waitUntil\(/);
    assert.match(source, /env\.ASSETS\.fetch\(request\)/);
});

test('build is idempotent and stages only unchanged 19 approved assets plus exact Pages controls', () => {
    const script = 'cloudflare/pages/build_pages.py';
    for (let i = 0; i < 2; i++) {
        const result = spawnSync('python', ['-B', script], { cwd: root, encoding: 'utf8' });
        assert.equal(result.status, 0, result.stderr);
        assert.match(result.stdout, /Staged 21 Pages files/);
    }
    const output = join(pages, 'public');
    const files = directory => readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
        assert.equal(entry.isSymbolicLink(), false);
        return entry.isDirectory() ? files(join(directory, entry.name)) : [join(directory, entry.name)];
    });
    const actual = files(output).map(path => relative(output, path).replaceAll('\\', '/')).sort();
    const assetResult = spawnSync('python', ['-B', '-c', 'import json,runpy; print(json.dumps(runpy.run_path("cloudflare/build_assets.py")["ASSETS"]))'], { cwd: root, encoding: 'utf8' });
    assert.equal(assetResult.status, 0, assetResult.stderr);
    const assets = JSON.parse(assetResult.stdout);
    assert.equal(assets.length, 19);
    const expected = [...assets.map(name => name === 'index.html' ? name : `static/${name}`), '_worker.js', '_routes.json'].sort();
    assert.deepEqual(actual, expected);
    for (const name of assets) assert.deepEqual(readFileSync(join(output, name === 'index.html' ? name : `static/${name}`)), readFileSync(join(root, 'static', name)));
    assert.deepEqual(readFileSync(join(output, '_worker.js')), readFileSync(join(pages, 'worker.mjs')));
    assert.deepEqual(readFileSync(join(output, '_routes.json')), readFileSync(join(pages, '_routes.json')));
    assert.match(readFileSync(join(output, 'index.html'), 'utf8'), /<html\b[^>]*\bdata-enable-geo="true"/);
    assert.ok(actual.every(name => !/\.xlsx$|\.env|cache|(^|\/)tests\/|(^|\/)app\//i.test(name)));
});
