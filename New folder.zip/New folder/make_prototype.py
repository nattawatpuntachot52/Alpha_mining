import json, os

artifact_dir = r"C:\Users\admin\.gemini\antigravity\brain\a8ea452c-ad6b-4a73-9204-892b7273b394"
os.makedirs(artifact_dir, exist_ok=True)
output_html_path = os.path.join(artifact_dir, "factnews_dashboard_prototype.html")

with open("parsed_factnews.json", "r", encoding="utf-8") as f_in:
    events = json.load(f_in)

events_sorted = sorted(events, key=lambda x: x["published_at"])
events_json = json.dumps(events_sorted, ensure_ascii=False)

html_template = f'''<!DOCTYPE html>
<html lang="th" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Factnews Event-Driven Radar</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {{
      font-family: 'Prompt', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background-color: #0b0f17;
      color: #e2e8f0;
      user-select: none;
    }}
    .font-mono {{
      font-family: 'JetBrains Mono', monospace;
    }}
    ::-webkit-scrollbar {{
      width: 6px;
      height: 6px;
    }}
    ::-webkit-scrollbar-track {{
      background: #111827;
    }}
    ::-webkit-scrollbar-thumb {{
      background: #374151;
      border-radius: 3px;
    }}
    ::-webkit-scrollbar-thumb:hover {{
      background: #4b5563;
    }}
    .timeline-canvas-container {{
      position: relative;
      background: radial-gradient(circle at 50% 20%, #151e2e 0%, #0b0f17 100%);
    }}
    .glass-panel {{
      background: rgba(17, 24, 39, 0.85);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(55, 65, 81, 0.5);
    }}
    .badge-pill {{
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }}
    .badge-pill:hover {{
      transform: translateY(-1px);
    }}
    .event-card {{
      transition: all 0.18s ease-in-out;
    }}
    .event-card:hover {{
      transform: translateY(-2px);
      box-shadow: 0 8px 24px -4px rgba(0, 0, 0, 0.5);
    }}
    .slider-thumb {{
      cursor: grab;
    }}
    .slider-thumb:active {{
      cursor: grabbing;
    }}
  </style>
</head>
<body class="min-h-screen flex flex-col bg-[#0b0f17] text-slate-100 antialiased selection:bg-amber-500 selection:text-black">

  <!-- TOP HEADER -->
  <header class="border-b border-slate-800 bg-[#0f172a]/90 backdrop-blur sticky top-0 z-40 px-6 py-3.5">
    <div class="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
      
      <!-- Brand & Status -->
      <div class="flex items-center gap-3.5">
        <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-500 flex items-center justify-center shadow-lg shadow-amber-500/20 text-white font-bold text-xl">
          ⚡
        </div>
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-lg md:text-xl font-bold tracking-tight text-white flex items-center gap-2">
              Factnews Event Radar <span class="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-medium">New Design</span>
            </h1>
          </div>
          <p class="text-xs text-slate-400 flex items-center gap-2">
            <span>ฐานข้อมูลข่าวสาร 60 นาที (Factnews.xlsx)</span>
            <span class="w-1 h-1 rounded-full bg-slate-600"></span>
            <span class="text-emerald-400 font-mono flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> ตรวจล่าสุด: 29 ต.ค. 2026, 17:03 น.
            </span>
          </p>
        </div>
      </div>

      <!-- Live Search & Global Stats -->
      <div class="flex items-center gap-3 w-full md:w-auto">
        <div class="relative flex-1 md:w-72">
          <input 
            type="text" 
            id="searchInput" 
            placeholder="ค้นหาข่าว (เช่น ดอกเบี้ย, ECB, Shell, จีน)..." 
            class="w-full bg-slate-900/90 text-sm border border-slate-700/80 rounded-lg pl-9 pr-8 py-2 text-slate-100 placeholder-slate-400 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition"
          >
          <span class="absolute left-3 top-2.5 text-slate-400 text-sm">🔍</span>
          <button id="clearSearchBtn" class="hidden absolute right-2.5 top-2.5 text-slate-400 hover:text-white text-xs">✕</button>
        </div>
        
        <!-- Quick Stats Pill -->
        <div class="hidden lg:flex items-center gap-2 bg-slate-800/80 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-300">
          <span class="font-mono text-amber-400 font-bold" id="totalCountBadge">540</span> ข่าว
          <span class="text-slate-500">|</span>
          <span class="font-mono text-cyan-400 font-bold" id="visibleCountBadge">540</span> แสดงอยู่
        </div>
      </div>

    </div>
  </header>

  <!-- MAIN DASHBOARD CONTENT -->
  <main class="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col gap-5">

    <!-- KPI / CATEGORY SUMMARY CARDS -->
    <section class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
      <!-- Card: All -->
      <div class="glass-panel p-3.5 rounded-xl border border-slate-800 flex flex-col justify-between hover:border-slate-700 transition cursor-pointer" onclick="resetFilters()">
        <span class="text-xs text-slate-400 font-medium">ภาพรวมข่าวทั้งหมด</span>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-2xl font-bold font-mono text-white">540</span>
          <span class="text-[11px] text-slate-400">22 วัน</span>
        </div>
        <div class="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
          <div class="bg-gradient-to-r from-amber-400 to-rose-400 h-full w-full"></div>
        </div>
      </div>

      <!-- Card: ธุรกิจ -->
      <div class="glass-panel p-3.5 rounded-xl border border-emerald-500/20 bg-emerald-950/10 flex flex-col justify-between hover:border-emerald-500/40 transition cursor-pointer" onclick="toggleOnlyCategory('ธุรกิจ')">
        <div class="flex items-center justify-between">
          <span class="text-xs font-semibold text-emerald-400">🏢 ธุรกิจ</span>
          <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
        </div>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-2xl font-bold font-mono text-white">158</span>
          <span class="text-[11px] text-emerald-300/70">29.3%</span>
        </div>
        <div class="w-full bg-emerald-950 h-1 rounded-full mt-2 overflow-hidden">
          <div class="bg-emerald-400 h-full" style="width: 29.3%"></div>
        </div>
      </div>

      <!-- Card: เศรษฐกิจ -->
      <div class="glass-panel p-3.5 rounded-xl border border-sky-500/20 bg-sky-950/10 flex flex-col justify-between hover:border-sky-500/40 transition cursor-pointer" onclick="toggleOnlyCategory('เศรษฐกิจ')">
        <div class="flex items-center justify-between">
          <span class="text-xs font-semibold text-sky-400">🌐 เศรษฐกิจ</span>
          <span class="w-2 h-2 rounded-full bg-sky-400"></span>
        </div>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-2xl font-bold font-mono text-white">108</span>
          <span class="text-[11px] text-sky-300/70">20.0%</span>
        </div>
        <div class="w-full bg-sky-950 h-1 rounded-full mt-2 overflow-hidden">
          <div class="bg-sky-400 h-full" style="width: 20%"></div>
        </div>
      </div>

      <!-- Card: การเงิน -->
      <div class="glass-panel p-3.5 rounded-xl border border-amber-500/20 bg-amber-950/10 flex flex-col justify-between hover:border-amber-500/40 transition cursor-pointer" onclick="toggleOnlyCategory('การเงิน')">
        <div class="flex items-center justify-between">
          <span class="text-xs font-semibold text-amber-400">💰 การเงิน</span>
          <span class="w-2 h-2 rounded-full bg-amber-400"></span>
        </div>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-2xl font-bold font-mono text-white">94</span>
          <span class="text-[11px] text-amber-300/70">17.4%</span>
        </div>
        <div class="w-full bg-amber-950 h-1 rounded-full mt-2 overflow-hidden">
          <div class="bg-amber-400 h-full" style="width: 17.4%"></div>
        </div>
      </div>

      <!-- Card: การเมือง -->
      <div class="glass-panel p-3.5 rounded-xl border border-rose-500/20 bg-rose-950/10 flex flex-col justify-between hover:border-rose-500/40 transition cursor-pointer" onclick="toggleOnlyCategory('การเมือง')">
        <div class="flex items-center justify-between">
          <span class="text-xs font-semibold text-rose-400">🏛️ การเมือง</span>
          <span class="w-2 h-2 rounded-full bg-rose-400"></span>
        </div>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-2xl font-bold font-mono text-white">93</span>
          <span class="text-[11px] text-rose-300/70">17.2%</span>
        </div>
        <div class="w-full bg-rose-950 h-1 rounded-full mt-2 overflow-hidden">
          <div class="bg-rose-400 h-full" style="width: 17.2%"></div>
        </div>
      </div>

      <!-- Card: คริปโต -->
      <div class="glass-panel p-3.5 rounded-xl border border-purple-500/20 bg-purple-950/10 flex flex-col justify-between hover:border-purple-500/40 transition cursor-pointer" onclick="toggleOnlyCategory('คริปโต')">
        <div class="flex items-center justify-between">
          <span class="text-xs font-semibold text-purple-400">🪙 คริปโต</span>
          <span class="w-2 h-2 rounded-full bg-purple-400"></span>
        </div>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-2xl font-bold font-mono text-white">87</span>
          <span class="text-[11px] text-purple-300/70">16.1%</span>
        </div>
        <div class="w-full bg-purple-950 h-1 rounded-full mt-2 overflow-hidden">
          <div class="bg-purple-400 h-full" style="width: 16.1%"></div>
        </div>
      </div>
    </section>

    <!-- INTERACTIVE CONTROL TOOLBAR -->
    <section class="glass-panel p-4 rounded-xl border border-slate-800 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
      
      <!-- Time Presets -->
      <div class="flex flex-wrap items-center gap-2">
        <span class="text-xs font-semibold text-slate-400 uppercase tracking-wider mr-1">ช่วงเวลา:</span>
        <button onclick="setZoomPreset(24)" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition" data-hours="24">
          24 ชั่วโมง
        </button>
        <button onclick="setZoomPreset(72)" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition" data-hours="72">
          3 วัน
        </button>
        <button onclick="setZoomPreset(168)" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-500/20 text-amber-300 border border-amber-500/30 transition active" data-hours="168">
          7 วัน (ค่าเริ่มต้น)
        </button>
        <button onclick="setZoomPreset(336)" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition" data-hours="336">
          14 วัน
        </button>
        <button onclick="setZoomPreset(0)" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition" data-hours="0">
          ทั้งหมด (22 วัน)
        </button>
      </div>

      <!-- Category Filter Chips -->
      <div class="flex flex-wrap items-center gap-2" id="categoryChipsContainer">
        <!-- Rendered by JS -->
      </div>

      <!-- Zoom In / Out & Reset -->
      <div class="flex items-center gap-2 border-t lg:border-t-0 pt-2 lg:pt-0 border-slate-800 justify-end">
        <button onclick="zoomStep(0.7)" title="ซูมเข้า (Zoom In)" class="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center font-bold text-base transition">
          +
        </button>
        <button onclick="zoomStep(1.4)" title="ซูมออก (Zoom Out)" class="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center font-bold text-base transition">
          −
        </button>
        <button onclick="resetTimelineView()" title="รีเซ็ตมุมมอง" class="px-2.5 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1 transition">
          <span>↺</span> รีเซ็ต
        </button>
      </div>

    </section>

    <!-- TIMELINE & EVENT EXPLORER CONTAINER -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
      
      <!-- LEFT 8 COLS: INTERACTIVE TIMELINE & NAVIGATION -->
      <div class="lg:col-span-8 flex flex-col gap-4">
        
        <!-- MAIN TIMELINE CANVAS CARD -->
        <div class="glass-panel rounded-2xl border border-slate-800 overflow-hidden shadow-2xl relative">
          
          <!-- Timeline Header / Instructions -->
          <div class="px-5 py-3 border-b border-slate-800 flex items-center justify-between bg-slate-900/50 text-xs text-slate-400">
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-amber-400"></span>
              <span class="font-medium text-slate-200">Interactive Event Timeline (แยกหมวดหมู่เป็น 5 เลน)</span>
            </div>
            <div class="flex items-center gap-3">
              <span class="hidden sm:inline">💡 ลากเพื่อเลื่อนแกนเวลา | หมุนลูกกลิ้งเมาส์เพื่อซูมเข้า-ออก</span>
              <span class="font-mono text-amber-300 font-semibold" id="currentVisibleWindowLabel">--</span>
            </div>
          </div>

          <!-- Main Timeline Canvas -->
          <div class="timeline-canvas-container relative w-full h-[380px] cursor-grab active:cursor-grabbing" id="timelineContainer">
            <canvas id="timelineCanvas" class="w-full h-full block"></canvas>
            
            <!-- Tooltip Popup -->
            <div id="timelineTooltip" class="absolute hidden pointer-events-none z-50 glass-panel p-3.5 rounded-xl border border-slate-600 shadow-2xl max-w-sm transition-opacity duration-150">
              <div class="flex items-center gap-2 mb-1.5">
                <span id="tooltipCategoryBadge" class="text-[11px] font-semibold px-2 py-0.5 rounded-full">--</span>
                <span id="tooltipTime" class="text-[11px] font-mono text-slate-400">--</span>
                <span id="tooltipProvider" class="text-[10px] text-slate-500 ml-auto font-mono">--</span>
              </div>
              <h4 id="tooltipTitle" class="text-sm font-bold text-white leading-snug mb-1">--</h4>
              <p id="tooltipSnippet" class="text-xs text-slate-300 line-clamp-2 leading-relaxed">--</p>
              <div class="mt-2 text-[10px] text-amber-400 font-medium flex items-center gap-1">
                <span>👆 คลิกเพื่อเปิดอ่านรายละเอียดฉบับเต็ม</span>
              </div>
            </div>

          </div>

          <!-- MINI-MAP NAVIGATOR (RANGE SLIDER / BRUSH) -->
          <div class="p-4 border-t border-slate-800 bg-slate-950/70 flex flex-col gap-2">
            <div class="flex items-center justify-between text-xs text-slate-400">
              <span class="font-medium flex items-center gap-1.5">
                <span>🗺️ แถบเลื่อนพาโนรามาทั้งเดือน (Mini-map Panorama - 22 วัน)</span>
              </span>
              <span class="font-mono text-[11px] text-slate-400" id="minimapRangeLabel">8 ต.ค. - 29 ต.ค. 2026</span>
            </div>
            
            <!-- Minimap Canvas with Highlight Overlay -->
            <div class="relative w-full h-14 bg-slate-900 rounded-lg border border-slate-800 overflow-hidden cursor-pointer" id="minimapContainer">
              <canvas id="minimapCanvas" class="w-full h-full block"></canvas>
              
              <!-- Draggable Viewport Highlight Window -->
              <div id="minimapViewport" class="absolute top-0 bottom-0 border-2 border-amber-400 bg-amber-500/20 backdrop-blur-[1px] rounded transition-none slider-thumb">
                <div class="absolute left-0 top-0 bottom-0 w-2.5 bg-amber-400/80 cursor-ew-resize hover:bg-amber-300" id="handleLeft"></div>
                <div class="absolute right-0 top-0 bottom-0 w-2.5 bg-amber-400/80 cursor-ew-resize hover:bg-amber-300" id="handleRight"></div>
                <div class="w-full h-full flex items-center justify-center pointer-events-none opacity-40 text-amber-200 text-xs">
                  ↔
                </div>
              </div>
            </div>
          </div>

        </div>

        <!-- QUICK COMPARISON NOTE -->
        <div class="glass-panel p-4 rounded-xl border border-slate-800 text-xs text-slate-400 flex items-start gap-3">
          <div class="text-lg">✨</div>
          <div class="leading-relaxed">
            <span class="text-slate-200 font-semibold">แก้ปัญหาจากเวอร์ชันเดิม:</span> 
            เวอร์ชันเดิมนำตัวหนังสือมาซ้อนทับกันบนกราฟราคาจนอ่านไม่ออกเมื่อมีข่าวหนาแน่น — ในเวอร์ชันใหม่นี้แยกเป็น <span class="text-amber-400">5 เลนหมวดหมู่ (Swimlanes)</span> พร้อมการจัดสเกลอัตโนมัติ (Collision Avoidance), รองรับการซูมแบบละเอียดระดับชั่วโมง, และมีฟีดขวาที่กรองเฉพาะข่าวในช่วงเวลานั้นให้อ่านอย่างสบายตา
          </div>
        </div>

      </div>

      <!-- RIGHT 4 COLS: SYNCHRONIZED REAL-TIME EVENT FEED -->
      <div class="lg:col-span-4 flex flex-col gap-3">
        
        <!-- Feed Card Header -->
        <div class="glass-panel px-4 py-3 rounded-xl border border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <h3 class="font-bold text-sm text-white">ฟีดข่าวในช่วงเวลาที่เลือก</h3>
          </div>
          <span class="text-xs font-mono px-2 py-0.5 rounded-md bg-slate-800 text-amber-400 border border-slate-700" id="feedCounterBadge">
            0 ข่าว
          </span>
        </div>

        <!-- Feed List Scrollable Container -->
        <div class="flex flex-col gap-2.5 max-h-[580px] overflow-y-auto pr-1" id="eventsFeedList">
          <!-- Dynamically populated cards -->
        </div>

      </div>

    </div>

  </main>

  <!-- EVENT DETAIL MODAL DIALOG -->
  <div id="eventDetailModal" class="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="glass-panel bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative flex flex-col gap-4 animate-in fade-in zoom-in-95 duration-150">
      
      <!-- Close button -->
      <button onclick="closeDetailModal()" class="absolute right-4 top-4 w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-sm transition">
        ✕
      </button>

      <!-- Modal Category & Time Tag -->
      <div class="flex flex-wrap items-center gap-2">
        <span id="modalCategoryBadge" class="text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
          หมวดหมู่
        </span>
        <span id="modalTime" class="text-xs font-mono text-slate-400 flex items-center gap-1">
          🕒 29 ต.ค. 2026, 17:03:00 น.
        </span>
        <span id="modalProvider" class="text-xs font-mono text-slate-500 ml-auto bg-slate-800 px-2.5 py-0.5 rounded border border-slate-700">
          Source: CNBC
        </span>
      </div>

      <!-- Headline -->
      <h2 id="modalTitle" class="text-xl font-bold text-white leading-snug">
        หัวข้อข่าวรายละเอียด
      </h2>

      <!-- Content Summary & Details -->
      <div class="bg-slate-950/60 p-4 rounded-xl border border-slate-800 text-slate-200 text-sm leading-relaxed space-y-3">
        <p id="modalSummary" class="text-slate-100 font-medium leading-relaxed"></p>
        <p id="modalDetails" class="text-slate-300 leading-relaxed"></p>
      </div>

      <!-- Footer Info -->
      <div class="flex items-center justify-between text-xs text-slate-400 border-t border-slate-800 pt-3">
        <div class="flex items-center gap-2">
          <span>แหล่งที่มา:</span>
          <span id="modalSourceLink" class="text-amber-400 font-medium">Factnews Feed</span>
        </div>
        <button onclick="closeDetailModal()" class="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition">
          ปิดหน้าต่าง
        </button>
      </div>

    </div>
  </div>

  <!-- EMBEDDED JAVASCRIPT ENGINE -->
  <script>
    // DATA SOURCE
    const RAW_EVENTS = {events_json};

    // CATEGORY THEME CONFIG
    const CATEGORIES = {{
      'ธุรกิจ': {{ color: '#34d399', bg: 'rgba(52, 211, 153, 0.15)', border: 'rgba(52, 211, 153, 0.4)', icon: '🏢', label: 'ธุรกิจ' }},
      'เศรษฐกิจ': {{ color: '#38bdf8', bg: 'rgba(56, 189, 248, 0.15)', border: 'rgba(56, 189, 248, 0.4)', icon: '🌐', label: 'เศรษฐกิจ' }},
      'การเงิน': {{ color: '#fbbf24', bg: 'rgba(251, 191, 36, 0.15)', border: 'rgba(251, 191, 36, 0.4)', icon: '💰', label: 'การเงิน' }},
      'การเมือง': {{ color: '#f87171', bg: 'rgba(248, 113, 113, 0.15)', border: 'rgba(248, 113, 113, 0.4)', icon: '🏛️', label: 'การเมือง' }},
      'คริปโต': {{ color: '#c084fc', bg: 'rgba(192, 132, 252, 0.15)', border: 'rgba(192, 132, 252, 0.4)', icon: '🪙', label: 'คริปโต' }}
    }};

    const CATEGORY_NAMES = Object.keys(CATEGORIES);

    // STATE
    let allEvents = [];
    let activeCategories = new Set(CATEGORY_NAMES);
    let searchQuery = '';
    let minTime = 0;
    let maxTime = 0;
    let viewStart = 0;
    let viewEnd = 0;

    // INTERACTION STATE
    let isDraggingTimeline = false;
    let dragStartX = 0;
    let dragStartTimeWindow = {{ start: 0, end: 0 }};

    let isDraggingMinimap = false;
    let minimapDragMode = null;
    let minimapDragStartX = 0;
    let minimapInitialView = {{ start: 0, end: 0 }};

    let hoveredEvent = null;
    let activeModalEvent = null;

    // INITIALIZATION
    function init() {{
      allEvents = RAW_EVENTS.map(ev => {{
        let time = new Date(ev.published_at).getTime();
        if (isNaN(time)) {{
          time = new Date(ev.date).getTime();
        }}
        return {{ ...ev, timestamp: time }};
      }}).filter(ev => !isNaN(ev.timestamp));

      allEvents.sort((a, b) => a.timestamp - b.timestamp);

      minTime = allEvents[0].timestamp;
      maxTime = allEvents[allEvents.length - 1].timestamp;

      // Default view: Last 7 Days (168 hours)
      const defaultDuration = 7 * 24 * 60 * 60 * 1000;
      viewEnd = maxTime;
      viewStart = Math.max(minTime, maxTime - defaultDuration);

      renderCategoryChips();
      setupEventListeners();
      setupCanvasResizing();
      updateDashboard();
    }}

    // RENDER CATEGORY FILTER CHIPS
    function renderCategoryChips() {{
      const container = document.getElementById('categoryChipsContainer');
      container.innerHTML = '';

      CATEGORY_NAMES.forEach(cat => {{
        const cfg = CATEGORIES[cat];
        const count = allEvents.filter(e => e.category === cat).length;
        const isActive = activeCategories.has(cat);

        const btn = document.createElement('button');
        btn.className = `badge-pill flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition ${{
          isActive 
            ? 'border-opacity-60 text-white' 
            : 'bg-slate-900/60 border-slate-800 text-slate-500 opacity-50'
        }}`;
        btn.style.backgroundColor = isActive ? cfg.bg : '';
        btn.style.borderColor = isActive ? cfg.border : '';
        btn.innerHTML = `<span>${{cfg.icon}}</span><span>${{cat}}</span><span class="text-[10px] font-mono opacity-80 bg-black/30 px-1.5 py-0.2 rounded-full">${{count}}</span>`;
        
        btn.onclick = () => {{
          if (activeCategories.has(cat)) {{
            if (activeCategories.size > 1) activeCategories.delete(cat);
          }} else {{
            activeCategories.add(cat);
          }}
          renderCategoryChips();
          updateDashboard();
        }};

        container.appendChild(btn);
      }});
    }}

    function toggleOnlyCategory(cat) {{
      activeCategories = new Set([cat]);
      renderCategoryChips();
      updateDashboard();
    }}

    function resetFilters() {{
      activeCategories = new Set(CATEGORY_NAMES);
      searchQuery = '';
      document.getElementById('searchInput').value = '';
      document.getElementById('clearSearchBtn').classList.add('hidden');
      renderCategoryChips();
      updateDashboard();
    }}

    function getFilteredEvents() {{
      return allEvents.filter(ev => {{
        if (!activeCategories.has(ev.category)) return false;
        if (searchQuery) {{
          const q = searchQuery.toLowerCase();
          const matchTitle = ev.title && ev.title.toLowerCase().includes(q);
          const matchSummary = ev.summary && ev.summary.toLowerCase().includes(q);
          const matchProvider = ev.provider && ev.provider.toLowerCase().includes(q);
          if (!matchTitle && !matchSummary && !matchProvider) return false;
        }}
        return true;
      }});
    }}

    function updateDashboard() {{
      const filtered = getFilteredEvents();
      
      document.getElementById('totalCountBadge').innerText = allEvents.length;
      document.getElementById('visibleCountBadge').innerText = filtered.length;

      const sDate = new Date(viewStart);
      const eDate = new Date(viewEnd);
      document.getElementById('currentVisibleWindowLabel').innerText = 
        `${{formatDateTime(sDate)}} - ${{formatDateTime(eDate)}}`;

      renderTimelineCanvas(filtered);
      renderMinimapCanvas(filtered);
      updateMinimapViewport();
      renderFeedList(filtered);
    }}

    function formatDateTime(d) {{
      const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
      const day = d.getDate();
      const month = months[d.getMonth()];
      const hours = String(d.getHours()).padStart(2, '0');
      const mins = String(d.getMinutes()).padStart(2, '0');
      return `${{day}} ${{month}} ${{hours}}:${{mins}} น.`;
    }}

    function formatDateShort(d) {{
      const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
      return `${{d.getDate()}} ${{months[d.getMonth()]}}`;
    }}

    // TIMELINE CANVAS RENDERING
    function renderTimelineCanvas(filtered) {{
      const canvas = document.getElementById('timelineCanvas');
      const ctx = canvas.getContext('2d');
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;

      if (canvas.width !== w * dpr || canvas.height !== h * dpr) {{
        canvas.width = w * dpr;
        canvas.height = h * dpr;
      }}

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, w, h);

      const timeToX = (t) => {{
        return ((t - viewStart) / (viewEnd - viewStart)) * w;
      }};

      const headerH = 40;
      const laneH = (h - headerH) / CATEGORY_NAMES.length;

      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, w, headerH);
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, headerH);
      ctx.lineTo(w, headerH);
      ctx.stroke();

      const viewDuration = viewEnd - viewStart;
      let tickInterval = 24 * 3600 * 1000;
      if (viewDuration <= 36 * 3600 * 1000) tickInterval = 4 * 3600 * 1000;
      else if (viewDuration <= 96 * 3600 * 1000) tickInterval = 12 * 3600 * 1000;
      else if (viewDuration > 14 * 24 * 3600 * 1000) tickInterval = 3 * 24 * 3600 * 1000;

      const firstTick = Math.floor(viewStart / tickInterval) * tickInterval;
      for (let t = firstTick; t <= viewEnd + tickInterval; t += tickInterval) {{
        const x = timeToX(t);
        if (x < -50 || x > w + 50) continue;

        ctx.strokeStyle = '#1e293b';
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(x, headerH);
        ctx.lineTo(x, h);
        ctx.stroke();
        ctx.setLineDash([]);

        const d = new Date(t);
        ctx.fillStyle = '#94a3b8';
        ctx.font = '11px Prompt, sans-serif';
        ctx.textAlign = 'center';
        
        let label = formatDateShort(d);
        if (tickInterval < 24 * 3600 * 1000) {{
          label = `${{String(d.getHours()).padStart(2, '0')}}:00`;
        }}
        ctx.fillText(label, x, 24);
      }}

      CATEGORY_NAMES.forEach((cat, idx) => {{
        const yTop = headerH + idx * laneH;
        const cfg = CATEGORIES[cat];

        ctx.fillStyle = idx % 2 === 0 ? 'rgba(15, 23, 42, 0.4)' : 'rgba(11, 15, 23, 0.6)';
        ctx.fillRect(0, yTop, w, laneH);

        ctx.strokeStyle = 'rgba(51, 65, 85, 0.4)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, yTop + laneH);
        ctx.lineTo(w, yTop + laneH);
        ctx.stroke();

        ctx.fillStyle = cfg.bg;
        ctx.beginPath();
        ctx.roundRect(10, yTop + 8, 85, 24, 6);
        ctx.fill();
        ctx.strokeStyle = cfg.border;
        ctx.stroke();

        ctx.fillStyle = cfg.color;
        ctx.font = 'bold 11px Prompt, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(`${{cfg.icon}} ${{cat}}`, 18, yTop + 24);
      }});

      const laneEvents = {{}};
      CATEGORY_NAMES.forEach(c => laneEvents[c] = []);

      filtered.forEach(ev => {{
        if (ev.timestamp >= viewStart - (viewDuration * 0.05) && ev.timestamp <= viewEnd + (viewDuration * 0.05)) {{
          if (laneEvents[ev.category]) laneEvents[ev.category].push(ev);
        }}
      }});

      CATEGORY_NAMES.forEach((cat, catIdx) => {{
        const laneY = headerH + catIdx * laneH;
        const cfg = CATEGORIES[cat];
        const evs = laneEvents[cat];

        evs.forEach((ev, i) => {{
          const x = timeToX(ev.timestamp);
          const offsetIdx = i % 2;
          const y = laneY + 22 + offsetIdx * 20;

          ev._renderX = x;
          ev._renderY = y;
          ev._renderRadius = 6.5;

          const isHovered = hoveredEvent && hoveredEvent.id === ev.id;

          ctx.strokeStyle = isHovered ? cfg.color : 'rgba(255, 255, 255, 0.15)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(x, headerH);
          ctx.lineTo(x, y);
          ctx.stroke();

          if (isHovered) {{
            ctx.fillStyle = cfg.border;
            ctx.beginPath();
            ctx.arc(x, y, 14, 0, Math.PI * 2);
            ctx.fill();
          }}

          ctx.fillStyle = cfg.color;
          ctx.beginPath();
          ctx.arc(x, y, isHovered ? 8 : 6, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = '#0b0f17';
          ctx.lineWidth = 2;
          ctx.stroke();

          if (viewDuration <= 7 * 24 * 3600 * 1000) {{
            const titleSnippet = ev.title.length > 20 ? ev.title.substring(0, 18) + '…' : ev.title;
            ctx.fillStyle = isHovered ? '#ffffff' : '#cbd5e1';
            ctx.font = isHovered ? 'bold 11px Prompt' : '10px Prompt';
            ctx.textAlign = 'left';
            ctx.fillText(titleSnippet, x + 10, y + 3.5);
          }}
        }});
      }});

      ctx.restore();
    }}

    // MINIMAP RENDERING
    function renderMinimapCanvas(filtered) {{
      const canvas = document.getElementById('minimapCanvas');
      const ctx = canvas.getContext('2d');
      const dpr = window.devicePixelRatio || 1;
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;

      if (canvas.width !== w * dpr || canvas.height !== h * dpr) {{
        canvas.width = w * dpr;
        canvas.height = h * dpr;
      }}

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, w, h);

      const numBuckets = 44;
      const bucketDuration = (maxTime - minTime) / numBuckets;
      const counts = new Array(numBuckets).fill(0);

      filtered.forEach(ev => {{
        const b = Math.min(numBuckets - 1, Math.max(0, Math.floor((ev.timestamp - minTime) / bucketDuration)));
        counts[b]++;
      }});

      const maxCount = Math.max(...counts, 1);
      const barW = (w / numBuckets);

      counts.forEach((c, i) => {{
        const barH = (c / maxCount) * (h - 12);
        const x = i * barW;
        const y = h - barH;

        ctx.fillStyle = '#334155';
        ctx.fillRect(x + 1, y, barW - 2, barH);
      }});

      ctx.restore();
    }}

    function updateMinimapViewport() {{
      const vp = document.getElementById('minimapViewport');
      const containerW = document.getElementById('minimapContainer').clientWidth;
      const totalSpan = maxTime - minTime;

      const leftFrac = Math.max(0, Math.min(1, (viewStart - minTime) / totalSpan));
      const rightFrac = Math.max(0, Math.min(1, (viewEnd - minTime) / totalSpan));

      const leftPx = leftFrac * containerW;
      const widthPx = Math.max(20, (rightFrac - leftFrac) * containerW);

      vp.style.left = `${{leftPx}}px`;
      vp.style.width = `${{widthPx}}px`;
    }}

    // FEED LIST RENDERING
    function renderFeedList(filtered) {{
      const container = document.getElementById('eventsFeedList');
      const feedBadge = document.getElementById('feedCounterBadge');

      const inViewEvents = filtered.filter(ev => 
        ev.timestamp >= viewStart && ev.timestamp <= viewEnd
      ).sort((a, b) => b.timestamp - a.timestamp);

      feedBadge.innerText = `${{inViewEvents.length}} ข่าว`;

      if (inViewEvents.length === 0) {{
        container.innerHTML = `
          <div class="glass-panel p-6 rounded-xl border border-slate-800 text-center text-slate-400 text-xs flex flex-col items-center gap-2">
            <span class="text-2xl">🔍</span>
            <span>ไม่พบข่าวสารในช่วงเวลานี้</span>
            <button onclick="setZoomPreset(0)" class="mt-2 text-amber-400 hover:underline">
              ขยายเป็นดูข่าวทั้งหมด
            </button>
          </div>
        `;
        return;
      }}

      container.innerHTML = inViewEvents.map(ev => {{
        const cfg = CATEGORIES[ev.category] || CATEGORIES['ธุรกิจ'];
        const pubDate = new Date(ev.timestamp);
        const timeStr = formatDateTime(pubDate);

        return `
          <div 
            class="event-card glass-panel p-3.5 rounded-xl border border-slate-800 hover:border-slate-700 cursor-pointer flex flex-col gap-2"
            onclick="openDetailModal('${{ev.id}}')"
            onmouseenter="highlightTimelineEvent('${{ev.id}}')"
            onmouseleave="clearHighlightTimelineEvent()"
          >
            <div class="flex items-center justify-between gap-2">
              <span class="text-[11px] font-semibold px-2 py-0.5 rounded-md" style="background-color: ${{cfg.bg}}; color: ${{cfg.color}}; border: 1px solid ${{cfg.border}}">
                ${{cfg.icon}} ${{ev.category}}
              </span>
              <span class="text-[11px] font-mono text-slate-400">${{timeStr}}</span>
            </div>

            <h4 class="text-sm font-semibold text-white leading-snug line-clamp-2">
              ${{ev.title}}
            </h4>

            <p class="text-xs text-slate-400 line-clamp-2 leading-relaxed">
              ${{ev.summary || 'คลิกเพื่อดูรายละเอียดเพิ่มเติม...'}}
            </p>

            <div class="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-800/80">
              <span class="font-mono">แหล่ง: ${{ev.source_link || ev.provider || 'Factnews'}}</span>
              <span class="text-amber-400/90 font-medium hover:underline flex items-center gap-0.5">
                อ่านต่อ ➔
              </span>
            </div>
          </div>
        `;
      }}).join('');
    }}

    function setZoomPreset(hours) {{
      document.querySelectorAll('.preset-btn').forEach(btn => {{
        btn.classList.remove('active', 'bg-amber-500/20', 'text-amber-300', 'border', 'border-amber-500/30');
        btn.classList.add('bg-slate-800', 'text-slate-300');
        if (Number(btn.dataset.hours) === hours) {{
          btn.classList.remove('bg-slate-800', 'text-slate-300');
          btn.classList.add('active', 'bg-amber-500/20', 'text-amber-300', 'border', 'border-amber-500/30');
        }}
      }});

      if (hours === 0) {{
        viewStart = minTime;
        viewEnd = maxTime;
      }} else {{
        const duration = hours * 3600 * 1000;
        viewEnd = maxTime;
        viewStart = Math.max(minTime, maxTime - duration);
      }}
      updateDashboard();
    }}

    function zoomStep(factor) {{
      const currentSpan = viewEnd - viewStart;
      const center = (viewStart + viewEnd) / 2;
      const newSpan = Math.max(2 * 3600 * 1000, Math.min(maxTime - minTime, currentSpan * factor));

      viewStart = Math.max(minTime, center - newSpan / 2);
      viewEnd = Math.min(maxTime, viewStart + newSpan);
      if (viewEnd >= maxTime) {{
        viewStart = Math.max(minTime, maxTime - newSpan);
      }}

      updateDashboard();
    }}

    function resetTimelineView() {{
      setZoomPreset(168);
    }}

    function setupEventListeners() {{
      const canvas = document.getElementById('timelineCanvas');
      const tooltip = document.getElementById('timelineTooltip');

      canvas.addEventListener('wheel', (e) => {{
        e.preventDefault();
        const rect = canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseRatio = mouseX / rect.width;

        const zoomFactor = e.deltaY > 0 ? 1.25 : 0.8;
        const currentSpan = viewEnd - viewStart;
        const newSpan = Math.max(2 * 3600 * 1000, Math.min(maxTime - minTime, currentSpan * zoomFactor));

        const focusTime = viewStart + currentSpan * mouseRatio;
        viewStart = Math.max(minTime, focusTime - newSpan * mouseRatio);
        viewEnd = Math.min(maxTime, viewStart + newSpan);
        if (viewEnd >= maxTime) {{
          viewStart = Math.max(minTime, maxTime - newSpan);
        }}

        updateDashboard();
      }}, {{ passive: false }});

      canvas.addEventListener('mousedown', (e) => {{
        isDraggingTimeline = true;
        dragStartX = e.clientX;
        dragStartTimeWindow = {{ start: viewStart, end: viewEnd }};
      }});

      window.addEventListener('mousemove', (e) => {{
        if (isDraggingTimeline) {{
          const dx = e.clientX - dragStartX;
          const rect = canvas.getBoundingClientRect();
          const timePerPx = (dragStartTimeWindow.end - dragStartTimeWindow.start) / rect.width;
          const dTime = dx * timePerPx;

          let newStart = dragStartTimeWindow.start - dTime;
          let newEnd = dragStartTimeWindow.end - dTime;

          if (newStart < minTime) {{
            newEnd += (minTime - newStart);
            newStart = minTime;
          }}
          if (newEnd > maxTime) {{
            newStart -= (newEnd - maxTime);
            newEnd = maxTime;
          }}

          viewStart = Math.max(minTime, newStart);
          viewEnd = Math.min(maxTime, newEnd);
          updateDashboard();
          return;
        }}

        if (!isDraggingTimeline && !isDraggingMinimap) {{
          const rect = canvas.getBoundingClientRect();
          const mx = e.clientX - rect.left;
          const my = e.clientY - rect.top;

          if (mx >= 0 && mx <= rect.width && my >= 0 && my <= rect.height) {{
            const filtered = getFilteredEvents();
            let found = null;

            for (let ev of filtered) {{
              if (ev._renderX !== undefined) {{
                const dist = Math.hypot(ev._renderX - mx, ev._renderY - my);
                if (dist < 12) {{
                  found = ev;
                  break;
                }}
              }}
            }}

            if (found) {{
              hoveredEvent = found;
              canvas.style.cursor = 'pointer';
              showTooltip(found, e.clientX, e.clientY);
              renderTimelineCanvas(filtered);
            }} else {{
              if (hoveredEvent) {{
                hoveredEvent = null;
                canvas.style.cursor = 'grab';
                hideTooltip();
                renderTimelineCanvas(filtered);
              }}
            }}
          }} else {{
            if (hoveredEvent) {{
              hoveredEvent = null;
              hideTooltip();
              renderTimelineCanvas(getFilteredEvents());
            }}
          }}
        }}

        if (isDraggingMinimap) {{
          const miniContainer = document.getElementById('minimapContainer');
          const miniRect = miniContainer.getBoundingClientRect();
          const totalSpan = maxTime - minTime;
          const dx = e.clientX - minimapDragStartX;
          const dTime = (dx / miniRect.width) * totalSpan;

          if (minimapDragMode === 'window') {{
            let newStart = minimapInitialView.start + dTime;
            let newEnd = minimapInitialView.end + dTime;
            const span = minimapInitialView.end - minimapInitialView.start;

            if (newStart < minTime) {{
              newStart = minTime;
              newEnd = minTime + span;
            }}
            if (newEnd > maxTime) {{
              newEnd = maxTime;
              newStart = maxTime - span;
            }}
            viewStart = newStart;
            viewEnd = newEnd;
          }} else if (minimapDragMode === 'left') {{
            let newStart = Math.min(viewEnd - (2 * 3600 * 1000), Math.max(minTime, minimapInitialView.start + dTime));
            viewStart = newStart;
          }} else if (minimapDragMode === 'right') {{
            let newEnd = Math.max(viewStart + (2 * 3600 * 1000), Math.min(maxTime, minimapInitialView.end + dTime));
            viewEnd = newEnd;
          }}
          updateDashboard();
        }}
      }});

      window.addEventListener('mouseup', () => {{
        isDraggingTimeline = false;
        isDraggingMinimap = false;
        minimapDragMode = null;
      }});

      canvas.addEventListener('click', (e) => {{
        if (hoveredEvent) {{
          openDetailModal(hoveredEvent.id);
        }}
      }});

      const vp = document.getElementById('minimapViewport');
      const handleL = document.getElementById('handleLeft');
      const handleR = document.getElementById('handleRight');

      vp.addEventListener('mousedown', (e) => {{
        if (e.target === handleL) {{
          minimapDragMode = 'left';
        }} else if (e.target === handleR) {{
          minimapDragMode = 'right';
        }} else {{
          minimapDragMode = 'window';
        }}
        isDraggingMinimap = true;
        minimapDragStartX = e.clientX;
        minimapInitialView = {{ start: viewStart, end: viewEnd }};
        e.stopPropagation();
      }});

      const searchInput = document.getElementById('searchInput');
      const clearSearchBtn = document.getElementById('clearSearchBtn');

      searchInput.addEventListener('input', (e) => {{
        searchQuery = e.target.value.trim();
        if (searchQuery) {{
          clearSearchBtn.classList.remove('hidden');
        }} else {{
          clearSearchBtn.classList.add('hidden');
        }}
        updateDashboard();
      }});

      clearSearchBtn.addEventListener('click', () => {{
        searchInput.value = '';
        searchQuery = '';
        clearSearchBtn.classList.add('hidden');
        updateDashboard();
      }});
    }}

    function showTooltip(ev, clientX, clientY) {{
      const tooltip = document.getElementById('timelineTooltip');
      const cfg = CATEGORIES[ev.category] || CATEGORIES['ธุรกิจ'];
      
      const badge = document.getElementById('tooltipCategoryBadge');
      badge.innerText = `${{cfg.icon}} ${{ev.category}}`;
      badge.style.backgroundColor = cfg.bg;
      badge.style.color = cfg.color;
      badge.style.borderColor = cfg.border;

      document.getElementById('tooltipTime').innerText = formatDateTime(new Date(ev.timestamp));
      document.getElementById('tooltipProvider').innerText = ev.source_link || ev.provider || '';
      document.getElementById('tooltipTitle').innerText = ev.title;
      document.getElementById('tooltipSnippet').innerText = ev.summary || '';

      const container = document.getElementById('timelineContainer').getBoundingClientRect();
      let left = clientX - container.left + 15;
      let top = clientY - container.top - 20;

      if (left + 320 > container.width) left = left - 340;
      if (top + 160 > container.height) top = container.height - 170;
      if (top < 10) top = 10;

      tooltip.style.left = `${{left}}px`;
      tooltip.style.top = `${{top}}px`;
      tooltip.classList.remove('hidden');
    }}

    function hideTooltip() {{
      document.getElementById('timelineTooltip').classList.add('hidden');
    }}

    function highlightTimelineEvent(id) {{
      const ev = allEvents.find(e => e.id === id);
      if (ev) {{
        hoveredEvent = ev;
        renderTimelineCanvas(getFilteredEvents());
      }}
    }}

    function clearHighlightTimelineEvent() {{
      hoveredEvent = null;
      renderTimelineCanvas(getFilteredEvents());
    }}

    function openDetailModal(id) {{
      const ev = allEvents.find(e => e.id === id);
      if (!ev) return;

      activeModalEvent = ev;
      const cfg = CATEGORIES[ev.category] || CATEGORIES['ธุรกิจ'];
      const modal = document.getElementById('eventDetailModal');

      const badge = document.getElementById('modalCategoryBadge');
      badge.innerText = `${{cfg.icon}} ${{ev.category}}`;
      badge.style.backgroundColor = cfg.bg;
      badge.style.color = cfg.color;

      document.getElementById('modalTime').innerText = `🕒 ${{formatDateTime(new Date(ev.timestamp))}}`;
      document.getElementById('modalProvider').innerText = `แหล่งข้อมูล: ${{ev.provider || 'Factnews AI'}}`;
      document.getElementById('modalTitle').innerText = ev.title;
      document.getElementById('modalSummary').innerText = ev.summary;
      document.getElementById('modalDetails').innerText = ev.details || '';
      document.getElementById('modalSourceLink').innerText = ev.source_link || 'CNBC / Thai PBS';

      modal.classList.remove('hidden');
    }}

    function closeDetailModal() {{
      document.getElementById('eventDetailModal').classList.add('hidden');
      activeModalEvent = null;
    }}

    window.addEventListener('keydown', (e) => {{
      if (e.key === 'Escape') closeDetailModal();
    }});
    document.getElementById('eventDetailModal').addEventListener('click', (e) => {{
      if (e.target.id === 'eventDetailModal') closeDetailModal();
    }});

    function setupCanvasResizing() {{
      window.addEventListener('resize', () => {{
        updateDashboard();
      }});
    }}

    window.addEventListener('DOMContentLoaded', init);
  </script>
</body>
</html>
'''

with open(output_html_path, "w", encoding="utf-8") as f_out:
    f_out.write(html_template)

print("Generated successfully:", output_html_path)
print("File size:", os.path.getsize(output_html_path), "bytes")
