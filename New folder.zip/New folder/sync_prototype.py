import json, os, base64

with open('parsed_factnews.json', 'r', encoding='utf-8') as f:
    events = json.load(f)

events_sorted = sorted(events, key=lambda x: x['published_at'])
events_json = json.dumps(events_sorted, ensure_ascii=False)

# Read the HTML template parts from static files
with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

with open('static/css/style.css', 'r', encoding='utf-8') as f:
    css = f.read()

with open('static/js/timeline.js', 'r', encoding='utf-8') as f:
    timeline_js = f.read()

with open('static/js/minimap.js', 'r', encoding='utf-8') as f:
    minimap_js = f.read()

with open('static/js/feed.js', 'r', encoding='utf-8') as f:
    feed_js = f.read()

with open('static/js/worldmap.js', 'r', encoding='utf-8') as f:
    worldmap_js = f.read()

with open('static/js/app.js', 'r', encoding='utf-8') as f:
    app_js = f.read()

# Replace leaflet links with inline styles & scripts or CDN fallback
leaflet_css_path = 'static/vendor/leaflet/leaflet.css'
leaflet_js_path = 'static/vendor/leaflet/leaflet.js'

if os.path.exists(leaflet_css_path):
    with open(leaflet_css_path, 'r', encoding='utf-8') as f_lcss:
        leaflet_css = f_lcss.read()
    html = html.replace('<link rel="stylesheet" href="/static/vendor/leaflet/leaflet.css" />', f'<style>{leaflet_css}</style>')
else:
    html = html.replace('<link rel="stylesheet" href="/static/vendor/leaflet/leaflet.css" />', '<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />')

if os.path.exists(leaflet_js_path):
    with open(leaflet_js_path, 'r', encoding='utf-8') as f_ljs:
        leaflet_js = f_ljs.read()
    html = html.replace('<script src="/static/vendor/leaflet/leaflet.js"></script>', f'<script>{leaflet_js}</script>')
else:
    html = html.replace('<script src="/static/vendor/leaflet/leaflet.js"></script>', '<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>')

# Replace css link with inline style
html = html.replace('<link rel="stylesheet" href="/static/css/style.css">', f'<style>{css}</style>')

# Embed logo as base64 data URI for standalone offline usage
logo_path = 'static/img/writetime_logo.png'
if os.path.exists(logo_path):
    with open(logo_path, 'rb') as f_logo:
        logo_b64 = base64.b64encode(f_logo.read()).decode('utf-8')
        logo_data_uri = f'data:image/jpeg;base64,{logo_b64}'
        html = html.replace('/static/img/writetime_logo.png', logo_data_uri)

# Replace script tags with embedded data & logic
script_replacement = f"""
  <script>
    const EMBEDDED_EVENTS = {events_json};
  </script>
  <script>
    {timeline_js}
  </script>
  <script>
    {minimap_js}
  </script>
  <script>
    {feed_js}
  </script>
  <script>
    {worldmap_js}
  </script>
"""

html = html.replace('<script src="/static/js/timeline.js"></script>', script_replacement)
html = html.replace('<script src="/static/js/minimap.js"></script>', '')
html = html.replace('<script src="/static/js/feed.js"></script>', '')
html = html.replace('<script src="/static/js/worldmap.js"></script>', '')

# In app.js, fallback to EMBEDDED_EVENTS if API is unreachable
app_js_standalone = app_js.replace(
    "const resp = await fetch('/api/events');",
    """let resp = null;
      let data = null;
      try {
        resp = await fetch('/api/events');
        if (resp && resp.ok) data = await resp.json();
      } catch (err) {}
      if (!data) {
        data = { events: EMBEDDED_EVENTS, total_count: EMBEDDED_EVENTS.length, last_modified: '30 ต.ค. 2026, 13:08 น.', min_timestamp: EMBEDDED_EVENTS[0].timestamp, max_timestamp: EMBEDDED_EVENTS[EMBEDDED_EVENTS.length-1].timestamp };
      }"""
)

html = html.replace('<script src="/static/js/app.js"></script>', f'<script>{app_js_standalone}</script>')

# Save to workspace and artifact dir
output_ws = 'factnews_dashboard_prototype.html'
output_art = r'C:\Users\admin\.gemini\antigravity\brain\a8ea452c-ad6b-4a73-9204-892b7273b394\factnews_dashboard_prototype.html'

with open(output_ws, 'w', encoding='utf-8') as f:
    f.write(html)
with open(output_art, 'w', encoding='utf-8') as f:
    f.write(html)

print('Updated standalone prototype successfully!')
