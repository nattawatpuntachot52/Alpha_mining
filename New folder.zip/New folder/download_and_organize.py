import os
import json
import urllib.request
import re
import time

DATA_FILE = r'd:\New folder\all_extracted_items.json'
TARGET_DIR = r'd:\New folder\Facebook_BanRimdoy_Photos'

CATEGORIES = {
    '01_ที่ดินและอสังหาริมทรัพย์เพื่อขาย': 'ที่ดิน แปลงขาย ผัง GPS และโฉนดเพื่อการขาย',
    '02_รีสอร์ทและทัศนียภาพเขาค้อ': 'บ้านริมดอย รีสอร์ท วิวทะเลหมอก ทัศนียภาพธรรมชาติ',
    '03_แบบแปลนและผังแม่บทโครงการ': 'แบบแปลนสถาปัตยกรรม ผังแม่บท Plan A อาคารและห้องพัก',
    '04_งานก่อสร้างปรับพื้นที่และรีโนเวท': 'เครื่องจักรกลหนัก ปรับหน้าดิน วางท่อ รีโนเวท ไซต์งาน',
    '05_การทำธุรกรรมและปิดการขายที่ดิน': 'สำนักงานที่ดิน ส่งมอบโฉนด ดีลปิดการขาย'
}

def classify(idx, it):
    cap = it.get('caption', '')
    src = it.get('src', '')
    i = idx + 1
    if 29 <= i <= 38:
        return '03_แบบแปลนและผังแม่บทโครงการ'
    if 39 <= i <= 50 or 83 <= i <= 86 or i == 79 or 'ไซต์งาน' in cap:
        return '04_งานก่อสร้างปรับพื้นที่และรีโนเวท'
    if i in [59, 81, 82] or 'สำนักงานที่ดิน' in cap or 'ดีลที่ดีมาก' in cap or 'อย่าล้อเล่นกับระบบ' in cap:
        return '05_การทำธุรกรรมและปิดการขายที่ดิน'
    if i in [11, 12, 13, 17, 24, 25, 51, 52, 53, 54, 55, 56, 57] or '.mp4' in src:
        return '02_รีสอร์ทและทัศนียภาพเขาค้อ'
    return '01_ที่ดินและอสังหาริมทรัพย์เพื่อขาย'

def main():
    os.makedirs(TARGET_DIR, exist_ok=True)
    for cat in CATEGORIES:
        os.makedirs(os.path.join(TARGET_DIR, cat), exist_ok=True)

    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        items = json.load(f)

    catalog = []
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
    }

    print(f"Starting download of {len(items)} items...")

    for idx, it in enumerate(items):
        item_num = idx + 1
        cat = classify(idx, it)
        fbid = it.get('fbid') or 'item'
        src = it.get('src', '')
        cap = it.get('caption', '').strip()
        url = it.get('url', '')

        # Determine extension
        ext = '.mp4' if ('.mp4' in src or it.get('type') == 'video') else '.jpg'
        filename = f"{item_num:02d}_{fbid}{ext}"
        filepath = os.path.join(TARGET_DIR, cat, filename)

        # Download if not exists or empty
        success = False
        if os.path.exists(filepath) and os.path.getsize(filepath) > 0:
            success = True
            print(f"[{item_num:02d}/{len(items)}] Exists: {filename}")
        else:
            for attempt in range(3):
                try:
                    req = urllib.request.Request(src, headers=headers)
                    with urllib.request.urlopen(req, timeout=30) as resp:
                        content = resp.read()
                        with open(filepath, 'wb') as out_f:
                            out_f.write(content)
                    success = True
                    print(f"[{item_num:02d}/{len(items)}] Downloaded ({len(content)} bytes): {filename} -> {cat}")
                    break
                except Exception as e:
                    print(f"[{item_num:02d}/{len(items)}] Attempt {attempt+1} failed for {filename}: {e}")
                    time.sleep(1)

        rel_path = f"{cat}/{filename}"
        catalog.append({
            'index': item_num,
            'fbid': fbid,
            'category': cat,
            'filename': filename,
            'relative_path': rel_path,
            'full_path': filepath,
            'caption': cap,
            'source_url': url,
            'media_url': src,
            'download_success': success
        })

    # Save catalog.json
    with open(os.path.join(TARGET_DIR, 'catalog.json'), 'w', encoding='utf-8') as f:
        json.dump(catalog, f, ensure_ascii=False, indent=2)

    # Generate README.md
    readme_lines = [
        "# รายการรูปภาพจากอัลบั้ม Facebook (Ban Rimdoy ,Property , Estates)",
        f"- ลิงก์ต้นทาง: https://www.facebook.com/media/set/?set=a.1045122632166875&type=3",
        f"- จำนวนรายการทั้งหมด: {len(catalog)} รายการ",
        f"- ดาวน์โหลดสำเร็จ: {sum(1 for c in catalog if c['download_success'])} รายการ\n",
        "## หมวดหมู่รูปภาพที่จัดเก็บ:\n"
    ]

    for cat_name, desc in CATEGORIES.items():
        cat_items = [c for c in catalog if c['category'] == cat_name]
        readme_lines.append(f"### {cat_name} ({len(cat_items)} รายการ)")
        readme_lines.append(f"*{desc}*\n")
        readme_lines.append("| ลำดับ | รหัส FBID | ชื่อไฟล์ | คำบรรยาย | ลิงก์ต้นทาง |")
        readme_lines.append("|---|---|---|---|---|")
        for ci in cat_items:
            short_cap = ci['caption'].replace('\n', ' ')[:60].replace('|', '/')
            readme_lines.append(f"| {ci['index']:02d} | `{ci['fbid']}` | `{ci['filename']}` | {short_cap} | [Facebook]({ci['source_url']}) |")
        readme_lines.append("\n")

    with open(os.path.join(TARGET_DIR, 'README.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(readme_lines))

    # Generate HTML gallery
    html_content = f"""<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<title>Ban Rimdoy Property Album Gallery</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f0f2f5; margin: 0; padding: 20px; }}
  h1 {{ text-align: center; color: #1877f2; }}
  .cat-section {{ margin-bottom: 40px; background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
  .cat-title {{ color: #050505; border-bottom: 2px solid #1877f2; padding-bottom: 8px; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; margin-top: 16px; }}
  .card {{ border: 1px solid #ddd; border-radius: 8px; overflow: hidden; background: #fafafa; display: flex; flex-direction: column; }}
  .card img, .card video {{ width: 100%; height: 200px; object-fit: cover; background: #000; }}
  .info {{ padding: 12px; font-size: 13px; flex-grow: 1; }}
  .fbid {{ font-weight: bold; color: #1877f2; }}
  .caption {{ color: #555; margin-top: 6px; max-height: 80px; overflow-y: auto; white-space: pre-line; }}
</style>
</head>
<body>
<h1>Ban Rimdoy Property Album ({len(catalog)} รายการ)</h1>
"""
    for cat_name, desc in CATEGORIES.items():
        cat_items = [c for c in catalog if c['category'] == cat_name]
        html_content += f"""
<div class="cat-section">
  <h2 class="cat-title">{cat_name} ({len(cat_items)} รายการ)</h2>
  <p style="color: #666;">{desc}</p>
  <div class="grid">
"""
        for ci in cat_items:
            rel = ci['relative_path']
            media_tag = f'<video src="{rel}" controls></video>' if ci['filename'].endswith('.mp4') else f'<img src="{rel}" loading="lazy">'
            html_content += f"""
    <div class="card">
      {media_tag}
      <div class="info">
        <div class="fbid">#{ci['index']:02d} | FBID: {ci['fbid']}</div>
        <div class="caption">{ci['caption'][:150]}</div>
      </div>
    </div>
"""
        html_content += """
  </div>
</div>
"""
    html_content += """
</body>
</html>
"""
    with open(os.path.join(TARGET_DIR, 'gallery.html'), 'w', encoding='utf-8') as f:
        f.write(html_content)

    print(f"\nAll done! Total items: {len(catalog)}, Successful: {sum(1 for c in catalog if c['download_success'])}")

if __name__ == '__main__':
    main()
