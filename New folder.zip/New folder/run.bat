@echo off
title Factnews Event Radar 2.0
echo ========================================================
echo  Starting Factnews Event-Driven Radar 2.0 Server
echo  Dataset: Factnews - ข่าวอัปเดต 60 นาที.xlsx
echo ========================================================
echo.
python run_server.py
pause
