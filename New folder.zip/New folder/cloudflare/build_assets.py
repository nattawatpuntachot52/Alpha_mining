"""Deterministic public staging; explicit assets only, never a project-tree copy."""
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
ASSETS = ("index.html", "css/style.css", "img/writetime_logo.png", "js/app.js", "js/feed.js",
    "js/minimap.js", "js/timeline.js", "js/worldmap.js", "vendor/leaflet/leaflet.css", "vendor/leaflet/leaflet.js",
    "vendor/leaflet/images/layers-2x.png", "vendor/leaflet/images/layers.png", "vendor/leaflet/images/marker-icon-2x.png",
    "vendor/leaflet/images/marker-icon.png", "vendor/leaflet/images/marker-shadow.png", "js/browser-data.js", "js/xlsx-worker.js",
    "vendor/sheetjs/xlsx.mini.min.js", "vendor/sheetjs/LICENSE")


def build_assets(source=None, destination=None):
    source = Path(source) if source is not None else ROOT.parent / "static"
    destination = Path(destination) if destination is not None else ROOT / "public"
    source_root, destination_root = source.resolve(), destination.resolve()
    if destination.is_symlink() or source_root == destination_root or source_root in destination_root.parents or destination_root in source_root.parents:
        raise ValueError("Static input and generated output must be separate real directories")
    mapping = {name: "index.html" if name == "index.html" else "static/" + name for name in ASSETS}
    inputs = []
    for name, relative in mapping.items():
        path, target = source / name, destination / relative
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(source_root):
            raise ValueError(f"Missing or unsafe approved static asset: {name}")
        if not target.resolve().is_relative_to(destination_root) or target.is_symlink():
            raise ValueError("Generated asset target escapes public directory")
        inputs.append((path, target))
    if destination.exists():
        for path in destination.rglob("*"):
            if path.is_symlink() or (path.is_file() and path.relative_to(destination).as_posix() not in mapping.values()):
                raise ValueError("Unexpected public artifact; refusing unrelated content")
    for path, target in inputs:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    return sorted(mapping.values())


if __name__ == "__main__":
    print("Staged", len(build_assets()), "approved static assets")
