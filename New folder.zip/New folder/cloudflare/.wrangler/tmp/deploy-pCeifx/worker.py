"""Fixed-host streaming only; XLSX and candle parsing run in the browser."""
import re
from urllib.parse import parse_qs, urlencode, urlsplit
from workers import Response, WorkerEntrypoint, fetch

MODE = "browser-xlsx-v1"
SHEET_URL = "https://docs.google.com/spreadsheets/d/1JOknhrZ5PPLsOOIIS55sfaUiRAsCvYdy3tFLr1H7CG8/export?format=xlsx"
BINANCE_URL = "https://data-api.binance.vision/api/v3/klines"
INTERVALS = {"1s", "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"}
MAX_XLSX_BYTES = 8 * 1024 * 1024
MAX_PRICE_BYTES = 2 * 1024 * 1024


def price_query(query):
    if set(query) - {"symbol", "interval", "start_ms", "end_ms", "limit"} or any(len(values) != 1 for values in query.values()):
        raise ValueError("Unsupported query")
    symbol, interval = query.get("symbol", ["BTCUSDT"])[0].upper(), query.get("interval", ["1h"])[0]
    if not re.fullmatch(r"[A-Z0-9]{1,30}", symbol) or interval not in INTERVALS:
        raise ValueError("Invalid symbol or interval")
    result = {"symbol": symbol, "interval": interval, "limit": int(query.get("limit", [1000])[0])}
    if not 1 <= result["limit"] <= 1000:
        raise ValueError("Invalid page limit")
    for name, target in (("start_ms", "startTime"), ("end_ms", "endTime")):
        if name in query:
            value = int(query[name][0])
            if not 0 <= value <= 253402300799999:
                raise ValueError("Invalid timestamp")
            result[target] = value
    if result.get("startTime", 0) > result.get("endTime", 253402300799999):
        raise ValueError("Invalid timestamp order")
    return result


async def stream_fixed(url, content_type, limit):
    try:
        upstream = await fetch(url)
        if not upstream.ok:
            return Response.json({"detail": "Upstream unavailable"}, status=502)
        length = upstream.headers.get("content-length")
        if length and int(length) > limit:
            return Response.json({"detail": "Upstream body exceeds size limit"}, status=413)
        return Response(upstream.body, headers={"Content-Type": content_type, "Cache-Control": "no-store"})
    except Exception:
        return Response.json({"detail": "Upstream unavailable"}, status=502)


class Default(WorkerEntrypoint):
    async def fetch(self, request):
        url = urlsplit(request.url)
        if not url.path.startswith("/api/"):
            return await self.env.ASSETS.fetch(request)
        methods = {"/api/status": "GET", "/api/events": "GET", "/api/prices": "GET", "/api/sync": "POST",
            "/api/refresh": "POST", "/api/raw/events": "GET", "/api/raw/prices": "GET"}
        if url.path not in methods:
            return Response.json({"detail": "Not Found"}, status=404)
        if request.method.upper() != methods[url.path]:
            return Response.json({"detail": "Method Not Allowed"}, status=405, headers={"Allow": methods[url.path]})
        try:
            if len(url.query) > 512:
                raise ValueError("Query too long")
            query = parse_qs(url.query, keep_blank_values=True)
            if url.path in {"/api/prices", "/api/raw/prices"}:
                validated = price_query(query)
                if url.path == "/api/raw/prices":
                    return await stream_fixed(BINANCE_URL + "?" + urlencode(validated), "application/json", MAX_PRICE_BYTES)
                return Response.json({"client_mode": MODE, "prices_transport": "browser-direct",
                    "prices_url": BINANCE_URL, "raw_prices_url": "/api/raw/prices"})
            if query:
                raise ValueError("Unsupported query")
            if url.path == "/api/raw/events":
                return await stream_fixed(SHEET_URL, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", MAX_XLSX_BYTES)
            if url.path == "/api/status":
                return Response.json({"status": "client", "client_mode": MODE, "sync_mode": "browser",
                    "source": "Public Factnews / browser parsing", "sync_count": None, "reload_count": None,
                    "file_exists": False, "total_events": None, "last_sync_time": None,
                    "sync_interval_seconds": None, "is_syncing": False, "last_error": None})
            if url.path in {"/api/sync", "/api/refresh"}:
                return Response.json({"status": "success", "client_mode": MODE, "refetch": True, "message": "Browser must refetch public data"})
            return Response.json({"client_mode": MODE, "raw_events_url": "/api/raw/events"})
        except (ValueError, OverflowError):
            return Response.json({"detail": "Invalid bounded query"}, status=400)
