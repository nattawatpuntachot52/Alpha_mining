// Pages advanced mode: fixed-host streaming only; parsing stays in the browser.
const MODE = 'browser-xlsx-v1';
const SHEET_URL = 'https://docs.google.com/spreadsheets/d/1JOknhrZ5PPLsOOIIS55sfaUiRAsCvYdy3tFLr1H7CG8/export?format=xlsx';
const BINANCE_URL = 'https://data-api.binance.vision/api/v3/klines';
const INTERVALS = new Set(['1s', '1m', '3m', '5m', '15m', '30m', '1h', '2h', '4h', '6h', '8h', '12h', '1d', '3d', '1w', '1M']);
const METHODS = new Map([
    ['/api/status', 'GET'], ['/api/events', 'GET'], ['/api/prices', 'GET'],
    ['/api/sync', 'POST'], ['/api/refresh', 'POST'],
    ['/api/raw/events', 'GET'], ['/api/raw/prices', 'GET'],
]);

function json(body, status = 200, headers = {}) {
    return Response.json(body, { status, headers: { 'Cache-Control': 'no-store', ...headers } });
}

function integer(value, minimum, maximum) {
    if (!/^[+-]?\d+$/.test(value)) throw new Error('Invalid integer');
    const result = Number(value);
    if (!Number.isSafeInteger(result) || result < minimum || result > maximum) throw new Error('Invalid bound');
    return result;
}

function priceQuery(params) {
    const allowed = new Set(['symbol', 'interval', 'start_ms', 'end_ms', 'limit']);
    const seen = new Set();
    for (const [key] of params) {
        if (!allowed.has(key) || seen.has(key)) throw new Error('Unsupported query');
        seen.add(key);
    }
    const symbol = (params.get('symbol') ?? 'BTCUSDT').toUpperCase();
    const interval = params.get('interval') ?? '1h';
    if (!/^[A-Z0-9]{1,30}$/.test(symbol) || !INTERVALS.has(interval)) throw new Error('Invalid market');
    const query = new URLSearchParams({ symbol, interval, limit: String(integer(params.get('limit') ?? '1000', 1, 1000)) });
    for (const [name, target] of [['start_ms', 'startTime'], ['end_ms', 'endTime']]) {
        if (params.has(name)) query.set(target, String(integer(params.get(name), 0, 253402300799999)));
    }
    if (Number(query.get('startTime') ?? 0) > Number(query.get('endTime') ?? 253402300799999)) throw new Error('Invalid time order');
    return query;
}

async function streamFixed(url, contentType, limit, fetcher) {
    try {
        const upstream = await fetcher(url);
        if (!upstream.ok) return json({ detail: 'Upstream unavailable' }, 502);
        const length = upstream.headers.get('content-length');
        if (length !== null && !/^\d+$/.test(length)) return json({ detail: 'Upstream unavailable' }, 502);
        if (length !== null && Number(length) > limit) return json({ detail: 'Upstream body exceeds size limit' }, 413);
        return new Response(upstream.body, { headers: { 'Content-Type': contentType, 'Cache-Control': 'no-store' } });
    } catch {
        return json({ detail: 'Upstream unavailable' }, 502);
    }
}

export async function handleRequest(request, env, fetcher = fetch) {
    const url = new URL(request.url);
    if (url.pathname !== '/api' && !url.pathname.startsWith('/api/')) return env.ASSETS.fetch(request);
    const method = METHODS.get(url.pathname);
    if (!method) return json({ detail: 'Not Found' }, 404);
    if (request.method.toUpperCase() !== method) return json({ detail: 'Method Not Allowed' }, 405, { Allow: method });
    let query;
    try {
        if (url.search.length > 513) throw new Error('Query too long');
        if (url.pathname === '/api/prices' || url.pathname === '/api/raw/prices') query = priceQuery(url.searchParams);
        else if ([...url.searchParams].length) throw new Error('Unsupported query');
    } catch {
        return json({ detail: 'Invalid bounded query' }, 400);
    }
    if (url.pathname === '/api/raw/prices') return streamFixed(`${BINANCE_URL}?${query}`, 'application/json', 2 * 1024 * 1024, fetcher);
    if (url.pathname === '/api/prices') return json({ client_mode: MODE, prices_transport: 'browser-direct', prices_url: BINANCE_URL, raw_prices_url: '/api/raw/prices' });
    if (url.pathname === '/api/raw/events') return streamFixed(SHEET_URL, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 8 * 1024 * 1024, fetcher);
    if (url.pathname === '/api/status') return json({
        status: 'client', client_mode: MODE, sync_mode: 'browser', source: 'Public Factnews / browser parsing',
        sync_count: null, reload_count: null, file_exists: false, total_events: null, last_sync_time: null,
        sync_interval_seconds: null, is_syncing: false, last_error: null,
    });
    if (url.pathname === '/api/sync' || url.pathname === '/api/refresh') return json({ status: 'success', client_mode: MODE, refetch: true, message: 'Browser must refetch public data' });
    return json({ client_mode: MODE, raw_events_url: '/api/raw/events' });
}

export default { fetch(request, env) { return handleRequest(request, env); } };
