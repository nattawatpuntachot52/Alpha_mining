/**
 * WRITE TIME Clean Synchronized News Feed Engine
 * Features:
 * - Clean, uncluttered editorial cards
 * - Realtime category & search filtering
 * - Direct click to open the Full Reading Modal Dialog
 * - Tabular Thai date & time formatting
 */
// Sheet/API text is never HTML; URLs have a separate protocol boundary.
function escapeNewsHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function safeNewsUrl(value) {
  if (typeof value !== 'string') return '';
  try {
    const url = new URL(value);
    return url.protocol === 'http:' || url.protocol === 'https:' ? url.href : '';
  } catch (_) {
    return '';
  }
}

class FeedEngine {
  constructor(listContainerId, counterBadgeId, onFeedCardClick) {
    this.listContainer = document.getElementById(listContainerId);
    this.counterBadge = document.getElementById(counterBadgeId);
    this.onFeedCardClick = onFeedCardClick;

    this.events = [];
    this.activeCategories = new Set(['ธุรกิจ', 'เศรษฐกิจ', 'การเงิน', 'การเมือง', 'คริปโต', 'สงคราม']);
    this.searchQuery = '';
    this.viewStart = 0;
    this.viewEnd = 0;
    this.selectedEvent = null;
    this.batchSize = 40;
    this.visibleCount = this.batchSize;

    this.categories = {
      'ธุรกิจ': { color: '#60A5FA', tint: 'rgba(96, 165, 250, 0.12)', border: 'rgba(96, 165, 250, 0.3)', icon: '🏢' },
      'เศรษฐกิจ': { color: '#34D399', tint: 'rgba(52, 211, 153, 0.12)', border: 'rgba(52, 211, 153, 0.3)', icon: '🌐' },
      'การเงิน': { color: '#FBBF24', tint: 'rgba(251, 191, 36, 0.12)', border: 'rgba(251, 191, 36, 0.3)', icon: '💰' },
      'การเมือง': { color: '#FB7185', tint: 'rgba(251, 113, 133, 0.12)', border: 'rgba(251, 113, 133, 0.3)', icon: '🏛️' },
      'คริปโต': { color: '#C084FC', tint: 'rgba(192, 132, 252, 0.12)', border: 'rgba(192, 132, 252, 0.3)', icon: '🪙' },
      'สงคราม': { color: '#FDBA74', tint: 'rgba(253, 186, 116, 0.12)', border: 'rgba(253, 186, 116, 0.3)', icon: '⚔️' }
    };
  }

  setEvents(events) {
    this.events = events;
    this.visibleCount = this.batchSize;
  }

  setFilters(activeCategories, searchQuery, viewStart, viewEnd) {
    this.activeCategories = new Set(activeCategories);
    this.searchQuery = (searchQuery || '').toLowerCase().trim();
    this.viewStart = viewStart;
    this.viewEnd = viewEnd;
    this.visibleCount = this.batchSize;
    this.render();
  }

  setSelectedEvent(ev) {
    this.selectedEvent = ev;
    this.updateCardSelectionHighlight();
  }

  formatDateTime(d) {
    const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    const day = d.getDate();
    const month = months[d.getMonth()];
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    return `${day} ${month} ${year}, ${hours}:${minutes} น.`;
  }

  highlightMatch(text) {
    text = String(text ?? '');
    if (!this.searchQuery) return escapeNewsHtml(text);
    const regex = new RegExp(`(${this.escapeRegex(this.searchQuery)})`, 'gi');
    return text.split(regex).map((part, index) => index % 2
      ? `<mark class="bg-[#e5a93c]/90 text-slate-950 px-1 rounded font-semibold">${escapeNewsHtml(part)}</mark>`
      : escapeNewsHtml(part)).join('');
  }

  escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  render() {
    if (!this.listContainer) return;

    // Filter by category & search
    let filtered = this.events.filter(ev => {
      if (!this.activeCategories.has(ev.category)) return false;
      if (this.searchQuery) {
        const q = this.searchQuery;
        const matchTitle = ev.title && ev.title.toLowerCase().includes(q);
        const matchSummary = ev.summary && ev.summary.toLowerCase().includes(q);
        const matchDetails = ev.details && ev.details.toLowerCase().includes(q);
        const matchProvider = ev.provider && ev.provider.toLowerCase().includes(q);
        if (!matchTitle && !matchSummary && !matchDetails && !matchProvider) return false;
      }
      return true;
    });

    // Filter by visible time window
    const inViewEvents = filtered.filter(ev => 
      ev.timestamp >= this.viewStart && ev.timestamp <= this.viewEnd
    ).sort((a, b) => b.timestamp - a.timestamp);

    // Update Counter
    if (this.counterBadge) {
      this.counterBadge.innerText = `${inViewEvents.length} ข่าว`;
    }

    // Empty state
    if (inViewEvents.length === 0) {
      this.listContainer.innerHTML = `
        <div class="col-span-full editorial-card p-10 text-center text-slate-400 flex flex-col items-center justify-center gap-3 my-2">
          <span class="text-3xl">${this.searchQuery ? '🔍' : '⏳'}</span>
          <p class="text-sm font-semibold text-slate-200">
            ${this.searchQuery ? `ไม่พบข่าวที่ตรงกับ "${escapeNewsHtml(this.searchQuery)}"` : 'ไม่พบข่าวในช่วงเวลาที่เลือก'}
          </p>
          <p class="text-xs text-slate-500">
            ลองปรับเลื่อนแถบเวลา หรือคลิกปุ่ม 7D / 14D / ALL เพื่อขยายมุมมอง
          </p>
        </div>
      `;
      return;
    }

    // Render Clean News Cards
    this.listContainer.innerHTML = inViewEvents.slice(0, this.visibleCount).map(ev => {
      const cfg = this.categories[ev.category] || this.categories['ธุรกิจ'];
      const timeStr = this.formatDateTime(new Date(ev.timestamp));
      const isSelected = this.selectedEvent && this.selectedEvent.id === ev.id;
      const highlightedTitle = this.highlightMatch(ev.title);
      const highlightedSummary = this.highlightMatch(ev.summary);
      const realUrl = safeNewsUrl(ev.source_url || ev.source_link || '');
      const sourceName = escapeNewsHtml(ev.source_name || ev.provider || 'ข่าวต้นทาง');
      const hasRealUrl = Boolean(realUrl);

      return `
        <article 
          class="editorial-card p-4 cursor-pointer flex flex-col justify-between gap-3 h-full ${isSelected ? 'active-selected' : ''}"
          data-id="${escapeNewsHtml(ev.id)}"
          tabindex="0"
          role="button"
          aria-label="ข่าว: ${escapeNewsHtml(ev.title)}"
        >
          <div class="flex flex-col gap-2">
            <!-- Metadata Row -->
            <div class="flex items-center justify-between gap-2">
              <span class="text-xs font-semibold px-2 py-0.5 rounded flex items-center gap-1" style="background-color: ${cfg.tint}; color: ${cfg.color}; border: 1px solid ${cfg.border}">
                <span>${cfg.icon}</span>
                <span>${escapeNewsHtml(ev.category)}</span>
              </span>
              <span class="text-xs font-mono text-slate-400 ml-auto">${timeStr}</span>
            </div>

            <!-- Headline -->
            <h4 class="text-[14.5px] font-bold text-white leading-snug line-clamp-2 mt-0.5 hover:text-[#e5a93c] transition">
              ${highlightedTitle}
            </h4>

            <!-- Summary -->
            <p class="text-[13px] text-slate-200 line-clamp-2 leading-relaxed">
              ${highlightedSummary || 'คลิกเพื่อเปิดอ่านเนื้อหาข่าวฉบับเต็มและแหล่งข้อมูล...'}
            </p>
          </div>

          <!-- Bottom Source & Action -->
          <div class="flex items-center justify-between text-xs pt-2.5 border-t border-[#1c2333] text-slate-400 mt-auto">
            <div class="flex items-center gap-1 font-mono text-xs truncate max-w-[170px]">
              <span class="text-slate-500">แหล่ง:</span>
              ${hasRealUrl ? `
                <a href="${escapeNewsHtml(realUrl)}" target="_blank" rel="noopener noreferrer" class="text-[#e5a93c] hover:underline flex items-center gap-0.5 font-medium truncate" title="คลิกเพื่อเปิดหน้าข่าวจริงจาก ${sourceName}">
                  <span class="truncate">${sourceName}</span>
                  <span class="text-[10px]">↗</span>
                </a>
              ` : `
                <span class="text-slate-300 truncate">${sourceName}</span>
              `}
            </div>
            <span class="text-[#e5a93c] text-xs font-semibold flex items-center gap-1 shrink-0 hover:underline">
              <span>อ่านข่าวเต็ม</span>
              <span>➔</span>
            </span>
          </div>
        </article>
      `;
    }).join('');

    // Attach click listeners to cards
    this.listContainer.querySelectorAll('article[data-id]').forEach(card => {
      const id = card.dataset.id;
      const ev = this.events.find(e => String(e.id) === id);
      if (!ev) return;

      const handleClick = (event) => {
        if (event && event.target.closest('a')) return;
        if (event && window.getSelection) {
          const selection = window.getSelection();
          if (selection && !selection.isCollapsed && (card.contains(selection.anchorNode) || card.contains(selection.focusNode))) return;
        }
        this.setSelectedEvent(ev);
        if (this.onFeedCardClick) {
          this.onFeedCardClick(ev);
        } else if (window.openDetailModal) {
          window.openDetailModal(ev);
        }
      };

      card.addEventListener('click', handleClick);
      card.addEventListener('keydown', (e) => {
        if (e.target === card && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          handleClick();
        }
      });
    });

    if (this.visibleCount < inViewEvents.length) {
      const more = document.createElement('button');
      more.type = 'button';
      more.className = 'col-span-full px-3 py-2 rounded bg-[#131722] text-[#e5a93c] border border-[#1c2333] text-xs font-semibold';
      more.textContent = `แสดงเพิ่ม (${inViewEvents.length - this.visibleCount} ข่าวที่เหลือ)`;
      more.setAttribute('aria-controls', this.listContainer.id);
      more.addEventListener('click', () => {
        const nextIndex = this.visibleCount;
        this.visibleCount += this.batchSize;
        this.render();
        // Keep keyboard focus at the first newly revealed result.
        const cards = this.listContainer.querySelectorAll('article[data-id]');
        if (cards[nextIndex]) cards[nextIndex].focus();
      });
      this.listContainer.appendChild(more);
    }
  }

  updateCardSelectionHighlight() {
    if (!this.listContainer) return;
    this.listContainer.querySelectorAll('article[data-id]').forEach(card => {
      if (this.selectedEvent && card.dataset.id === this.selectedEvent.id) {
        card.classList.add('active-selected');
      } else {
        card.classList.remove('active-selected');
      }
    });
  }
}
