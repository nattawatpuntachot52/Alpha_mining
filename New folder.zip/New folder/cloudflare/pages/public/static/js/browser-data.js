/* Public data adapter. Heavy XLSX/JSON parsing runs only in the dedicated worker. */
'use strict';
class BrowserDataAdapter {
  constructor(fetcher = (...args)=>fetch(...args), workerFactory = ()=>new Worker('/static/js/xlsx-worker.js')) {
    this.fetcher=fetcher; this.workerFactory=workerFactory; this.sequence=0; this.lastEvents=null; this.lastPrices=null;
  }
  async bytes(url, limit, options={}) {
    const controller = new AbortController();
    const response = await this.fetcher(url,{...options,cache:'no-store',signal:controller.signal});
    if (!response.ok) throw Error('Public data request failed');
    if (Number(response.headers.get('content-length')) > limit) { controller.abort(); throw Error('Download byte limit exceeded'); }
    if (!response.body || !response.body.getReader) { controller.abort(); throw Error('Bounded streaming downloads are unavailable'); }
    const reader=response.body.getReader(), chunks=[]; let size=0;
    try {
      while (true) {
        const {done,value}=await reader.read(); if (done) break;
        size+=value.byteLength;
        if (size>limit) { controller.abort(); await reader.cancel(); throw Error('Download byte limit exceeded'); }
        chunks.push(value);
      }
    } finally { reader.releaseLock(); }
    const bytes=new Uint8Array(size); let offset=0;
    chunks.forEach(chunk=>{ bytes.set(chunk,offset); offset+=chunk.byteLength; });
    return bytes.buffer;
  }
  parse(type, buffer, extra={}) {
    return new Promise((resolve,reject)=>{
      const worker=this.workerFactory(), id=++this.sequence;
      const finish=(error,result)=>{ clearTimeout(timer); worker.terminate(); error?reject(error):resolve(result); };
      const timer=setTimeout(()=>finish(Error('Data parser timed out')),30000);
      worker.onmessage=event=>{ if (event.data && event.data.id===id) finish(event.data.error?Error(event.data.error):null,event.data.result); };
      worker.onerror=()=>finish(Error('Data worker failed'));
      try { worker.postMessage({id,type,buffer,...extra},[buffer]); } catch (error) { finish(error); }
    });
  }
  async events(payload) {
    if (!payload.client_mode) return payload;
    if (payload.client_mode!=='browser-xlsx-v1') throw Error('Unsupported client data mode');
    try {
      const result=await this.parse('factnews',await this.bytes('/api/raw/events',8*1024*1024));
      this.lastEvents=result; return result;
    } catch (error) {
      if (!this.lastEvents) throw error;
      return {...this.lastEvents,freshness:{...this.lastEvents.freshness,source_mode:'cache_fallback',status:'stale',stale:true,
        checked_at:new Date().toISOString(),fetch_error:String(error.message).slice(0,200)}};
    }
  }
  async prices(payload, query) {
    if (!payload.client_mode) return payload;
    if (payload.client_mode!=='browser-xlsx-v1') throw Error('Unsupported client data mode');
    const officialUrl='https://data-api.binance.vision/api/v3/klines';
    const transport=payload.prices_transport || 'proxy';
    if (!['proxy','browser-direct'].includes(transport) || (transport==='browser-direct' && payload.prices_url!==officialUrl) || (transport==='proxy' && payload.prices_url!==undefined)) throw Error('Untrusted market-data directive');
    const direct=transport==='browser-direct';
    const steps={'1s':1000,'1m':60000,'3m':180000,'5m':300000,'15m':900000,'30m':1800000,'1h':3600000,'2h':7200000,'4h':14400000,'6h':21600000,'8h':28800000,'12h':43200000,'1d':86400000,'3d':259200000,'1w':604800000};
    const symbol=String(query.symbol || 'BTCUSDT').toUpperCase(), interval=query.interval || '1h';
    const start=Number(query.start_ms ?? 1791417600000), now=Date.now(), end=Number(query.end_ms ?? now), limit=Math.min(end,now);
    if (!/^[A-Z0-9]{1,30}$/.test(symbol) || !(Object.prototype.hasOwnProperty.call(steps,interval) || interval==='1M') || !Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start<0 || end<start || end>253402300799999) throw Error('Invalid market range');
    const next=stamp=>{ if (interval!=='1M') return stamp+steps[interval]; const date=new Date(stamp); return Date.UTC(date.getUTCFullYear(),date.getUTCMonth()+1,1); };
    let floor;
    if (interval==='1M') { const date=new Date(start); floor=Date.UTC(date.getUTCFullYear(),date.getUTCMonth(),1); }
    else { const offset=interval==='1w'?345600000:0; floor=Math.floor((start-offset)/steps[interval])*steps[interval]+offset; }
    const first=floor<start?next(floor):floor;
    let cursor=first, error=null; const byTime=new Map();
    for (let page=0; page<5 && cursor<=limit; page++) {
      try {
        const params=new URLSearchParams({symbol,interval,limit:'1000'});
        params.set(direct?'startTime':'start_ms',String(cursor));
        params.set(direct?'endTime':'end_ms',String(limit));
        const url=(direct?officialUrl:'/api/raw/prices')+'?'+params;
        const options=direct?{mode:'cors',credentials:'omit',redirect:'error'}:{};
        const result=await this.parse('prices',await this.bytes(url,2*1024*1024,options),{start,end:limit});
        result.candles.forEach(candle=>byTime.set(candle.time,candle));
        if (result.latest===null || result.latest<cursor) throw Error('Binance page did not advance');
        cursor=next(result.latest);
      } catch (failure) { error=String(failure.message).slice(0,200); break; }
    }
    if (cursor<=limit && !error) error='Market pagination limit reached';
    const key=JSON.stringify([symbol,interval,start,end]);
    let fallback=false;
    if (error && !byTime.size && this.lastPrices && this.lastPrices.key===key) { this.lastPrices.result.candles.forEach(candle=>byTime.set(candle.time,candle)); fallback=true; }
    const candles=Array.from(byTime.values()).sort((a,b)=>a.time-b.time); let expected=first;
    while (expected<=limit && byTime.has(expected)) expected=next(expected);
    const complete=expected>limit && end<=now, stale=Boolean(error)||!complete;
    const result={symbol,interval,count:candles.length,candles,freshness:{source:fallback?'cache_fallback':candles.length?'binance':'none',
      status:!candles.length?'unavailable':stale?'stale':'fresh',stale:stale||!candles.length,coverage_complete:complete,
      requested_range:{start_ms:start,end_ms:end},returned_range:{start_ms:candles[0]?.time??null,end_ms:candles[candles.length-1]?.time??null},
      last_candle_time:candles[candles.length-1]?.time??null,as_of_ms:now,cache_ttl_seconds:0,fetch_error:error,cache_write_error:null}};
    if (!stale && candles.length) this.lastPrices={key,result};
    return result;
  }
}
globalThis.BrowserDataAdapter=BrowserDataAdapter;
globalThis.WriteTimeData=new BrowserDataAdapter();
