/**
 * WRITE TIME Editorial Intelligence Controller
 * Orchestrates Timeline, Minimap, Feed, and Full Reading Modal Dialog.
 */
document.addEventListener('DOMContentLoaded', async () => {
  // One reversible deployment flag; OFF never requests or executes GEO assets.
  let geoEnabled = document.documentElement.dataset.enableGeo === 'true';
  if (geoEnabled) {
    try {
      const stylesheet = document.createElement('link');
      stylesheet.rel = 'stylesheet';
      stylesheet.href = '/static/vendor/leaflet/leaflet.css';
      document.head.appendChild(stylesheet);
      for (const source of ['/static/vendor/leaflet/leaflet.js', '/static/js/worldmap.js']) {
        await new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = source;
          script.onload = resolve;
          script.onerror = () => reject(new Error('GEO asset unavailable'));
          document.head.appendChild(script);
        });
      }
    } catch (error) {
      geoEnabled = false;
      console.warn('GEO remains disabled:', error);
    }
  }
  const geoNavigation = document.getElementById('tabWorldMapBtn');
  if (geoNavigation) {
    geoNavigation.hidden = !geoEnabled;
    geoNavigation.inert = !geoEnabled;
    geoNavigation.style.display = geoEnabled ? '' : 'none';
  }
  const geoSection = document.getElementById('worldMapTabContent');
  if (geoSection) {
    geoSection.inert = !geoEnabled;
    if (geoEnabled) geoSection.removeAttribute('hidden');
    else {
      geoSection.hidden = true;
      geoSection.style.display = 'none';
    }
  }
  // Global State
  let allEvents = [];
  let priceCandles = [];
  const DAY_MS = 24 * 3600 * 1000;
  let viewEnd = Date.now();
  let viewStart = viewEnd - DAY_MS;
  let minTime = viewStart;
  let maxTime = viewEnd;
  let activePreset = 24;
  let previousEventCount = 0;
  let latestGeoScenarios = [];
  let eventsFreshness = null;
  let pricesFreshness = null;
  let loadPromise = null;
  let manualSyncInProgress = false;
  let modalOpen = false;
  let modalInvoker = null;
  let modalBackground = [];
  let previousOverflow = '';
  let closeTimelineTour = () => {};
  let refreshTimelineTour = () => {};

  function modalFocusables(modal) {
    return Array.from(modal.querySelectorAll('button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
      .filter(control => control.getClientRects().length > 0 && !control.closest('[inert]'));
  }

  const CATEGORIES = {
    'ธุรกิจ': { color: '#60A5FA', tint: 'rgba(96, 165, 250, 0.12)', border: 'rgba(96, 165, 250, 0.3)', icon: '🏢' },
    'เศรษฐกิจ': { color: '#34D399', tint: 'rgba(52, 211, 153, 0.12)', border: 'rgba(52, 211, 153, 0.3)', icon: '🌐' },
    'การเงิน': { color: '#FBBF24', tint: 'rgba(251, 191, 36, 0.12)', border: 'rgba(251, 191, 36, 0.3)', icon: '💰' },
    'การเมือง': { color: '#FB7185', tint: 'rgba(251, 113, 133, 0.12)', border: 'rgba(251, 113, 133, 0.3)', icon: '🏛️' },
    'คริปโต': { color: '#C084FC', tint: 'rgba(192, 132, 252, 0.12)', border: 'rgba(192, 132, 252, 0.3)', icon: '🪙' },
    'สงคราม': { color: '#FDBA74', tint: 'rgba(253, 186, 116, 0.12)', border: 'rgba(253, 186, 116, 0.3)', icon: '⚔️' }
  };
  const categoryNames = Object.keys(CATEGORIES);
  let activeCategories = new Set(categoryNames);
  let searchQuery = '';
  let showPriceCurve = true;
  let showNewsLabels = false;

  // Realtime Countdown State
  let countdownSeconds = 60;
  let countdownTimer = null;

  // 1. Initialize Reading Modal Functions
  window.openDetailModal = function(ev, invoker = document.activeElement) {
    if (!ev) return;
    // Reading always takes precedence over the optional guide.
    closeTimelineTour(false);
    const modal = document.getElementById('eventDetailModal');
    if (!modal) return;

    const cfg = CATEGORIES[ev.category] || CATEGORIES['ธุรกิจ'];
    const pubDate = new Date(ev.timestamp);
    const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    const timeFormatted = `${pubDate.getDate()} ${months[pubDate.getMonth()]} ${pubDate.getFullYear()}, ${String(pubDate.getHours()).padStart(2, '0')}:${String(pubDate.getMinutes()).padStart(2, '0')}:${String(pubDate.getSeconds()).padStart(2, '0')} น.`;

    // Populate Category Badge
    const badgeEl = document.getElementById('modalCategoryBadge');
    if (badgeEl) {
      badgeEl.textContent = `${cfg.icon} ${ev.category || ''}`;
      badgeEl.style.backgroundColor = cfg.tint;
      badgeEl.style.color = cfg.color;
      badgeEl.style.border = `1px solid ${cfg.border}`;
    }

    // Real Source URL & Name
    const realUrl = safeNewsUrl(ev.source_url || ev.source_link || '');
    const sourceName = ev.source_name || ev.provider || 'ข่าวต้นทาง';

    // Populate Time & Provider
    const timeEl = document.getElementById('modalTime');
    if (timeEl) timeEl.innerText = `🕒 ${timeFormatted}`;

    const providerLink = document.getElementById('modalProviderLink');
    const providerText = document.getElementById('modalProviderText');
    if (providerText) providerText.innerText = sourceName;
    if (providerLink) {
      if (realUrl) {
        providerLink.href = realUrl;
        providerLink.title = `คลิกเปิดดูข่าวจริงจาก ${sourceName}`;
        providerLink.style.display = 'inline-flex';
      } else {
        providerLink.removeAttribute('href');
      }
    }

    // Populate Title
    const titleEl = document.getElementById('modalTitle');
    if (titleEl) titleEl.innerText = ev.title || 'ไม่มีหัวข้อข่าว';

    // Populate Summary & Details
    const summaryEl = document.getElementById('modalSummary');
    if (summaryEl) summaryEl.innerText = ev.summary || '';

    const detailsEl = document.getElementById('modalDetails');
    if (detailsEl) {
      detailsEl.replaceChildren();
      if (ev.details && ev.details.trim().length > 0 && ev.details !== ev.summary) {
        ev.details.split(/\n\n/).forEach(text => {
          const paragraph = document.createElement('p');
          paragraph.textContent = text;
          paragraph.style.whiteSpace = 'pre-line';
          detailsEl.appendChild(paragraph);
        });
      }
    }

    // Populate Source Link in Footer
    const sourceLinkEl = document.getElementById('modalSourceLink');
    const sourceNameEl = document.getElementById('modalSourceName');
    const directBtn = document.getElementById('modalDirectSourceBtn');

    if (sourceNameEl) sourceNameEl.innerText = sourceName;
    if (sourceLinkEl) {
      if (realUrl) {
        sourceLinkEl.href = realUrl;
        sourceLinkEl.title = `คลิกเพื่อเปิดหน้าข่าวจริงจาก ${sourceName}`;
        sourceLinkEl.style.display = 'inline-flex';
      } else {
        sourceLinkEl.removeAttribute('href');
      }
    }

    if (directBtn) {
      if (realUrl) {
        directBtn.href = realUrl;
        directBtn.title = `เปิดหน้าเว็บข่าวจริงจาก ${sourceName} ในแท็บใหม่`;
        directBtn.style.display = 'inline-flex';
        directBtn.textContent = `🌐 เปิดอ่านเว็บข่าวจริง (${sourceName}) ↗`;
      } else {
        directBtn.removeAttribute('href');
        directBtn.style.display = 'none';
      }
    }

    // Show Modal immediately
    if (!modalOpen) {
      modalInvoker = invoker;
      previousOverflow = document.body.style.overflow;
      modalBackground = Array.from(document.body.children).filter(child => child !== modal && !['SCRIPT', 'STYLE', 'LINK'].includes(child.tagName))
        .map(element => ({ element, inert: element.inert }));
      modalBackground.forEach(({ element }) => { element.inert = true; });
    }
    modalOpen = true;
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    (document.getElementById('modalCloseBtn') || document.getElementById('eventDetailDialog')).focus({ preventScroll: true });

    // Safely highlight selected in timeline & feed
    try {
      if (typeof timeline !== 'undefined' && timeline && typeof timeline.setSelectedEvent === 'function') {
        timeline.setSelectedEvent(ev);
      }
      if (typeof feed !== 'undefined' && feed && typeof feed.setSelectedEvent === 'function') {
        feed.setSelectedEvent(ev);
      }
    } catch (err) {
      console.warn('Selection highlight error:', err);
    }
  };

  window.closeDetailModal = function() {
    if (!modalOpen) return;
    const modal = document.getElementById('eventDetailModal');
    if (modal) {
      modalOpen = false;
      modal.classList.add('hidden');
      document.body.style.overflow = previousOverflow;
      modalBackground.forEach(({ element, inert }) => { element.inert = inert; });
      modalBackground = [];
      let restoreTarget = modalInvoker;
      if (restoreTarget && restoreTarget.isConnected === false && restoreTarget.dataset.id) {
        restoreTarget = Array.from(document.querySelectorAll('article[data-id]')).find(card => card.dataset.id === modalInvoker.dataset.id);
      }
      if (!restoreTarget || restoreTarget.isConnected === false) restoreTarget = document.getElementById('timelineCanvas');
      if (restoreTarget) restoreTarget.focus({ preventScroll: true });
      modalInvoker = null;
    }
  };

  // Close modal on backdrop click
  const modalContainer = document.getElementById('eventDetailModal');
  if (modalContainer) {
    modalContainer.addEventListener('click', (e) => {
      if (e.target === modalContainer) {
        window.closeDetailModal();
      }
    });
  }

  // Keep keyboard focus inside the dialog until it closes.
  window.addEventListener('keydown', (e) => {
    if (!modalOpen) return;
    if (e.key === 'Escape') {
      e.preventDefault();
      window.closeDetailModal();
    } else if (e.key === 'Tab') {
      const modal = document.getElementById('eventDetailModal');
      const controls = modalFocusables(modal);
      const first = controls[0] || document.getElementById('eventDetailDialog');
      const last = controls[controls.length - 1] || first;
      if (!controls.length || !modal.contains(document.activeElement) || (e.shiftKey && document.activeElement === first) || (!e.shiftKey && document.activeElement === last)) {
        e.preventDefault();
        (e.shiftKey ? last : first).focus();
      }
    }
  });
  document.addEventListener('focusin', (e) => {
    if (modalOpen && !document.getElementById('eventDetailModal').contains(e.target)) {
      document.getElementById('modalCloseBtn').focus();
    }
  });

  // 2. Initialize Timeline Engine (Full Width)
  const timeline = new TimelineEngine(
    'timelineCanvas',
    'timelineContainer',
    'timelineTooltip',
    (ev) => window.openDetailModal(ev),
    (s, e) => handleWindowChange(s, e, 'timeline')
  );

  // 3. Initialize Minimap Panorama Engine
  const minimap = new MinimapEngine(
    'minimapCanvas',
    'minimapContainer',
    'minimapViewport',
    'handleLeft',
    'handleRight',
    (s, e) => handleWindowChange(s, e, 'minimap')
  );

  // 4. Initialize Synchronized News Feed Engine
  const feed = new FeedEngine(
    'eventsFeedList',
    'feedCounterBadge',
    (ev) => window.openDetailModal(ev)
  );

  // 5. Initialize World Map Engine
  if (geoEnabled && !window.worldMapEngine) {
    window.worldMapEngine = new WorldMapEngine('leafletMap');
  }

  // Main Tab Navigation Switcher
  window.switchMainTab = function(tabName) {
    if (!geoEnabled) tabName = 'market-timeline';
    const timelineContent = document.getElementById('marketTimelineTabContent');
    const worldMapContent = document.getElementById('worldMapTabContent');
    const tabTimelineBtn = document.getElementById('tabMarketTimelineBtn');
    const tabWorldMapBtn = document.getElementById('tabWorldMapBtn');
    const subtitle = document.getElementById('tabStatusSubtitle');
    if (subtitle) subtitle.textContent = tabName === 'world-map' ? 'แผนที่ข่าวและผลทบทวนรายวัน' : 'Timeline & Factnews Ready';

    if (tabName === 'world-map') {
      if (timelineContent) {
        timelineContent.style.display = 'none';
        timelineContent.classList.add('hidden');
      }
      if (worldMapContent) {
        worldMapContent.style.display = 'flex';
        worldMapContent.classList.remove('hidden');
      }

      if (tabTimelineBtn) {
        tabTimelineBtn.classList.remove('active', 'bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/50');
        tabTimelineBtn.classList.add('bg-[#131722]', 'text-slate-300', 'border-[#1c2333]');
      }
      if (tabWorldMapBtn) {
        tabWorldMapBtn.classList.remove('bg-[#131722]', 'text-slate-300', 'border-[#1c2333]');
        tabWorldMapBtn.classList.add('active', 'bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/50');
      }

      // Initialize map on first view and always force size invalidation
      if (geoEnabled && window.worldMapEngine) {
        if (!window.worldMapEngine.isInitialized) {
          window.worldMapEngine.init();
        }
        if (allEvents && allEvents.length > 0) {
          window.worldMapEngine.setData(allEvents, latestGeoScenarios);
        }
        requestAnimationFrame(() => {
          window.worldMapEngine.invalidateSize();
        });
        setTimeout(() => {
          window.worldMapEngine.invalidateSize();
        }, 150);
        setTimeout(() => {
          window.worldMapEngine.invalidateSize();
        }, 400);
      }
    } else {
      if (worldMapContent) {
        worldMapContent.style.display = 'none';
        worldMapContent.classList.add('hidden');
      }
      if (timelineContent) {
        timelineContent.style.display = 'flex';
        timelineContent.classList.remove('hidden');
      }

      if (tabWorldMapBtn) {
        tabWorldMapBtn.classList.remove('active', 'bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/50');
        tabWorldMapBtn.classList.add('bg-[#131722]', 'text-slate-300', 'border-[#1c2333]');
      }
      if (tabTimelineBtn) {
        tabTimelineBtn.classList.remove('bg-[#131722]', 'text-slate-300', 'border-[#1c2333]');
        tabTimelineBtn.classList.add('active', 'bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/50');
      }

      // Repaint timeline
      if (timeline) timeline.render();
      if (minimap) minimap.render();
    }
  };

  // Repaint canvas as soon as webfonts (Prompt, JetBrains Mono, etc.) finish loading
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => {
      if (timeline) timeline.render();
      if (minimap) minimap.render();
    });
  }

  // Sync window changes across timeline, minimap, and news feed
  function handleWindowChange(s, e, source) {
    viewStart = s;
    viewEnd = e;
    if (!['init', 'preset'].includes(source)) activePreset = null;
    updatePresetButtons();

    if (source !== 'timeline') timeline.setWindow(s, e);
    if (source !== 'minimap') minimap.setWindow(s, e);

    updateVisibleWindowLabel();
    feed.setFilters(activeCategories, searchQuery, viewStart, viewEnd);
    refreshTimelineTour();
  }

  function updatePresetButtons() {
    document.querySelectorAll('.preset-btn').forEach(btn => {
      const selected = activePreset !== null && Number(btn.dataset.hours) === activePreset;
      btn.classList.toggle('active', selected);
      btn.classList.toggle('bg-[#e5a93c]/20', selected);
      btn.classList.toggle('text-[#e5a93c]', selected);
      btn.classList.toggle('border-[#e5a93c]/50', selected);
      btn.classList.toggle('text-slate-300', !selected);
      btn.setAttribute('aria-pressed', String(selected));
    });
  }

  function updateTimeBounds() {
    const now = Date.now();
    minTime = Math.min(now - DAY_MS, viewStart);
    maxTime = Math.max(now, viewEnd);
    allEvents.forEach(event => {
      const stamp = Number(event.timestamp);
      if (Number.isFinite(stamp) && stamp > 0) {
        minTime = Math.min(minTime, stamp);
        maxTime = Math.max(maxTime, stamp);
      }
    });
  }

  function updateEngineData() {
    timeline.setData(allEvents, minTime, maxTime, priceCandles);
    minimap.setData(allEvents, minTime, maxTime);
    const rangeLabel = document.getElementById('minimapRangeLabel');
    const format = value => new Date(value).toLocaleDateString('th-TH', { timeZone: 'Asia/Bangkok', day: 'numeric', month: 'short', year: 'numeric' });
    if (rangeLabel) rangeLabel.textContent = `${format(minTime)} – ${format(maxTime)}`;
  }

  function updateVisibleWindowLabel() {
    const sDate = new Date(viewStart);
    const eDate = new Date(viewEnd);
    const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    const format = (d) => `${d.getDate()} ${months[d.getMonth()]} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    const el = document.getElementById('currentVisibleWindowLabel');
    if (el) el.innerText = `${format(sDate)} - ${format(eDate)}`;
  }

  // Synchronize Filters
  function applyFilters() {
    timeline.setFilters(activeCategories, searchQuery);
    minimap.setFilters(activeCategories, searchQuery);
    feed.setFilters(activeCategories, searchQuery, viewStart, viewEnd);

    // Update Dropdown value
    const catSelect = document.getElementById('categorySelect');
    if (catSelect) {
      if (activeCategories.size === categoryNames.length) {
        catSelect.value = 'all';
      } else if (activeCategories.size === 1) {
        catSelect.value = Array.from(activeCategories)[0];
      } else {
        catSelect.value = 'custom';
      }
    }

    renderCategoryChips();
    refreshTimelineTour();
  }

  function freshnessState(metadata) {
    const source = metadata && (metadata.source_mode || metadata.source);
    if (!metadata) return { state: 'unknown', label: 'ยังไม่ทราบสถานะ' };
    if (metadata.status === 'error') return { state: 'error', label: 'เชื่อมต่อไม่สำเร็จ' };
    if (metadata.status === 'unavailable') return { state: 'unavailable', label: 'ไม่มีข้อมูล' };
    if (source === 'cache_fallback') return { state: 'cache_fallback', label: 'แคชสำรอง / ข้อมูลเก่า' };
    if (metadata.stale || metadata.status === 'stale') return { state: 'stale', label: 'ข้อมูลเก่า' };
    if (metadata.status === 'degraded' || metadata.fetch_error || metadata.cache_write_error) return { state: 'degraded', label: 'ทำงานได้บางส่วน' };
    if (metadata.status === 'local') return { state: 'local', label: 'แคชในเครื่อง' };
    if (metadata.status === 'fresh') return { state: 'fresh', label: 'สด' };
    return { state: 'unknown', label: 'ยังไม่ทราบสถานะ' };
  }

  function freshnessTime(value) {
    if (value === null || value === undefined || value === '') return 'ไม่ทราบเวลา';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? 'ไม่ทราบเวลา' : date.toLocaleString('th-TH', {
      timeZone: 'Asia/Bangkok', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
    });
  }

  function renderFreshness() {
    const news = freshnessState(eventsFreshness);
    const prices = freshnessState(pricesFreshness);
    const fresh = news.state === 'fresh' && prices.state === 'fresh';
    const states = [news.state, prices.state];
    const label = fresh ? 'Realtime' : states.includes('error') ? 'เชื่อมต่อขัดข้อง' : states.includes('unavailable') ? 'ข้อมูลไม่พร้อม' : states.some(state => state === 'stale' || state === 'cache_fallback') ? 'ข้อมูลเก่า / แคช' : states.includes('degraded') ? 'ทำงานได้บางส่วน' : states.includes('local') ? 'แคชในเครื่อง' : 'รอตรวจสอบ';
    const realtime = document.getElementById('realtimeLabel');
    if (realtime) realtime.innerText = label;
    const indicator = document.getElementById('realtimeIndicator');
    if (indicator) indicator.dataset.state = fresh ? 'fresh' : states.find(state => state !== 'fresh');
    const dot = document.getElementById('realtimeDot');
    if (dot) dot.classList.toggle('animate-pulse', fresh);
    const newsTime = eventsFreshness && (eventsFreshness.last_live_success_at || eventsFreshness.cache_updated_at || eventsFreshness.checked_at);
    const priceTime = pricesFreshness && pricesFreshness.last_candle_time;
    const description = `ข่าว: ${news.label} (${freshnessTime(newsTime)}) • ราคา: ${prices.label} (${freshnessTime(priceTime)})`;
    const modified = document.getElementById('lastModifiedBadge');
    if (modified) modified.innerText = description;
    const status = document.getElementById('freshnessStatus');
    if (status) status.textContent = description;
    return fresh;
  }

  // Read cached server state; the server watcher owns automatic upstream sync.
  function loadData(showToast = false) {
    if (!loadPromise) loadPromise = fetchData(showToast).finally(() => { loadPromise = null; });
    return loadPromise;
  }

  async function fetchData(showToast = false) {
    try {
      const resp = await fetch('/api/events');
      if (!resp.ok) throw new Error('API events error');
      const payload = await resp.json();
      if (payload.client_mode && !window.WriteTimeData) throw new Error('Browser data adapter unavailable');
      const data = window.WriteTimeData ? await window.WriteTimeData.events(payload) : payload;
      eventsFreshness = data.freshness || null;

      allEvents = data.events || [];
      const currentCount = allEvents.length;

      // Keep the clock and the reader's chosen window inside both engine bounds.
      // Sparse, stale or empty news must never shrink the default 24-hour window.
      updateTimeBounds();

      // Fetch Market Price overlay
      try {
        const priceResp = await fetch(`/api/prices?symbol=BTCUSDT&interval=1h&start_ms=${minTime}&end_ms=${maxTime}`);
        if (!priceResp.ok) throw new Error('API prices error');
        const pricePayload = await priceResp.json();
        if (pricePayload.client_mode && !window.WriteTimeData) throw new Error('Browser price adapter unavailable');
        const priceData = window.WriteTimeData ? await window.WriteTimeData.prices(pricePayload, {symbol: 'BTCUSDT', interval: '1h', start_ms: minTime, end_ms: maxTime}) : pricePayload;
        priceCandles = priceData.candles || [];
        pricesFreshness = priceData.freshness || null;
      } catch (err) {
        pricesFreshness = { ...pricesFreshness, status: 'error' };
        console.warn('Market price fetch failed:', err);
      }

      // Populate counts & stats
      const totalBadge = document.getElementById('totalCountBadge');
      if (totalBadge) totalBadge.innerText = allEvents.length;

      const fresh = renderFreshness();

      // Set data in engines
      updateEngineData();
      feed.setEvents(allEvents);
      latestGeoScenarios = data.geo_scenarios || [];
      if (geoEnabled && window.worldMapEngine) {
        window.worldMapEngine.setData(allEvents, latestGeoScenarios);
      }

      const timelineCountBadge = document.getElementById('timelineCountBadge');
      if (timelineCountBadge) timelineCountBadge.innerText = `${allEvents.length} ข่าว`;

      renderCategoryChips();
      handleWindowChange(viewStart, viewEnd, 'init');

      if (showToast) {
        const diff = currentCount - previousEventCount;
        if (!fresh) {
          showNotificationToast(`⚠ อ่านข้อมูลแล้ว: ข่าว ${freshnessState(eventsFreshness).label} • ราคา ${freshnessState(pricesFreshness).label}`);
        } else if (previousEventCount > 0 && diff > 0) {
          showNotificationToast(`⚡ อัปเดตข้อมูลสำเร็จ! พบ ${diff} ข่าวใหม่`);
        } else {
          showNotificationToast(`✓ อัปเดตข้อมูลล่าสุดเรียบร้อย (${currentCount} ข่าว)`);
        }
      }
      previousEventCount = currentCount;
      return true;

    } catch (e) {
      console.error('Data loading error:', e);
      eventsFreshness = { ...eventsFreshness, status: 'error' };
      renderFreshness();
      if (showToast) showNotificationToast('⚠ โหลดข้อมูลหลังซิงค์ไม่สำเร็จ กรุณาลองอีกครั้ง');
      const feedList = document.getElementById('eventsFeedList');
      if (feedList) {
        feedList.innerHTML = `
          <div class="col-span-full editorial-card p-6 border-rose-500/30 text-center text-rose-300 text-xs">
            ⚠️ ไม่สามารถเชื่อมต่อ API ได้ กำลังลองเชื่อมต่อใหม่...
          </div>
        `;
      }
      return false;
    }
  }

  // Realtime Countdown Engine (60s loop)
  function startRealtimeCountdown() {
    if (countdownTimer) clearInterval(countdownTimer);
    countdownSeconds = 60;

    countdownTimer = setInterval(async () => {
      countdownSeconds--;
      const badge = document.getElementById('countdownBadge');
      if (badge) badge.innerText = `${countdownSeconds}s`;

      if (countdownSeconds <= 0) {
        countdownSeconds = 60;
        if (!manualSyncInProgress) await loadData(false);
      }
    }, 1000);
  }

  // Only an explicit manual action forces an upstream sync.
  window.triggerManualSync = async function() {
    if (manualSyncInProgress) return;
    manualSyncInProgress = true;
    const btn = document.getElementById('refreshBtn');
    if (btn) btn.classList.add('animate-spin');

    try {
      if (loadPromise) await loadPromise;
      const resp = await fetch('/api/sync', { method: 'POST' });
      if (!resp.ok) throw new Error(`Sync HTTP ${resp.status}`);
      await loadData(true);
    } catch (e) {
      console.error('Sync failed:', e);
      showNotificationToast('⚠ ซิงค์ข้อมูลไม่สำเร็จ กรุณาลองอีกครั้ง');
    } finally {
      manualSyncInProgress = false;
      if (btn) btn.classList.remove('animate-spin');
      countdownSeconds = 60;
    }
  };

  function showNotificationToast(msg) {
    const toast = document.getElementById('syncToast');
    const toastText = document.getElementById('syncToastText');
    if (!toast || !toastText) return;

    toastText.innerText = msg;
    toast.classList.remove('translate-y-[-20px]', 'opacity-0');
    toast.classList.add('translate-y-0', 'opacity-100');

    setTimeout(() => {
      toast.classList.remove('translate-y-0', 'opacity-100');
      toast.classList.add('translate-y-[-20px]', 'opacity-0');
    }, 3500);
  }

  // Category Select Dropdown
  function setupCategoryDropdown() {
    const select = document.getElementById('categorySelect');
    if (!select) return;

    select.addEventListener('change', (e) => {
      const val = e.target.value;
      if (val === 'all') {
        activeCategories = new Set(categoryNames);
      } else if (val === 'custom') {
        // Keep current custom selection
      } else {
        activeCategories = new Set([val]);
      }
      applyFilters();
    });
  }

  // Category Filter Chips
  function renderCategoryChips() {
    const container = document.getElementById('categoryChipsContainer');
    if (!container) return;
    container.innerHTML = '';

    categoryNames.forEach(cat => {
      const cfg = CATEGORIES[cat];
      const count = allEvents.filter(e => e.category === cat).length;
      const isActive = activeCategories.has(cat);

      const btn = document.createElement('button');
      btn.className = `flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium border transition ${
        isActive 
          ? 'text-white border-opacity-70' 
          : 'bg-[#12151e] border-[#1c2333] text-slate-500 opacity-40'
      }`;
      btn.style.backgroundColor = isActive ? cfg.tint : '';
      btn.style.borderColor = isActive ? cfg.border : '';
      btn.innerHTML = `<span>${cfg.icon}</span><span>${cat}</span><span class="text-[10px] font-mono opacity-80 bg-black/40 px-1 rounded">${count}</span>`;

      btn.onclick = () => {
        if (activeCategories.has(cat)) {
          if (activeCategories.size > 1) {
            activeCategories.delete(cat);
          } else {
            activeCategories = new Set(categoryNames);
          }
        } else {
          activeCategories.add(cat);
        }
        applyFilters();
      };

      container.appendChild(btn);
    });
  }

  // Time Preset Handlers
  window.setZoomPreset = function(hours) {
    activePreset = hours;
    viewEnd = Date.now();
    viewStart = viewEnd - (hours || 24) * 3600 * 1000;
    updateTimeBounds();
    if (hours === 0) {
      viewStart = minTime;
      viewEnd = maxTime;
    }
    updateEngineData();
    handleWindowChange(viewStart, viewEnd, 'preset');
  };

  window.zoomStep = function(factor) {
    const currentSpan = viewEnd - viewStart;
    const center = (viewStart + viewEnd) / 2;
    const newSpan = Math.max(2 * 3600 * 1000, Math.min(maxTime - minTime, currentSpan * factor));

    viewStart = Math.max(minTime, center - newSpan / 2);
    viewEnd = Math.min(maxTime, viewStart + newSpan);
    if (viewEnd >= maxTime) {
      viewStart = Math.max(minTime, maxTime - newSpan);
    }
    handleWindowChange(viewStart, viewEnd, 'zoomStep');
  };

  window.resetTimelineView = function() {
    window.setZoomPreset(24);
  };

  window.toggleOnlyCategory = function(cat) {
    activeCategories = new Set([cat]);
    applyFilters();
  };

  window.resetFilters = function() {
    activeCategories = new Set(categoryNames);
    searchQuery = '';
    const searchInput = document.getElementById('searchInput');
    if (searchInput) searchInput.value = '';
    document.getElementById('clearSearchBtn').classList.add('hidden');
    applyFilters();
  };

  window.togglePriceOverlayUI = function() {
    showPriceCurve = !showPriceCurve;
    const btn = document.getElementById('togglePriceBtn');
    if (showPriceCurve) {
      btn.classList.remove('bg-[#131722]', 'text-slate-400');
      btn.classList.add('bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/40');
      btn.innerHTML = '📈 กราฟราคา BTC: เปิด';
    } else {
      btn.classList.remove('bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/40');
      btn.classList.add('bg-[#131722]', 'text-slate-400');
      btn.innerHTML = '📈 กราฟราคา BTC: ปิด';
    }
    timeline.togglePriceOverlay(showPriceCurve);
  };

  window.toggleNewsLabelsUI = function(forceState) {
    if (typeof forceState === 'boolean') {
      showNewsLabels = forceState;
    } else {
      showNewsLabels = !showNewsLabels;
    }
    const btn = document.getElementById('toggleLabelsBtn');
    if (btn) {
      if (showNewsLabels) {
        btn.classList.remove('bg-[#131722]', 'text-slate-400', 'border-[#1c2333]');
        btn.classList.add('bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/40');
        btn.innerHTML = '🏷️ ป้ายชื่อข่าว: เปิด';
      } else {
        btn.classList.remove('bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/40');
        btn.classList.add('bg-[#131722]', 'text-slate-400', 'border-[#1c2333]');
        btn.innerHTML = '🏷️ ป้ายชื่อข่าว: ปิด';
      }
    }
    timeline.toggleEventLabels(showNewsLabels);
  };

  // Search input binding (Strict Filtering)
  const searchInput = document.getElementById('searchInput');
  const clearSearchBtn = document.getElementById('clearSearchBtn');

  searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value.trim();
    if (searchQuery) {
      clearSearchBtn.classList.remove('hidden');
      // Auto-turn on labels when searching for a topic so users can scan results immediately!
      if (!showNewsLabels) {
        window.toggleNewsLabelsUI(true);
      }
    } else {
      clearSearchBtn.classList.add('hidden');
    }
    applyFilters();
  });

  clearSearchBtn.addEventListener('click', () => {
    searchInput.value = '';
    searchQuery = '';
    clearSearchBtn.classList.add('hidden');
    applyFilters();
  });

  function setupTimelineTour() {
    const dialog = document.getElementById('timelineTourDialog');
    const spotlight = document.getElementById('timelineTourSpotlight');
    const help = document.getElementById('timelineTourHelpBtn');
    if (!dialog || !spotlight || !help) return () => {};
    const title = document.getElementById('timelineTourTitle');
    const description = document.getElementById('timelineTourDescription');
    const counter = document.getElementById('timelineTourCounter');
    const back = document.getElementById('timelineTourBackBtn');
    const next = document.getElementById('timelineTourNextBtn');
    const storageKey = 'writetime.timelineTour.shownDay.v1';
    const bangkokDay = () => new Date(Date.now() + 7 * 3600 * 1000).toISOString().slice(0, 10);
    const first = selector => Array.from(document.querySelectorAll(selector))[0];
    const byId = id => document.getElementById(id);
    const steps = [
      { title: 'เริ่มจากช่วงเวลาที่อยากอ่าน', text: 'ทุกครั้งที่เปิดหน้าใหม่ จะเริ่มที่ 24 ชั่วโมงล่าสุด เลือก 3D, 7D, 14D หรือ ALL เพื่อดูย้อนหลังได้ ปุ่ม ↺ จะกลับมา 24 ชั่วโมงล่าสุดค่ะ', targets: () => [byId('timePresetControls')] },
      { title: 'เลือกหมวดข่าว', text: 'เลือกหมวดจากเมนู หรือกดชื่อหมวดเพื่อเลือกหลายหมวดพร้อมกัน ข่าวบนกราฟและการ์ดด้านล่างจะกรองไปด้วยกันค่ะ', targets: () => [byId('categorySelect')] },
      { title: 'ค้นหาเรื่องที่สนใจ', text: 'พิมพ์คำค้นเพื่อกรองข่าวในช่วงเวลาที่เลือก ล้างคำค้นด้วยปุ่ม ✕ เมื่อต้องการกลับมาดูข่าวทั้งหมดในหมวดเดิมค่ะ', targets: () => [byId('searchInput')] },
      { title: 'เลื่อนเวลาและซูมกราฟ', text: 'บนคอมพิวเตอร์ ลากกราฟเพื่อเลื่อนเวลาและหมุนล้อเมาส์เพื่อซูม บนมือถือใช้ปุ่ม + / − และลากกรอบในแถบภาพรวมใต้กราฟได้ค่ะ', targets: () => [byId('timelineCanvas')] },
      { title: 'เปิดอ่านข่าว', text: 'กดจุดข่าวบนกราฟ หรือกดการ์ดข่าวด้านล่างเพื่ออ่านรายละเอียด ปิดหน้าต่างข่าวเพื่อกลับมาที่ Timeline ได้ค่ะ', empty: 'ช่วงเวลาและตัวกรองนี้ยังไม่มีข่าว เมื่อมีข่าว กดจุดบนกราฟหรือการ์ดด้านล่างเพื่ออ่านรายละเอียดได้ค่ะ', targets: () => [first('#eventsFeedList article[data-id]') || byId('newsFeedSection')], available: () => !!first('#eventsFeedList article[data-id]') },
      { title: 'เปิดข่าวจากแหล่งต้นทาง', text: 'กดชื่อแหล่งข่าวบนการ์ดเพื่อเปิดต้นฉบับในแท็บใหม่ ในหน้าต่างรายละเอียดก็มีปุ่ม “เปิดอ่านเว็บข่าวจริง” เช่นกันค่ะ', empty: 'ยังไม่มีลิงก์ต้นทางในข่าวที่แสดง เมื่อข่าวมีลิงก์ กดชื่อแหล่งข่าวบนการ์ดหรือปุ่ม “เปิดอ่านเว็บข่าวจริง” ในรายละเอียดได้ค่ะ', targets: () => [first('#eventsFeedList article a[href]') || byId('newsFeedSection')], available: () => !!first('#eventsFeedList article a[href]') },
      { title: 'ปรับกราฟให้อ่านง่าย', text: 'เปิดหรือปิดเส้นราคา BTC และป้ายชื่อข่าวได้ตามต้องการ พร้อมแล้วกด “เสร็จสิ้น” หากอยากทบทวน กด “วิธีใช้” ได้ทุกเมื่อค่ะ', targets: () => [byId('togglePriceBtn'), byId('toggleLabelsBtn')] }
    ];
    let index = 0;
    let opened = false;
    let invoker = null;
    let priorPadding = '';
    let shownDay = '';

    // If persistent storage is blocked, session storage still survives reloads.
    // With no writable storage, keep manual help available without repeat auto-popups.
    function claimDay() {
      const day = bangkokDay();
      if (shownDay === day) return false;
      const readableStores = [];
      for (const name of ['localStorage', 'sessionStorage']) {
        try {
          const storage = window[name];
          if (storage.getItem(storageKey) === day) { shownDay = day; return false; }
          readableStores.push(storage);
        } catch (_) { /* A blocked store may still have a working fallback. */ }
      }
      for (const storage of readableStores) {
        try {
          storage.setItem(storageKey, day);
          if (storage.getItem(storageKey) === day) { shownDay = day; return true; }
        } catch (_) { /* Storage restrictions must never interrupt news. */ }
      }
      return false;
    }

    function position(scrollToTarget = false) {
      if (!opened) return;
      const targets = steps[index].targets().filter(target => target && target.isConnected !== false);
      const rects = targets.map(target => target.getBoundingClientRect()).filter(rect => rect.width && rect.height);
      if (!rects.length) { spotlight.hidden = true; return; }
      let bounds = { left: Math.min(...rects.map(r => r.left)), top: Math.min(...rects.map(r => r.top)), right: Math.max(...rects.map(r => r.right)), bottom: Math.max(...rects.map(r => r.bottom)) };
      const viewport = window.visualViewport;
      const height = viewport ? viewport.height : window.innerHeight;
      const offsetTop = viewport ? viewport.offsetTop : 0;
      const width = document.documentElement.clientWidth;
      // Reserve space below the target, including for the last feed card on mobile.
      const cardHeight = dialog.getBoundingClientRect().height;
      dialog.style.bottom = `${Math.max(0, window.innerHeight - height - offsetTop) + 12}px`;
      document.body.style.paddingBottom = `calc(${priorPadding || '0px'} + ${cardHeight + 32}px)`;
      const availableBottom = offsetTop + height - cardHeight - 28;
      // Desktop masthead/navigation are sticky; search itself lives in that masthead.
      const stickyHeaders = ['appHeader', 'primaryNavigation'].map(byId).filter(element => element && window.getComputedStyle && ['sticky', 'fixed'].includes(window.getComputedStyle(element).position));
      const targetInHeader = stickyHeaders.some(header => targets.some(target => header.contains(target)));
      const headerBottom = targetInHeader ? 0 : Math.max(0, ...stickyHeaders.map(header => header.getBoundingClientRect().bottom));
      const topEdge = Math.max(offsetTop, headerBottom) + 12;
      if (scrollToTarget) {
        const targetHeight = Math.min(bounds.bottom - bounds.top, Math.max(44, availableBottom - topEdge));
        const desiredTop = topEdge + Math.max(0, (availableBottom - topEdge - targetHeight) / 2);
        window.scrollBy({ top: bounds.top - desiredTop, behavior: 'instant' });
        position(false);
        return;
      }
      bounds = { left: Math.max(4, bounds.left - 5), right: Math.min(width - 4, bounds.right + 5), top: Math.max(topEdge, bounds.top - 5), bottom: Math.min(availableBottom, bounds.bottom + 5) };
      spotlight.hidden = bounds.bottom <= bounds.top || bounds.right <= bounds.left;
      Object.assign(spotlight.style, { left: `${bounds.left}px`, top: `${bounds.top}px`, width: `${Math.max(0, bounds.right - bounds.left)}px`, height: `${Math.max(0, bounds.bottom - bounds.top)}px` });
    }

    function render(scrollToTarget = false) {
      if (!opened) return;
      const step = steps[index];
      title.textContent = step.title;
      description.textContent = step.available && !step.available() ? step.empty : step.text;
      counter.textContent = `${index + 1}/${steps.length}`;
      counter.setAttribute('aria-label', `ขั้นตอน ${index + 1} จาก ${steps.length}`);
      back.disabled = index === 0;
      next.textContent = index === steps.length - 1 ? 'เสร็จสิ้น' : 'ถัดไป';
      position(scrollToTarget);
    }

    function close(restoreFocus = true) {
      if (!opened) return;
      const hadFocus = dialog.contains(document.activeElement);
      opened = false;
      dialog.hidden = true;
      spotlight.hidden = true;
      document.body.style.paddingBottom = priorPadding;
      help.setAttribute('aria-expanded', 'false');
      if (restoreFocus && hadFocus) {
        const target = invoker && invoker.isConnected !== false ? invoker : help;
        target.focus({ preventScroll: true });
      }
    }

    function open(automatic = false) {
      if (opened || modalOpen) return;
      if (automatic && !claimDay()) return;
      if (!automatic) claimDay();
      window.switchMainTab('market-timeline');
      index = 0;
      invoker = document.activeElement === document.body ? help : document.activeElement;
      priorPadding = document.body.style.paddingBottom;
      opened = true;
      dialog.hidden = false;
      help.setAttribute('aria-expanded', 'true');
      render(true);
      next.focus({ preventScroll: true });
    }

    help.addEventListener('click', () => open(false));
    document.getElementById('timelineTourCloseBtn').addEventListener('click', () => close());
    document.getElementById('timelineTourSkipBtn').addEventListener('click', () => close());
    back.addEventListener('click', () => { if (index > 0) { index--; render(true); if (back.disabled) next.focus({ preventScroll: true }); } });
    next.addEventListener('click', () => { if (index === steps.length - 1) close(); else { index++; render(true); } });
    window.addEventListener('keydown', event => { if (opened && event.key === 'Escape') { event.preventDefault(); close(); } });
    window.addEventListener('resize', () => position());
    window.addEventListener('scroll', () => position(), { passive: true });
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', () => position());
      window.visualViewport.addEventListener('scroll', () => position());
    }
    closeTimelineTour = close;
    refreshTimelineTour = () => render();
    return () => open(true);
  }

  // Initialize the current clock window even when the first request fails.
  updateEngineData();
  handleWindowChange(viewStart, viewEnd, 'init');
  const showDailyTour = setupTimelineTour();
  // Initial load & Start Countdown
  setupCategoryDropdown();
  await loadData(false);
  startRealtimeCountdown();
  showDailyTour();
});
