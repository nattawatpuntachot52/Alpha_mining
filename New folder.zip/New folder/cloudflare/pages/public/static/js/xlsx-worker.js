/* SheetJS CE 0.20.3: locally vendored, Apache-2.0; see vendor/sheetjs/LICENSE. */
'use strict';
const MAX_XLSX_BYTES = 8 * 1024 * 1024;
const MAX_PRICE_BYTES = 2 * 1024 * 1024;
const domains = {'thai pbs':'https://www.thaipbs.or.th/news',coindesk:'https://www.coindesk.com',
  'the guardian':'https://www.theguardian.com/business','the guardian business':'https://www.theguardian.com/business',
  cnbc:'https://www.cnbc.com/world/',bbc:'https://www.bbc.com/news','the standard wealth':'https://thestandard.co/wealth/'};
function allowedUrl(value) {
  try { const url = new URL(String(value || '')); return ['http:', 'https:'].includes(url.protocol) ? url.href : ''; }
  catch (_) { return ''; }
}
function dateValue(value) {
  if (typeof value === 'number') {
    const date = XLSX.SSF.parse_date_code(value);
    return date ? Date.UTC(date.y, date.m - 1, date.d, date.H, date.M, date.S) - 25200000 : null;
  }
  const text = String(value || '').trim();
  if (/(?:Z|[+-]\d{2}:\d{2})$/i.test(text)) { const stamp = Date.parse(text); return Number.isFinite(stamp) ? stamp : null; }
  let match = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
  let parts;
  if (match) parts = [Number(match[1]), Number(match[2]), Number(match[3]), Number(match[4] || 0), Number(match[5] || 0), Number(match[6] || 0)];
  else {
    match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?: (\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (!match) return null;
    parts = [Number(match[3]), Number(match[2]), Number(match[1]), Number(match[4] || 0), Number(match[5] || 0), Number(match[6] || 0)];
  }
  const stamp = Date.UTC(parts[0], parts[1] - 1, parts[2], parts[3], parts[4], parts[5]);
  const check = new Date(stamp);
  if (check.getUTCFullYear() !== parts[0] || check.getUTCMonth() + 1 !== parts[1] || check.getUTCDate() !== parts[2] || parts[3] > 23 || parts[4] > 59 || parts[5] > 59) return null;
  return stamp - 25200000;
}
// Read scenario tables by header so reordering columns does not change the joins.
function scenarioRows(book, name, required) {
  const sheet = book.Sheets[name];
  if (!sheet || !sheet['!ref']) return [];
  const range = XLSX.utils.decode_range(sheet['!fullref'] || sheet['!ref']);
  if (range.e.r > 10000 || range.e.c > 63) return [];
  const columns = new Map();
  for (let c = range.s.c; c <= range.e.c; c++) {
    const key = String(sheet[XLSX.utils.encode_cell({r:range.s.r,c})]?.v ?? '').trim();
    if (required.includes(key)) {
      if (columns.has(key)) return [];
      columns.set(key,c);
    }
  }
  if (required.some(key => !columns.has(key))) return [];
  const rows = [];
  for (let r = range.s.r + 1; r <= range.e.r; r++) {
    const row = {};
    for (const [key,c] of columns) {
      const cell = sheet[XLSX.utils.encode_cell({r,c})];
      let value = cell?.v ?? '';
      if (typeof value === 'number' && key.endsWith('_ict')) {
        const parsed = XLSX.SSF.parse_date_code(value);
        if (parsed) {
          const two = n => String(n).padStart(2,'0');
          const day = `${parsed.y}-${two(parsed.m)}-${two(parsed.d)}`;
          value = key === 'date_ict' || key === 'window_start_ict' ? day
            : `${day}T${two(parsed.H)}:${two(parsed.M)}:${two(parsed.S)}+07:00`;
        }
      }
      if (key === 'canonical_url') value = allowedUrl(cell?.l?.Target || value);
      row[key] = String(value).trim();
    }
    if (row[required[0]]) rows.push(row);
  }
  return rows;
}

function uniqueRows(rows,key) {
  const result = new Map();
  for (const row of rows) result.set(row[key],result.has(row[key]) ? null : row);
  return result;
}

function parseScenarioReviews(book) {
  const daily = scenarioRows(book,'Scenario_Daily',[
    'review_id','date_ict','zone_id','zone_th','window_start_ict','cutoff_at_ict','decision','analysis_id',
    'carry_from_analysis_id','decision_reason_th','coverage_state','source_timing_state','prepared_at_ict'
  ]).filter(row => {
    const date = dateValue(row.date_ict);
    return /^\d{4}-\d{2}-\d{2}$/.test(row.date_ict) && date !== null &&
      row.cutoff_at_ict.startsWith(row.date_ict + 'T') && dateValue(row.cutoff_at_ict) !== null;
  });
  const analysis = uniqueRows(scenarioRows(book,'Scenario_Analysis',[
    'analysis_id','review_id','date_ict','zone_id','headline_th','confirmed_facts_th','why_new_th',
    'escalation_trigger_th','escalation_if_then_th','deescalation_trigger_th','deescalation_if_then_th',
    'watch_indicators_th','confidence','limitations_th','prepared_at_ict','evidence_ids'
  ]),'analysis_id');
  const evidence = uniqueRows(scenarioRows(book,'Scenario_Evidence',[
    'evidence_id','review_id','analysis_id','publisher','source_date_or_time','canonical_url','supports_th','timing_assessment'
  ]),'evidence_id');
  const byReview = uniqueRows(daily,'review_id');
  const dailyEvidence = new Map();
  for (const item of evidence.values()) {
    if (!item || !byReview.get(item.review_id)) continue;
    if (!dailyEvidence.has(item.review_id)) dailyEvidence.set(item.review_id,[]);
    dailyEvidence.get(item.review_id).push(item.evidence_id);
  }

  return daily.filter(day => byReview.get(day.review_id) === day).map(day => {
    const carry = day.decision === 'CARRY_FORWARD';
    const candidate = analysis.get(carry ? day.carry_from_analysis_id : day.analysis_id);
    const origin = candidate && byReview.get(candidate.review_id);
    // A historical review may link only to its own analysis or an explicitly carried, earlier one.
    const record = candidate && origin && origin.zone_id === day.zone_id && candidate.zone_id === day.zone_id &&
      origin.date_ict === candidate.date_ict && origin.analysis_id === candidate.analysis_id &&
      origin.decision === 'NEW_SCENARIO' && (carry ? origin.date_ict < day.date_ict :
        day.decision === 'NEW_SCENARIO' && origin.review_id === day.review_id) ? candidate : null;
    const ids = new Set(dailyEvidence.get(day.review_id) || []);
    if (record) for (const id of record.evidence_ids.split(/[,;\s]+/)) if (id) ids.add(id);
    const sources = [];
    for (const id of ids) {
      const item = evidence.get(id);
      const sourceDay = item && byReview.get(item.review_id);
      if (!sourceDay || sourceDay.zone_id !== day.zone_id || sourceDay.date_ict > day.date_ict ||
          (item.review_id !== day.review_id && sourceDay.date_ict > record.date_ict) ||
          (item.analysis_id && item.analysis_id !== record?.analysis_id)) continue;
      sources.push({...item, reviewed_on:sourceDay.date_ict});
    }
    return {...day,analysis:record,evidence:sources};
  });
}

function parseFactnews(buffer) {
  if (!self.XLSX) importScripts('/static/vendor/sheetjs/xlsx.mini.min.js');
  if (XLSX.version !== '0.20.3') throw Error('Unexpected spreadsheet library version');
  const book = XLSX.read(buffer, {type:'array', cellFormula:true, cellDates:false, sheetStubs:true, sheetRows:10020});
  const sheet = book.Sheets[book.SheetNames.includes('Factnews') ? 'Factnews' : book.SheetNames[0]];
  if (!sheet || !sheet['!ref']) throw Error('Workbook has no news sheet');
  const range = XLSX.utils.decode_range(sheet['!fullref'] || sheet['!ref']);
  if (range.e.r > 10000 || range.e.c > 63) throw Error('Workbook exceeds supported row/column limits');
  const cell = (row, column) => sheet[XLSX.utils.encode_cell({r:row,c:column})] || {};
  let header = -1, columns = {};
  for (let row = 0; row <= Math.min(13, range.e.r); row++) {
    const names = {};
    for (let column = 0; column <= range.e.c; column++) names[String(cell(row,column).v || '').trim().toLowerCase()] = column;
    if ('description' in names && 'category' in names) { header = row; columns = names; break; }
  }
  if (header < 0) throw Error('Workbook is missing Description/Category headers');
  const field = (row,name,fallback) => cell(row, columns[name] ?? fallback);
  const events = [];
  for (let row = header + 1; row <= range.e.r; row++) {
    const lines = String(field(row,'description',2).v || '').split(/\r?\n/).map(line=>line.trim()).filter(Boolean);
    if (!lines.length || ['None','nan'].includes(lines[0])) continue;
    const category = String(field(row,'category',1).v || 'ทั่วไป').trim();
    const provider = String(field(row,'provider',3).v || 'Factnews AI').trim();
    const source = field(row,'source link',4), raw = String(source.v || '').trim();
    const formula = String(source.f || raw).match(/HYPERLINK\s*\(\s*"(https?:\/\/[^"]+)"\s*(?:,\s*"([^"]*)")?\s*\)/i);
    let sourceUrl, sourceName;
    if (formula) { sourceUrl = allowedUrl(formula[1]); sourceName = formula[2] || formula[1]; }
    else if (source.l && source.l.Target) { sourceUrl = allowedUrl(source.l.Target); sourceName = raw || source.l.Target; }
    else if (allowedUrl(raw)) { sourceUrl = allowedUrl(raw); sourceName = raw; }
    else if (raw && !['None','nan'].includes(raw)) { sourceName = raw; sourceUrl = (Object.prototype.hasOwnProperty.call(domains,raw.toLowerCase()) ? domains[raw.toLowerCase()] : '') || 'https://www.google.com/search?q=' + encodeURIComponent(lines[0] + ' ' + raw); }
    else { sourceName = provider; sourceUrl = 'https://www.google.com/search?q=' + encodeURIComponent(lines[0]); }
    const stamp = dateValue(field(row,'published at',5).v) ?? dateValue(field(row,'date',0).v);
    const local = stamp === null ? '' : new Date(stamp + 25200000).toISOString();
    events.push({id:`evt-${String(events.length+1).padStart(4,'0')}`,title:lines[0],summary:lines[1] || '',details:lines.slice(2).join(' '),
      category:['','None','nan'].includes(category)?'ทั่วไป':category,provider:['','None','nan'].includes(provider)?'Factnews AI':provider,
      source_name:sourceName,source_url:sourceUrl,source_link:sourceUrl,timestamp:stamp ?? 0,
      published_at:local ? local.slice(0,19)+'+07:00':'',display_time:local ? `${local.slice(8,10)}/${local.slice(5,7)}/${local.slice(0,4)} ${local.slice(11,16)}`:''});
  }
  if (!events.length) throw Error('Workbook contains no news events');
  events.sort((a,b)=>a.timestamp-b.timestamp);
  const counts = Object.create(null);
  events.forEach(event=>{ counts[event.category]=(Object.prototype.hasOwnProperty.call(counts,event.category)?counts[event.category]:0)+1; });
  const checked = new Date().toISOString();
  return {status:'success',source:'Live Realtime Feed',file_name:'Factnews.xlsx',total_count:events.length,events,category_counts:counts,
    min_timestamp:events[0].timestamp,max_timestamp:events[events.length-1].timestamp,last_sync_time:new Date(Date.now()+25200000).toISOString().slice(0,19).replace('T',' '),geo_scenarios:parseScenarioReviews(book),
    freshness:{source_mode:'live',status:'fresh',stale:false,checked_at:checked,last_live_success_at:checked,cache_updated_at:null,fetch_error:null,cache_write_error:null}};
}
function parsePricePage(buffer, start, end) {
  const rows = JSON.parse(new TextDecoder().decode(buffer));
  if (!Array.isArray(rows) || rows.length > 1000) throw Error('Invalid bounded Binance page');
  const candles = []; let latest = null;
  for (const row of rows) {
    if (!Array.isArray(row) || row.length < 6) throw Error('Invalid Binance candle');
    const values = row.slice(0,6).map(Number);
    if (!values.every(Number.isFinite) || !Number.isSafeInteger(values[0]) || values[0] < 0) throw Error('Invalid finite Binance value');
    latest = latest === null ? values[0] : Math.max(latest,values[0]);
    if (values[0] >= start && values[0] <= end) candles.push(Object.fromEntries(['time','open','high','low','close','volume'].map((key,index)=>[key,values[index]])));
  }
  return {candles,latest};
}
self.onmessage = event => {
  const data = event.data || {};
  try {
    if (!(data.buffer instanceof ArrayBuffer) || !data.buffer.byteLength) throw Error('Empty or invalid worker buffer');
    const limit = data.type === 'factnews' ? MAX_XLSX_BYTES : MAX_PRICE_BYTES;
    if (data.buffer.byteLength > limit) throw Error('Worker byte limit exceeded');
    if (!['factnews','prices'].includes(data.type)) throw Error('Unknown parser message');
    const result = data.type === 'factnews' ? parseFactnews(data.buffer) : parsePricePage(data.buffer,data.start,data.end);
    self.postMessage({id:data.id,result});
  } catch (error) { self.postMessage({id:data.id,error:String(error.message || 'Parsing failed').slice(0,200)}); }
};
