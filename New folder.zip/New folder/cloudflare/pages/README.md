# WRITE TIME Pages package

Independent Pages advanced-mode package for `writetime.pages.dev`. The entry page enables World Map & Geopolitics through `data-enable-geo="true"`. The map matches Factnews in a 21-day window, and its two scenarios display their template source. XLSX parsing runs in the dedicated browser worker, and prices use the official Binance browser-direct endpoint. This build prepares the local deployment package.

From `D:\New folder`, prepare and verify locally:

```powershell
python -B cloudflare/pages/build_pages.py
node --check cloudflare/pages/worker.mjs
node --test tests/test_pages_contract.mjs
```

The build imports the existing 19-item `../build_assets.py` allowlist, copies only those assets, then stages `worker.mjs` as `public/_worker.js` and `_routes.json` as `public/_routes.json`. It refuses unexpected output files and symlinks. Only `public/` is uploadable; no workbook, cache, environment file, backend, tests, or project-tree upload.

Katherine owns project creation and deployment. Run Pages CLI commands from this directory so Wrangler selects this Pages config instead of the parent Python Worker config. Wrangler 4.156.0 supports hidden `--force` flags on project creation and deployment to bypass automatic Workers delegation (verified from installed official CLI source). For an existing Pages project, normal deployment is sufficient:

```powershell
# Only if the Pages project has not already been created:
npx wrangler pages project create writetime --production-branch main --force
npx wrangler pages deploy public --project-name writetime --branch main
```

These are instructions only; no account/deployment action is performed by the build/tests. This package uses no Python Worker flags, dependencies, account identifiers, secrets, paid bindings, or previous Worker hostname.

API routes preserve `/api/status`, `/api/events`, `/api/prices`, POST `/api/sync` and `/api/refresh`, and fixed raw proxies. Query validation permits only bounded price parameters, rejects duplicates/unknown keys, and maps `start_ms/end_ms` to Binance `startTime/endTime`. Raw proxies retain declared-length limits (8 MiB XLSX / 2 MiB prices); the unchanged browser adapter also enforces actual streamed byte limits. Bodies are streamed without server parsing. Upstream failures return safe JSON 502; API misses return JSON 404 and wrong methods return JSON 405. Static requests use Pages assets; `/api` and `/api/*` invoke the API runtime so API misses cannot become the Pages HTML fallback.

Local contracts do not establish live Pages/Free CPU, Google export availability, or browser CORS validation. Katherine must validate the deployed site/news/prices after deployment.

Official references: [advanced mode](https://developers.cloudflare.com/pages/functions/advanced-mode/), [routing](https://developers.cloudflare.com/pages/functions/routing/), [Pages Wrangler configuration](https://developers.cloudflare.com/pages/functions/wrangler-configuration/).
