"""Stage the existing approved web assets and only the Pages runtime controls."""
from pathlib import Path
import runpy
import shutil

ROOT = Path(__file__).resolve().parent
ASSETS = runpy.run_path(str(ROOT.parent / "build_assets.py"))["ASSETS"]


def build_pages():
    source, destination = ROOT.parent.parent / "static", ROOT / "public"
    source_root, destination_root = source.resolve(), destination.resolve()
    if destination.is_symlink() or not destination_root.is_relative_to(ROOT):
        raise ValueError("Unsafe Pages output directory")
    inputs = [(source / name, "index.html" if name == "index.html" else "static/" + name) for name in ASSETS]
    inputs += [(ROOT / "worker.mjs", "_worker.js"), (ROOT / "_routes.json", "_routes.json")]
    approved = {relative for _, relative in inputs}
    for path, relative in inputs:
        target = destination / relative
        root = source_root if path.is_relative_to(source) else ROOT
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError("Missing or unsafe approved Pages input")
        if target.is_symlink() or not target.resolve().is_relative_to(destination_root):
            raise ValueError("Unsafe Pages output target")
    if destination.exists():
        for path in destination.rglob("*"):
            if path.is_symlink() or (path.is_file() and path.relative_to(destination).as_posix() not in approved):
                raise ValueError("Unexpected Pages artifact; refusing unrelated content")
    for path, relative in inputs:
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    return sorted(approved)


if __name__ == "__main__":
    print("Staged", len(build_pages()), "Pages files (19 web assets + runtime + routing)")
