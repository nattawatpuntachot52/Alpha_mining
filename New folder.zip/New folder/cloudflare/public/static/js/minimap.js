/**
 * Phase 2: Mini-map Panorama & Brush Navigation Engine
 * Synchronized with filtered events.
 */
class MinimapEngine {
  constructor(canvasId, containerId, viewportId, handleLeftId, handleRightId, onBrushChange) {
    this.canvas = document.getElementById(canvasId);
    this.container = document.getElementById(containerId);
    this.viewport = document.getElementById(viewportId);
    this.handleLeft = document.getElementById(handleLeftId);
    this.handleRight = document.getElementById(handleRightId);
    this.ctx = this.canvas.getContext('2d');
    this.onBrushChange = onBrushChange;

    this.minTime = 0;
    this.maxTime = 0;
    this.viewStart = 0;
    this.viewEnd = 0;
    this.events = [];
    this.activeCategories = new Set(['ธุรกิจ', 'เศรษฐกิจ', 'การเงิน', 'การเมือง', 'คริปโต']);
    this.searchQuery = '';

    this.isDragging = false;
    this.dragMode = null; // 'window', 'left', 'right'
    this.dragStartX = 0;
    this.initialWindow = { start: 0, end: 0 };
    this.activePointerId = null;

    this.bindEvents();
  }

  setData(events, minTime, maxTime) {
    this.events = events;
    this.minTime = minTime;
    this.maxTime = maxTime;
    this.render();
  }

  setFilters(activeCategories, searchQuery) {
    this.activeCategories = new Set(activeCategories);
    this.searchQuery = (searchQuery || '').toLowerCase().trim();
    this.render();
  }

  setWindow(start, end) {
    this.viewStart = start;
    this.viewEnd = end;
    this.updateViewportStyle();
  }

  getFilteredEvents() {
    return this.events.filter(ev => {
      if (!this.activeCategories.has(ev.category)) return false;
      if (this.searchQuery) {
        const q = this.searchQuery;
        const matchTitle = ev.title && ev.title.toLowerCase().includes(q);
        const matchSummary = ev.summary && ev.summary.toLowerCase().includes(q);
        const matchDetails = ev.details && ev.details.toLowerCase().includes(q);
        const matchProvider = ev.provider && ev.provider.toLowerCase().includes(q);
        if (!matchTitle && !matchSummary && !matchDetails && !matchProvider) return false;
      }
      return true;
    });
  }

  bindEvents() {
    [this.viewport, this.handleLeft, this.handleRight].forEach(control => {
      control.addEventListener('keydown', event => {
        if (event.target === control) this.handleKeyboard(event, control);
      });
    });
    this.viewport.addEventListener('pointerdown', (e) => {
      if (e.isPrimary === false || (e.button !== undefined && e.button !== 0)) return;
      if (e.target === this.handleLeft) {
        this.dragMode = 'left';
      } else if (e.target === this.handleRight) {
        this.dragMode = 'right';
      } else {
        this.dragMode = 'window';
      }
      this.isDragging = true;
      this.activePointerId = e.pointerId;
      this.dragStartX = e.clientX;
      this.initialWindow = { start: this.viewStart, end: this.viewEnd };
      (this.dragMode === 'left' ? this.handleLeft : this.dragMode === 'right' ? this.handleRight : this.viewport).focus({ preventScroll: true });
      this.viewport.setPointerCapture(e.pointerId);
      e.preventDefault();
      e.stopPropagation();
    });

    this.container.addEventListener('click', (e) => {
      if (e.target === this.viewport || this.viewport.contains(e.target)) return;
      const rect = this.container.getBoundingClientRect();
      const clickRatio = (e.clientX - rect.left) / rect.width;
      const totalSpan = this.maxTime - this.minTime;
      if (rect.width <= 0 || totalSpan <= 0) return;
      const windowDuration = this.viewEnd - this.viewStart;

      const targetCenter = this.minTime + clickRatio * totalSpan;
      let newStart = targetCenter - windowDuration / 2;
      let newEnd = targetCenter + windowDuration / 2;

      if (newStart < this.minTime) {
        newStart = this.minTime;
        newEnd = this.minTime + windowDuration;
      }
      if (newEnd > this.maxTime) {
        newEnd = this.maxTime;
        newStart = this.maxTime - windowDuration;
      }

      this.viewStart = newStart;
      this.viewEnd = newEnd;
      this.updateViewportStyle();
      if (this.onBrushChange) this.onBrushChange(this.viewStart, this.viewEnd);
    });

    this.viewport.addEventListener('pointermove', (e) => {
      if (!this.isDragging || e.pointerId !== this.activePointerId) return;

      const rect = this.container.getBoundingClientRect();
      const totalSpan = this.maxTime - this.minTime;
      if (rect.width <= 0 || totalSpan <= 0) return;
      const minimumSpan = Math.min(2 * 3600 * 1000, totalSpan);
      const dx = e.clientX - this.dragStartX;
      const dTime = (dx / rect.width) * totalSpan;

      if (this.dragMode === 'window') {
        const span = this.initialWindow.end - this.initialWindow.start;
        let newStart = this.initialWindow.start + dTime;
        let newEnd = this.initialWindow.end + dTime;

        if (newStart < this.minTime) {
          newStart = this.minTime;
          newEnd = this.minTime + span;
        }
        if (newEnd > this.maxTime) {
          newEnd = this.maxTime;
          newStart = this.maxTime - span;
        }
        this.viewStart = newStart;
        this.viewEnd = newEnd;
      } else if (this.dragMode === 'left') {
        let newStart = Math.min(this.viewEnd - minimumSpan, Math.max(this.minTime, this.initialWindow.start + dTime));
        this.viewStart = newStart;
      } else if (this.dragMode === 'right') {
        let newEnd = Math.max(this.viewStart + minimumSpan, Math.min(this.maxTime, this.initialWindow.end + dTime));
        this.viewEnd = newEnd;
      }

      this.updateViewportStyle();
      if (this.onBrushChange) this.onBrushChange(this.viewStart, this.viewEnd);
      e.preventDefault();
    });

    const finishPointer = (e) => {
      if (e.pointerId !== this.activePointerId) return;
      this.isDragging = false;
      this.dragMode = null;
      this.activePointerId = null;
      if (this.viewport.hasPointerCapture(e.pointerId)) this.viewport.releasePointerCapture(e.pointerId);
      this.announceWindow();
    };
    this.viewport.addEventListener('pointerup', finishPointer);
    this.viewport.addEventListener('pointercancel', finishPointer);
    this.viewport.addEventListener('lostpointercapture', finishPointer);

    window.addEventListener('resize', () => {
      this.render();
      this.updateViewportStyle();
    });
  }

  announceWindow() {
    const status = document.getElementById('navigationStatus');
    if (status) status.textContent = this.windowDescription();
  }

  windowDescription() {
    const format = value => new Date(value).toLocaleString('th-TH', {timeZone: 'Asia/Bangkok'});
    return `กรอบเวลา ${format(this.viewStart)} ถึง ${format(this.viewEnd)}`;
  }

  handleKeyboard(event, control) {
    if (event.altKey || event.ctrlKey || event.metaKey || this.maxTime <= this.minTime) return;
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const minimumSpan = Math.min(2 * 3600 * 1000, this.maxTime - this.minTime);
    const span = this.viewEnd - this.viewStart;
    const step = Math.max(minimumSpan / 10, span / 10) * (event.shiftKey ? 5 : 1);
    const delta = event.key === 'ArrowLeft' ? -step : step;
    if (control === this.handleLeft) {
      const target = event.key === 'Home' ? this.minTime : event.key === 'End' ? this.viewEnd - minimumSpan : this.viewStart + delta;
      this.viewStart = Math.max(this.minTime, Math.min(this.viewEnd - minimumSpan, target));
    } else if (control === this.handleRight) {
      const target = event.key === 'Home' ? this.viewStart + minimumSpan : event.key === 'End' ? this.maxTime : this.viewEnd + delta;
      this.viewEnd = Math.min(this.maxTime, Math.max(this.viewStart + minimumSpan, target));
    } else {
      const target = event.key === 'Home' ? this.minTime : event.key === 'End' ? this.maxTime - span : this.viewStart + delta;
      this.viewStart = Math.max(this.minTime, Math.min(this.maxTime - span, target));
      this.viewEnd = this.viewStart + span;
    }
    this.updateViewportStyle();
    if (this.onBrushChange) this.onBrushChange(this.viewStart, this.viewEnd);
    this.announceWindow();
  }

  updateViewportStyle() {
    const containerW = this.container.clientWidth;
    const totalSpan = this.maxTime - this.minTime;
    if (totalSpan <= 0) return;

    const leftFrac = Math.max(0, Math.min(1, (this.viewStart - this.minTime) / totalSpan));
    const rightFrac = Math.max(0, Math.min(1, (this.viewEnd - this.minTime) / totalSpan));

    const touchTargets = window.matchMedia && window.matchMedia('(pointer: coarse), (max-width: 767px)').matches;
    const minimumWidth = Math.min(containerW, touchTargets ? 132 : 18);
    const leftPx = Math.min(leftFrac * containerW, Math.max(0, containerW - minimumWidth));
    const widthPx = Math.min(containerW - leftPx, Math.max(minimumWidth, (rightFrac - leftFrac) * containerW));

    this.viewport.style.left = `${leftPx}px`;
    this.viewport.style.width = `${widthPx}px`;
    this.viewport.setAttribute('aria-label', this.windowDescription());
    const minimumSpan = Math.min(2 * 3600 * 1000, totalSpan);
    [[this.handleLeft, this.viewStart, this.minTime, this.viewEnd - minimumSpan],
      [this.handleRight, this.viewEnd, this.viewStart + minimumSpan, this.maxTime]].forEach(([control, value, minimum, maximum]) => {
      control.setAttribute('aria-valuemin', minimum);
      control.setAttribute('aria-valuemax', maximum);
      control.setAttribute('aria-valuenow', value);
      control.setAttribute('aria-valuetext', new Date(value).toLocaleString('th-TH', {timeZone: 'Asia/Bangkok'}));
    });
  }

  render() {
    // Enforce 2x DPR for ultra-sharp minimap density bars
    const dpr = Math.max(window.devicePixelRatio || 1, 2);
    const w = this.canvas.clientWidth;
    const h = this.canvas.clientHeight;

    if (this.canvas.width !== Math.round(w * dpr) || this.canvas.height !== Math.round(h * dpr)) {
      this.canvas.width = Math.round(w * dpr);
      this.canvas.height = Math.round(h * dpr);
    }

    const ctx = this.ctx;
    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    const numBuckets = 44;
    const totalSpan = this.maxTime - this.minTime;
    if (totalSpan <= 0) {
      ctx.restore();
      return;
    }

    const bucketDuration = totalSpan / numBuckets;
    const counts = new Array(numBuckets).fill(0);

    const activeEvents = this.getFilteredEvents();
    activeEvents.forEach(ev => {
      const b = Math.min(numBuckets - 1, Math.max(0, Math.floor((ev.timestamp - this.minTime) / bucketDuration)));
      counts[b]++;
    });

    const maxCount = Math.max(...counts, 1);
    const barW = w / numBuckets;

    counts.forEach((c, i) => {
      const barH = (c / maxCount) * (h - 12);
      const x = i * barW;
      const y = h - barH;

      ctx.fillStyle = this.searchQuery ? '#eab308' : '#334155';
      ctx.fillRect(x + 1, y, barW - 2, barH);
    });

    ctx.restore();
  }
}
