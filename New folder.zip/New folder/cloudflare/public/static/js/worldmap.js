/**
 * WRITE TIME — World Map & Geopolitical Scenario Radar Engine
 * Features:
 * - Interactive Dark Leaflet World Map (CartoDB Dark Matter)
 * - Built-in High-Tech Interactive Dark Vector World Map Fallback
 * - Geopolitical Conflict & War Hotspots with dynamic glowing cluster pins
 * - Strategic Supply Chain & Resource Chokepoints (Lithium, Hormuz, Red Sea, Taiwan)
 * - Shockwave & Trade Route Transmission Arcs (golden geodesic dashed polylines)
 * - Scenario Simulator: "Event A -> Economic Transmission Channel -> Action Playbook"
 * - Synchronized Keyword Links & Geopolitical Intelligence Feed
 */
class WorldMapEngine {
  constructor(mapContainerId, options = {}) {
    this.mapContainerId = mapContainerId;
    this.options = options;
    this.map = null;
    this.markersLayer = null;
    this.connectionsLayer = null;
    this.allEvents = [];
    this.filteredEvents = [];
    this.isInitialized = false;
    this.activeCategory = 'all';
    this.scenarioMode = 'escalation'; // 'escalation' (Scenario A) or 'deescalation' (Scenario B)

    // 21-Day Rolling Daily Intelligence State
    this.availableDates = [];
    this.selectedAnchorDate = null;
    this.events21d = [];
    this.rollingWindowDays = 21;
    this.scenariosFeed = [];

    // Pre-curated Geopolitical & Strategic Hotspots
    this.hotspots = [
      {
        id: 'hormuz',
        name: 'ช่องแคบฮอร์มุซ & ตะวันออกกลาง (Strait of Hormuz)',
        region: 'Middle East',
        coords: [26.56, 56.25],
        type: 'conflict',
        pulseClass: 'pulse-red',
        badgeColor: '#ef4444',
        count: 263,
        tensionLevel: 'วิกฤติตึงเครียดระดับสูงสุด (Critical Tension)',
        summary: 'จุดยุทธศาสตร์ลำเลียงน้ำมันดิบกว่า 20% ของโลก เผชิญความเสี่ยงสงครามขยายวงและการสกัดกั้นเรือบรรทุกน้ำมัน',
        keywords: ['ฮอร์มุซ', 'อิหร่าน', 'อิสราเอล', 'ตะวันออกกลาง', 'น้ำมัน', 'opec', 'พลังงาน'],
        scenario: {
          eventA: 'กองกำลังในภูมิภาคประกาศปิดกั้นช่องแคบฮอร์มุซ หรือเปิดฉากโจมตีเรือบรรทุกน้ำมันและโรงกลั่นพลังงานขนาดใหญ่',
          economicImpact: {
            energy: 'ราคาน้ำมันดิบ Brent และ WTI พุ่งทะลุ $105 - $120/บาร์เรล ต้นทุนค่าระวางเรือพาณิชย์และเบี้ยประกันความเสี่ยงสงครามพุ่ง 250%',
            inflation: 'เงินเฟ้อทั่วไป (Headline Inflation) โลกดีดกลับฉับพลัน ธนาคารกลางสหรัฐ (Fed) และ ECB จำเป็นต้องชะลอการปรับลดอัตราดอกเบี้ย',
            equities: 'ภาวะ Risk-off ฉับพลัน ตลาดหุ้นโลกปรับฐาน -5% ถึง -10% กลุ่มสายการบิน ขนส่ง ยานยนต์ และค้าปลีกเผชิญแรงเทขายรุนแรง',
            safeHaven: 'เงินทุนแห่เข้าพักในสินทรัพย์ปลอดภัย ดัชนีดอลลาร์ (DXY) แข็งค่า ทองคำ (Gold) พุ่งสร้างสถิติ All-Time High ใหม่'
          },
          actionPlaybook: {
            portfolio: 'ขยับสัดส่วนถือเงินสด (Cash/USD) และพันธบัตรรัฐบาลระยะสั้นขึ้นเป็น 25-30% เพื่อลดความผันผวนของพอร์ตหลัก',
            tacticalHedge: 'เปิดสถานะ Long สัญญาน้ำมันดิบ / กองทุนพลังงานต้นน้ำ (Energy Equities) ควบคู่กับถือทองคำแท่ง/Gold ETF เป็นเกราะกำบัง',
            supplyChain: 'เร่งสำรองสต็อกเชื้อเพลิง วางแผนสัญญาจัดซื้อล่วงหน้า และเปลี่ยนเส้นทางขนส่งทางบกหรือเลี่ยงเข้าท่าเรือสำรอง',
            crypto: 'ระวังแรงเทขายช่วงแรกจากภาวะขาดสภาพคล่อง (Liquidity Crunch) แล้วรอตั้งรับสะสม Bitcoin ในช่วงราคาสร้างฐาน'
          },
          eventB: 'สหรัฐฯ และพันธมิตรจัดตั้งกองเรือคุ้มกันสำเร็จ และเปิดช่องทางการทูตเพื่อเจรจาหยุดยิง',
          economicImpactB: {
            energy: 'ราคาน้ำมันดิบทิ้งตัวลงสู่ $72 - $76/บาร์เรล ต้นทุนค่าขนส่งปรับตัวลงสู่ระดับปกติ',
            inflation: 'แรงกดดันด้านเงินเฟ้อคลายตัว ธนาคารกลางกลับมาดำเนินนโยบายผ่อนคลายการเงินตามแผน',
            equities: 'ตลาดหุ้นเกิด Relief Rally หุ้นกลุ่มเติบโตและเทคโนโลยีนำตลาดฟื้นตัว',
            safeHaven: 'ทองคำและดอลลาร์ปรับฐานลง เงินทุนไหลกลับเข้าสินทรัพย์เสี่ยง'
          },
          actionPlaybookB: {
            portfolio: 'ทยอยลดสถานะเงินสด เพิ่มน้ำหนักการลงทุนในกลุ่มหุ้นเติบโต (Tech, Industrials, Growth)',
            tacticalHedge: 'ปิดสถานะทำกำไรในสัญญา Long น้ำมัน และสลับเงินทุนเข้าสู่กลุ่มหุ้นวัฏจักร'
          }
        }
      },
      {
        id: 'lithium',
        name: 'สามเหลี่ยมลิเธียม อาร์เจนตินา (Lithium Basin Argentina)',
        region: 'Latin America',
        coords: [-24.18, -65.30],
        type: 'strategic',
        pulseClass: 'pulse-gold',
        badgeColor: '#e5a93c',
        count: 10,
        tensionLevel: 'ยุทธศาสตร์แร่หายาก & พลังงานสะอาด (Strategic Resource)',
        summary: 'Rio Tinto อนุมัติงบ $1.18 พันล้านเหรียญ ขยายโครงการ Rincon Lithium ในอาร์เจนตินาเพื่อป้อนซัพพลายเชนแบตเตอรี่ EV โลก',
        keywords: ['ลิเธียม', 'lithium', 'อาร์เจนตินา', 'rio tinto', 'เหมือง', 'แบตเตอรี่', 'ev'],
        scenario: {
          eventA: 'การขยายตัวของการลงทุน $1.18 พันล้านเหรียญในอาร์เจนตินา ท่ามกลางการแข่งขันชิงซัพพลายเชนแร่พลังงานสะอาดระหว่างสหรัฐฯ และจีน',
          economicImpact: {
            energy: 'เพิ่มเสถียรภาพอุปทานลิเธียมคาร์บอเนตสำหรับอุตสาหกรรมยานยนต์ไฟฟ้าและระบบกักเก็บพลังงาน (BESS) ทั่วโลก',
            inflation: 'ช่วยกดดันต้นทุนการผลิตแบตเตอรี่ EV ในระยะกลาง-ยาวให้ลดลง ส่งเสริมเป้าหมายการเปลี่ยนผ่านพลังงานสะอาด',
            equities: 'หุ้นกลุ่มเหมืองแร่ยักษ์ใหญ่ (Rio Tinto, Albemarle, SQM) ได้รับอานิสงส์เชิงบวกและดึงดูดเม็ดเงินลงทุนสถาบัน',
            safeHaven: 'ค่าเงินและดุลบัญชีเดินสะพัดของอาร์เจนตินาได้รับแรงหนุนจากเม็ดเงินลงทุนโดยตรงจากต่างประเทศ (FDI)'
          },
          actionPlaybook: {
            portfolio: 'กระจายการลงทุนเข้าสู่ห่วงโซ่อุตสาหกรรมแร่พลังงานและวัสดุสำหรับเทคโนโลยีอนาคต',
            tacticalHedge: 'ติดตามความเสี่ยงด้านนโยบายสัมปทานแร่และภาษีส่งออกของรัฐบาลท้องถิ่น',
            supplyChain: 'ผู้ผลิตแบตเตอรี่ควรเร่งทำสัญญาซื้อขายระยะยาว (Offtake Agreement) เพื่อการันตีวัตถุดิบ',
            crypto: 'เชื่อมโยงสู่โทเคนกลุ่ม Real-World Asset (RWA) ที่อิงกับทรัพยากรธรรมชาติ'
          }
        }
      },
      {
        id: 'ukraine',
        name: 'ยูเครน & ยุโรปตะวันออก (Eastern Europe Frontline)',
        region: 'Eastern Europe',
        coords: [50.45, 30.52],
        type: 'conflict',
        pulseClass: 'pulse-red',
        badgeColor: '#ef4444',
        count: 58,
        tensionLevel: 'สงครามยืดเยื้อและมาตรการคว่ำบาตร (Active War Zone)',
        summary: 'การปะทะตามแนวรบยูเครนและความเสี่ยงต่อท่อส่งก๊าซธรรมชาติ โรงไฟฟ้านิวเคลียร์ และเส้นทางส่งออกธัญพืชทะเลดำ',
        keywords: ['ยูเครน', 'รัสเซีย', 'ยุโรป', 'ก๊าซ', 'นาโต', 'nato', 'ธัญพืช'],
        scenario: {
          eventA: 'การยกระดับการโจมตีโครงสร้างพื้นฐานพลังงานในยุโรปตะวันออก และการเพิ่มมาตรการคว่ำบาตรต่อชาติพันธมิตร',
          economicImpact: {
            energy: 'ราคาก๊าซธรรมชาติในยุโรป (Dutch TTF) ดีดตัวขึ้น กระทบต้นทุนค่าไฟฟ้าและภาคอุตสาหกรรมหนักในเยอรมนี/ฝรั่งเศส',
            inflation: 'Core Inflation ของยูโรโซนทรงตัวในระดับสูง กดดันให้ ECB ต้องคงอัตราดอกเบี้ยเป็นเวลานานขึ้น',
            equities: 'หุ้นภาคการผลิตและเคมีภัณฑ์ในยุโรปเผชิญแรงกดดันด้านอัตรากำไร ขณะที่หุ้นกลุ่มอุตสาหกรรมป้องกันประเทศ (Defense) พุ่งขึ้น',
            safeHaven: 'เงินยูโร (EUR) อ่อนค่าเมื่อเทียบกับดอลลาร์สหรัฐ'
          },
          actionPlaybook: {
            portfolio: 'ลดน้ำหนักหุ้นยุโรปกลุ่ม Cyclical และเพิ่มการลงทุนในกลุ่ม Defense & European Utilities',
            tacticalHedge: 'ถือสัญญา Long European Natural Gas หรือสเปรดราคาก๊าซ',
            supplyChain: 'กระจายแหล่งจัดซื้อก๊าซธรรมชาติเหลว (LNG) จากสหรัฐฯ และกาตาร์'
          }
        }
      },
      {
        id: 'taiwan',
        name: 'ช่องแคบไต้หวัน & ทะเลจีนใต้ (Taiwan Strait & East Asia)',
        region: 'East Asia',
        coords: [24.0, 119.5],
        type: 'conflict',
        pulseClass: 'pulse-red',
        badgeColor: '#ef4444',
        count: 37,
        tensionLevel: 'จุดเปราะบางเซมิคอนดักเตอร์โลก (Semiconductor Chokepoint)',
        summary: 'จุดเสี่ยงยุทธศาสตร์สำคัญที่สุดของห่วงโซ่อุปทานชิปประมวลผลขั้นสูง (TSMC) ซึ่งควบคุมกำลังผลิตชิป AI กว่า 90% ของโลก',
        keywords: ['ไต้หวัน', 'จีน', 'สหรัฐ', 'ชิป', 'semiconductor', 'tsmc', 'ไบเดน', 'ทรัมป์'],
        scenario: {
          eventA: 'การปิดล้อมทางทะเลหรือการซ้อมรบทางอากาศรอบเกาะไต้หวัน กระทบต่อการขนส่งชิปเซมิคอนดักเตอร์ขั้นสูง',
          economicImpact: {
            energy: 'เส้นทางเดินเรือพาณิชย์ในเอเชียตะวันออกต้องเปลี่ยนทิศทาง ต้นทุนโลจิสติกส์เอเชียพุ่งสูง',
            inflation: 'วิกฤตขาดแคลนชิปทั่วโลกส่งผลให้ราคาสินค้าอิเล็กทรอนิกส์ ยานยนต์ และคอมพิวเตอร์พุ่งสูงทันที',
            equities: 'หุ้นกลุ่มเซมิคอนดักเตอร์และบิ๊กเทค (Nvidia, Apple, TSMC, AMD) ดิ่งลงฉับพลัน ฉุดตลาดหุ้นทั่วโลก',
            safeHaven: 'ทองคำและพันธบัตรรัฐบาลสหรัฐฯ พุ่งสูง ขณะที่สกุลเงินเอเชีย (TWD, KRW, JPY) เผชิญแรงกดดันอ่อนค่า'
          },
          actionPlaybook: {
            portfolio: 'ตั้งจุดตัดขาดทุน (Stop-Loss) ในหุ้นเทคโนโลยีที่มีความเปราะบางต่อซัพพลายเชนชิป',
            tacticalHedge: 'กระจายการลงทุนสู่ผู้ผลิตชิปนอกไต้หวัน (เช่น Intel, Samsung) และถือทองคำเป็นสินทรัพย์คุ้มกัน',
            supplyChain: 'บริษัทเทคโนโลยีต้องเร่งกระจายกำลังการผลิตและการสำรองสินค้าสำเร็จรูป'
          }
        }
      },
      {
        id: 'redsea',
        name: 'ทะเลแดง & ช่องแคบบับเอลมันเดบ (Red Sea & Suez Corridor)',
        region: 'Red Sea',
        coords: [13.5, 43.5],
        type: 'conflict',
        pulseClass: 'pulse-red',
        badgeColor: '#ef4444',
        count: 15,
        tensionLevel: 'เส้นทางขนส่งทางทะเลหยุดชะงัก (Maritime Disruption)',
        summary: 'การโจมตีเรือพาณิชย์ทำให้บริษัทเดินเรือยักษ์ใหญ่ (Maersk, MSC, Hapag-Lloyd) ต้องเปลี่ยนเส้นทางอ้อมแหลมกู๊ดโฮป',
        keywords: ['ทะเลแดง', 'ฮูตี', 'เยเมน', 'เรือ', 'ขนส่ง', 'คลองสุเอซ', 'โลจิสติกส์'],
        scenario: {
          eventA: 'การโจมตีเรือพาณิชย์ระลอกใหม่ในทะเลแดง บังคับให้กองเรือขนส่งสินค้าทั่วโลกต้องเดินทางอ้อมแหลมกู๊ดโฮปต่อเนื่อง',
          economicImpact: {
            energy: 'ระยะเวลาขนส่งสินค้าระหว่างเอเชียและยุโรปเพิ่มขึ้น 10-14 วัน เพิ่มการบริโภคน้ำมันเชื้อเพลิงเรือเดินสมุทร',
            inflation: 'ค่าระวางตู้คอนเทนเนอร์ (Container Freight Rate) พุ่งขึ้น 150-200% ดันราคาสินค้านำเข้าในยุโรป',
            equities: 'หุ้นกลุ่มเดินเรือตู้คอนเทนเนอร์มีรายได้ค่าระวางพุ่งขึ้น ขณะที่กลุ่มค้าปลีกและยานยนต์เผชิญปัญหาสินค้าล่าช้า',
            safeHaven: 'เงินดอลลาร์สหรัฐแข็งค่าในฐานะสกุลเงินหลักที่ใช้ชำระค่าระวางและพลังงาน'
          },
          actionPlaybook: {
            portfolio: 'เลือกลงทุนในหุ้นกลุ่มเดินเรือและโลจิสติกส์ที่ได้ประโยชน์จากค่าระวางสูง',
            tacticalHedge: 'ป้องกันความเสี่ยงด้านเวลาด้วยการเพิ่มสินค้าคงคลังสำรอง (Safety Stock) 1-2 เดือน',
            supplyChain: 'ทำสัญญาจองระวางเรือล่วงหน้าและพิจารณาทางเลือกการขนส่งผสมทางบก/อากาศ'
          }
        }
      },
      {
        id: 'fed',
        name: 'ธนาคารกลางสหรัฐฯ วอชิงตัน ดี.ซี. (Federal Reserve & US Policy)',
        region: 'North America',
        coords: [38.90, -77.03],
        type: 'financial',
        pulseClass: 'pulse-cyan',
        badgeColor: '#06b6d4',
        count: 130,
        tensionLevel: 'ศูนย์กลางนโยบายการเงินโลก (Global Monetary Core)',
        summary: 'การตัดสินใจอัตราดอกเบี้ยและมาตรการควบคุมเงินเฟ้อของ Fed กำหนดทิศทางสภาพคล่องและกระแสเงินทุนทั่วโลก',
        keywords: ['fed', 'เฟด', 'ดอกเบี้ย', 'เงินเฟ้อ', 'สหรัฐ', 'ดอลลาร์', 'พาวเวลล์'],
        scenario: {
          eventA: 'ธนาคารกลางสหรัฐฯ ส่งสัญญาณคงอัตราดอกเบี้ยสูงยาวนานขึ้น (Higher-for-Longer) จากความเสี่ยงเงินเฟ้อสงคราม',
          economicImpact: {
            energy: 'ราคาสินค้าโภคภัณฑ์ในรูปดอลลาร์เผชิญแรงกดดันจากต้นทุนการกู้ยืมที่สูงขึ้น',
            inflation: 'อัตราผลตอบแทนพันธบัตรรัฐบาลสหรัฐฯ 10 ปี (US 10Y Yield) ดีดตัวขึ้นสู่ 4.5%+',
            equities: 'หุ้นกลุ่ม Growth / Tech ที่ซื้อขายบน Valuation สูงเผชิญแรงกดดันปรับฐาน',
            safeHaven: 'ดัชนีดอลลาร์ (DXY) ปรับตัวแข็งแกร่ง กระทบค่าเงินในตลาดเกิดใหม่ (EM Currencies)'
          },
          actionPlaybook: {
            portfolio: 'ล็อกผลตอบแทนด้วยตราสารหนี้คุณภาพสูงระยะสั้น (Short-Duration T-Bills) ที่ให้ยีลด์ 4-5%',
            tacticalHedge: 'ลดสัดส่วนหนี้สินและงดเว้นการใช้ Margin ในการลงทุน',
            crypto: 'จับตาระดับ Liquidity ของเงินดอลลาร์ รอจังหวะสะสมเมื่อแนวโน้มดอกเบี้ยเริ่มถึงจุดสูงสุดชัดเจน'
          }
        }
      },
      {
        id: 'ecb',
        name: 'ธนาคารกลางยุโรป แฟรงก์เฟิร์ต (European Central Bank)',
        region: 'Europe',
        coords: [50.11, 8.68],
        type: 'financial',
        pulseClass: 'pulse-cyan',
        badgeColor: '#06b6d4',
        count: 44,
        tensionLevel: 'นโยบายเศรษฐกิจยุโรป (European Macro Policy)',
        summary: 'การรักษาสมดุลระหว่างการคุมเงินเฟ้อจากวิกฤตพลังงานกับการป้องกันภาวะเศรษฐกิจถดถอยในเยอรมนีและยูโรโซน',
        keywords: ['ecb', 'ยุโรป', 'เยอรมนี', 'ยูโร', 'ลาการ์ด'],
        scenario: {
          eventA: 'ภาวะเศรษฐกิจชะลอตัวในยูโรโซนบีบให้ ECB ต้องปรับลดดอกเบี้ยสวนทางกับแรงกดดันเงินเฟ้อด้านพลังงาน',
          economicImpact: {
            energy: 'ค่าเงินยูโรอ่อนค่าลงซ้ำเติมต้นทุนการนำเข้าน้ำมันและก๊าซธรรมชาติ',
            inflation: 'ภาวะ Stagflation อ่อนๆ ในกลุ่มประเทศอุตสาหกรรมยุโรป',
            equities: 'ตลาดหุ้นยุโรปผันผวน กลุ่มธนาคารเผชิญส่วนต่างดอกเบี้ยที่ลดลง',
            safeHaven: 'เงินทุนโยกย้ายข้ามฝั่งไปยังตลาดทุนสหรัฐฯ'
          },
          actionPlaybook: {
            portfolio: 'กระจายความเสี่ยงออกนอกตลาดยุโรป มุ่งเน้นสินทรัพย์ที่มีรายได้สกุลดอลลาร์เป็นหลัก'
          }
        }
      },
      {
        id: 'malacca',
        name: 'ช่องแคบมะละกา (Strait of Malacca, Southeast Asia)',
        region: 'Southeast Asia',
        coords: [2.50, 101.50],
        type: 'strategic',
        pulseClass: 'pulse-gold',
        badgeColor: '#e5a93c',
        count: 12,
        tensionLevel: 'เส้นทางเดินเรือเอเชีย (Asian Maritime Artery)',
        summary: 'เส้นทางขนส่งสินค้าและน้ำมันดิบกว่า 25% ของโลก เชื่อมโยงมหาสมุทรอินเดียสู่จีน ญี่ปุ่น เกาหลีใต้ และเอเชียตะวันออกเฉียงใต้',
        keywords: ['มะละกา', 'สิงคโปร์', 'มาเลเซีย', 'ขนส่ง', 'อาเซียน'],
        scenario: {
          eventA: 'การซ้อมรบทางทะเลหรืออุบัติเหตุการชนในร่องน้ำแคบกระทบการสัญจรทางเรือของเอเชียตะวันออก',
          economicImpact: {
            energy: 'กระทบการนำเข้าน้ำมันดิบของจีนและญี่ปุ่น โรงกลั่นในเอเชียต้องดึงสต็อกสำรอง',
            inflation: 'ค่าขนส่งและเบี้ยประกันเรือในเอเชียตะวันออกเฉียงใต้ปรับตัวขึ้น',
            equities: 'หุ้นท่าเรือและโลจิสติกส์ในภูมิภาคเผชิญความล่าช้า',
            safeHaven: 'เงินดอลลาร์สิงคโปร์ (SGD) และเยนญี่ปุ่นผันผวน'
          },
          actionPlaybook: {
            portfolio: 'พิจารณาโครงสร้างพื้นฐานพลังงานทดแทนและท่าเรือสำรองในภูมิภาค'
          }
        }
      }
    ];

    // Connection Arcs (Trade routes & economic shockwave transmission lines)
    this.connectionArcs = [
      { from: 'lithium', to: 'fed', label: 'Argentina Lithium -> US EV Tech Chain' },
      { from: 'lithium', to: 'taiwan', label: 'Lithium Raw -> Asian Battery Fabricators' },
      { from: 'hormuz', to: 'ecb', label: 'Hormuz Oil -> European Energy Security' },
      { from: 'hormuz', to: 'malacca', label: 'Middle East Crude -> Asian Refineries' },
      { from: 'redsea', to: 'ecb', label: 'Red Sea / Suez -> Europe Consumer Supply' },
      { from: 'taiwan', to: 'fed', label: 'TSMC Taiwan -> US AI Datacenters' },
      { from: 'ukraine', to: 'ecb', label: 'Eastern Europe Gas/Grain -> European Food & Industry' }
    ];

    // Default active hotspot
    this.selectedHotspot = this.hotspots[0];

    // Populate scenario panel and category chips immediately so HTML is never blank!
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.setupCategoryFilterChips();
        this.updateScenarioPanel();
        this.updateRelatedSignals();
      });
    } else {
      setTimeout(() => {
        this.setupCategoryFilterChips();
        this.updateScenarioPanel();
        this.updateRelatedSignals();
      }, 0);
    }
  }

  init() {
    this.selectedHotspot = this.hotspots[0];

    // Setup Category Chips & Scenario immediately
    this.setupCategoryFilterChips();
    this.updateScenarioPanel();
    this.updateRelatedSignals();

    const container = document.getElementById(this.mapContainerId);
    if (!container) return;

    // Check Leaflet availability
    if (typeof L === 'undefined') {
      console.warn('Leaflet library not loaded, using SVG dark map fallback.');
      this.initFallbackMap();
      this.isInitialized = true;
      return;
    }

    if (this.map) {
      this.invalidateSize();
      return;
    }

    try {
      // Initialize Leaflet Map
      this.map = L.map(this.mapContainerId, {
        center: [24, 25],
        zoom: 2,
        minZoom: 2,
        maxZoom: 10,
        zoomControl: true,
        attributionControl: true
      });

      // High-Contrast Professional Dark Canvas (100% Free, No Watermark, No API Key Required)
      this.baseTileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 16,
        attribution: 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ'
      }).addTo(this.map);

      // Subtle Geographic Borders & Labels Overlay
      this.referenceTileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 16,
        opacity: 0.75,
        attribution: ''
      }).addTo(this.map);

      this.markersLayer = L.layerGroup().addTo(this.map);
      this.connectionsLayer = L.layerGroup().addTo(this.map);

      this.renderHotspots();
      this.renderConnectionArcs();
      this.isInitialized = true;

      // Safe initial setView without flyTo to prevent animation crash on fresh render
      this.selectHotspot(this.hotspots[0], false);

      // Trigger map resize invalidation
      setTimeout(() => {
        if (this.map) {
          this.map.invalidateSize();
          this.map.setView([24, 25], 2);
        }
      }, 150);

    } catch (err) {
      console.warn('Leaflet map creation failed, using fallback:', err);
      this.initFallbackMap();
      this.isInitialized = true;
    }
  }

  initFallbackMap() {
    const container = document.getElementById(this.mapContainerId);
    if (!container) return;

    // High-Tech Interactive Dark Vector World Map Fallback
    container.innerHTML = `
      <div class="relative w-full h-full bg-[#0a0e17] overflow-hidden flex items-center justify-center select-none" id="vectorWorldMapFallback">
        <!-- World Map SVG Silhouette Grid Background -->
        <svg class="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="geoGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" stroke-width="0.7"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#geoGrid)" />
        </svg>

        <!-- World Continents Approximate Outlines (SVG) -->
        <svg viewBox="0 0 1000 500" class="absolute inset-0 w-full h-full pointer-events-none opacity-30">
          <!-- North America -->
          <path d="M 150 100 Q 220 80 280 120 Q 290 180 230 220 Q 180 240 140 180 Z" fill="#1e293b" stroke="#334155" stroke-width="1.5"/>
          <!-- South America -->
          <path d="M 280 250 Q 340 270 330 360 Q 290 440 260 400 Q 250 310 280 250 Z" fill="#1e293b" stroke="#334155" stroke-width="1.5"/>
          <!-- Europe -->
          <path d="M 480 90 Q 560 80 580 140 Q 520 180 470 150 Z" fill="#1e293b" stroke="#334155" stroke-width="1.5"/>
          <!-- Africa -->
          <path d="M 480 190 Q 570 190 560 300 Q 510 390 480 340 Q 450 250 480 190 Z" fill="#1e293b" stroke="#334155" stroke-width="1.5"/>
          <!-- Asia -->
          <path d="M 590 80 Q 820 70 850 180 Q 750 280 620 220 Q 580 160 590 80 Z" fill="#1e293b" stroke="#334155" stroke-width="1.5"/>
          <!-- Australia -->
          <path d="M 760 320 Q 860 320 850 390 Q 780 420 750 360 Z" fill="#1e293b" stroke="#334155" stroke-width="1.5"/>
        </svg>

        <!-- Connection Arcs (SVG) -->
        <svg viewBox="0 0 1000 500" class="absolute inset-0 w-full h-full pointer-events-none" id="fallbackConnectionLines">
          <!-- Hormuz to Europe -->
          <path d="M 605 215 Q 550 150 515 130" stroke="#e5a93c" stroke-width="1.5" stroke-dasharray="5,5" fill="none" opacity="0.7"/>
          <!-- Hormuz to East Asia -->
          <path d="M 605 215 Q 670 240 730 250" stroke="#e5a93c" stroke-width="1.5" stroke-dasharray="5,5" fill="none" opacity="0.7"/>
          <!-- Argentina Lithium to US -->
          <path d="M 285 350 Q 230 250 240 145" stroke="#e5a93c" stroke-width="1.5" stroke-dasharray="5,5" fill="none" opacity="0.7"/>
          <!-- Red Sea to Europe -->
          <path d="M 570 250 Q 540 180 515 130" stroke="#e5a93c" stroke-width="1.5" stroke-dasharray="5,5" fill="none" opacity="0.7"/>
          <!-- Taiwan to US -->
          <path d="M 770 190 Q 500 50 240 145" stroke="#e5a93c" stroke-width="1.5" stroke-dasharray="5,5" fill="none" opacity="0.5"/>
        </svg>

        <!-- Hotspot Pin Overlay Layer -->
        <div class="absolute inset-0 w-full h-full" id="fallbackPinsContainer">
          <!-- Hormuz -->
          <button onclick="worldMapEngine.focusHotspot('hormuz')" class="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer" style="left: 60.5%; top: 43%;">
            <div class="geo-marker-pulse pulse-red w-8 h-8 flex items-center justify-center">
              <div data-hotspot-count="hormuz" class="w-6 h-6 rounded-full bg-[#101520] border-2 border-rose-500 text-white font-mono text-[10px] font-bold flex items-center justify-center shadow-lg group-hover:scale-125 transition">${this.hotspots.find(spot => spot.id === 'hormuz').count}</div>
            </div>
            <span class="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-black/90 text-rose-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-rose-500/40 opacity-0 group-hover:opacity-100 transition">ฮอร์มุซ / ตะวันออกกลาง</span>
          </button>

          <!-- Lithium Argentina -->
          <button onclick="worldMapEngine.focusHotspot('lithium')" class="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer" style="left: 28.5%; top: 70%;">
            <div class="geo-marker-pulse pulse-gold w-8 h-8 flex items-center justify-center">
              <div data-hotspot-count="lithium" class="w-6 h-6 rounded-full bg-[#101520] border-2 border-[#e5a93c] text-white font-mono text-[10px] font-bold flex items-center justify-center shadow-lg group-hover:scale-125 transition">${this.hotspots.find(spot => spot.id === 'lithium').count}</div>
            </div>
            <span class="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-black/90 text-[#e5a93c] text-[10px] font-bold px-1.5 py-0.5 rounded border border-[#e5a93c]/40 opacity-0 group-hover:opacity-100 transition">ลิเธียม อาร์เจนตินา ($1.18B)</span>
          </button>

          <!-- Ukraine / Eastern Europe -->
          <button onclick="worldMapEngine.focusHotspot('ukraine')" class="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer" style="left: 54%; top: 25%;">
            <div class="geo-marker-pulse pulse-red w-8 h-8 flex items-center justify-center">
              <div data-hotspot-count="ukraine" class="w-6 h-6 rounded-full bg-[#101520] border-2 border-rose-500 text-white font-mono text-[10px] font-bold flex items-center justify-center shadow-lg group-hover:scale-125 transition">${this.hotspots.find(spot => spot.id === 'ukraine').count}</div>
            </div>
            <span class="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-black/90 text-rose-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-rose-500/40 opacity-0 group-hover:opacity-100 transition">ยูเครน / ยุโรปตะวันออก</span>
          </button>

          <!-- Taiwan Strait -->
          <button onclick="worldMapEngine.focusHotspot('taiwan')" class="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer" style="left: 77%; top: 38%;">
            <div class="geo-marker-pulse pulse-red w-8 h-8 flex items-center justify-center">
              <div data-hotspot-count="taiwan" class="w-6 h-6 rounded-full bg-[#101520] border-2 border-rose-500 text-white font-mono text-[10px] font-bold flex items-center justify-center shadow-lg group-hover:scale-125 transition">${this.hotspots.find(spot => spot.id === 'taiwan').count}</div>
            </div>
            <span class="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-black/90 text-rose-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-rose-500/40 opacity-0 group-hover:opacity-100 transition">ช่องแคบไต้หวัน / TSMC</span>
          </button>

          <!-- Red Sea -->
          <button onclick="worldMapEngine.focusHotspot('redsea')" class="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer" style="left: 57%; top: 50%;">
            <div class="geo-marker-pulse pulse-red w-8 h-8 flex items-center justify-center">
              <div data-hotspot-count="redsea" class="w-6 h-6 rounded-full bg-[#101520] border-2 border-rose-500 text-white font-mono text-[10px] font-bold flex items-center justify-center shadow-lg group-hover:scale-125 transition">${this.hotspots.find(spot => spot.id === 'redsea').count}</div>
            </div>
            <span class="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-black/90 text-rose-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-rose-500/40 opacity-0 group-hover:opacity-100 transition">ทะเลแดง / บับเอลมันเดบ</span>
          </button>

          <!-- US Federal Reserve -->
          <button onclick="worldMapEngine.focusHotspot('fed')" class="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer" style="left: 24%; top: 29%;">
            <div class="geo-marker-pulse pulse-cyan w-8 h-8 flex items-center justify-center">
              <div data-hotspot-count="fed" class="w-6 h-6 rounded-full bg-[#101520] border-2 border-cyan-400 text-white font-mono text-[10px] font-bold flex items-center justify-center shadow-lg group-hover:scale-125 transition">${this.hotspots.find(spot => spot.id === 'fed').count}</div>
            </div>
            <span class="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-black/90 text-cyan-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-cyan-400/40 opacity-0 group-hover:opacity-100 transition">ธนาคารกลางสหรัฐฯ (Fed)</span>
          </button>

          <!-- ECB Frankfurt -->
          <button onclick="worldMapEngine.focusHotspot('ecb')" class="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer" style="left: 51.5%; top: 26%;">
            <div class="geo-marker-pulse pulse-cyan w-8 h-8 flex items-center justify-center">
              <div data-hotspot-count="ecb" class="w-6 h-6 rounded-full bg-[#101520] border-2 border-cyan-400 text-white font-mono text-[10px] font-bold flex items-center justify-center shadow-lg group-hover:scale-125 transition">${this.hotspots.find(spot => spot.id === 'ecb').count}</div>
            </div>
            <span class="absolute top-8 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-black/90 text-cyan-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-cyan-400/40 opacity-0 group-hover:opacity-100 transition">ธนาคารกลางยุโรป (ECB)</span>
          </button>
        </div>
      </div>
    `;
  }

  setData(events, scenarios = null) {
    const wasLatest = !this.selectedAnchorDate || this.selectedAnchorDate === this.availableDates[this.availableDates.length - 1];
    this.allEvents = Array.isArray(events) ? events : [];
    this.availableDates = [...new Set(this.allEvents.map(ev => this.eventDate(ev)).filter(Boolean))].sort();
    if (wasLatest || !this.availableDates.includes(this.selectedAnchorDate)) {
      this.selectedAnchorDate = this.availableDates[this.availableDates.length - 1] || null;
    }
    if (scenarios && Array.isArray(scenarios) && scenarios.length > 0) {
      this.updateScenariosFromFeed(scenarios);
    }
    this.updateDateWindow();
  }

  eventDate(event) {
    // Workbook dates are published in Thailand time, independent of browser timezone.
    const timestamp = Number(event.timestamp);
    if (!Number.isFinite(timestamp) || timestamp <= 0) return null;
    const date = new Date(timestamp + 7 * 3600 * 1000);
    return Number.isNaN(date.getTime()) ? null : date.toISOString().slice(0, 10);
  }

  onDateSelectChange(value) {
    if (!this.availableDates.length) return;
    if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      this.selectedAnchorDate = this.availableDates.filter(date => date <= value).pop() || this.availableDates[0];
    }
    this.updateDateWindow();
  }

  stepDate(direction) {
    if (!this.availableDates.length) return;
    const current = Math.max(0, this.availableDates.indexOf(this.selectedAnchorDate));
    const index = Math.max(0, Math.min(this.availableDates.length - 1, current + Math.sign(direction)));
    this.onDateSelectChange(this.availableDates[index]);
  }

  resetToLatestDate() {
    if (this.availableDates.length) this.onDateSelectChange(this.availableDates[this.availableDates.length - 1]);
  }

  updateDateWindow() {
    const dayMs = 24 * 3600 * 1000;
    const anchorStart = this.selectedAnchorDate ? Date.parse(`${this.selectedAnchorDate}T00:00:00+07:00`) : 0;
    const windowStart = anchorStart - (this.rollingWindowDays - 1) * dayMs;
    this.events21d = this.selectedAnchorDate ? this.allEvents.filter(ev => {
      const timestamp = Number(ev.timestamp);
      return timestamp >= windowStart && timestamp < anchorStart + dayMs;
    }) : [];

    const select = document.getElementById('worldMapDateSelect');
    if (select) {
      select.replaceChildren();
      this.availableDates.forEach(date => {
        const option = document.createElement('option');
        option.value = date;
        option.textContent = date;
        select.appendChild(option);
      });
      select.disabled = !this.availableDates.length;
      select.value = this.selectedAnchorDate || '';
    }
    const current = this.availableDates.indexOf(this.selectedAnchorDate);
    const previous = document.getElementById('worldMapPreviousDate');
    const next = document.getElementById('worldMapNextDate');
    const latest = document.getElementById('worldMapLatestDate');
    if (previous) previous.disabled = current <= 0;
    if (next) next.disabled = current < 0 || current >= this.availableDates.length - 1;
    if (latest) latest.disabled = current < 0 || current === this.availableDates.length - 1;

    const range = document.getElementById('rolling21DateRangeLabel');
    const rangeText = this.selectedAnchorDate ? `${new Date(windowStart + 7 * 3600 * 1000).toISOString().slice(0, 10)} ถึง ${this.selectedAnchorDate}` : 'ไม่มีข้อมูลวันที่';
    if (range) range.innerText = rangeText;
    const archive = document.getElementById('geoArchiveDateBadge');
    if (archive) archive.innerText = rangeText;
    const count = document.getElementById('rolling21CountBadge');
    if (count) count.innerText = `${this.events21d.length} ข่าว`;
    const total = document.getElementById('donutTotalCountBadge');
    if (total) total.innerText = this.events21d.length;
    this.filterEvents();
  }

  updateScenariosFromFeed(scenarios) {
    if (!Array.isArray(scenarios) || scenarios.length === 0) return;
    scenarios.forEach(scen => {
      const sId = (scen.id || '').toLowerCase().trim();
      const existing = this.hotspots.find(h => h.id.toLowerCase() === sId);
      if (existing) {
        if (scen.name) existing.name = scen.name;
        if (scen.tension_level) existing.tensionLevel = scen.tension_level;
        if (scen.region) existing.region = scen.region;
        if (scen.synced_from_sheet) existing.synced_from_sheet = true;
        if (scen.last_updated) existing.last_updated = scen.last_updated;

        // Update Scenario A
        if (scen.event_a) existing.scenario.eventA = scen.event_a;
        if (scen.energy_impact) existing.scenario.economicImpact.energy = scen.energy_impact;
        if (scen.inflation_impact) existing.scenario.economicImpact.inflation = scen.inflation_impact;
        if (scen.equities_impact) existing.scenario.economicImpact.equities = scen.equities_impact;
        if (scen.safe_haven_impact) existing.scenario.economicImpact.safeHaven = scen.safe_haven_impact;

        // Update Playbook
        if (scen.action_portfolio) existing.scenario.actionPlaybook.portfolio = scen.action_portfolio;
        if (scen.action_hedge) existing.scenario.actionPlaybook.tacticalHedge = scen.action_hedge;
        if (scen.action_supply_chain) existing.scenario.actionPlaybook.supplyChain = scen.action_supply_chain;
        if (scen.action_crypto) existing.scenario.actionPlaybook.crypto = scen.action_crypto;

        // Update Scenario B
        if (scen.event_b) existing.scenario.eventB = scen.event_b;
        if (scen.deescalation_impact && existing.scenario.economicImpactB) {
          existing.scenario.economicImpactB.energy = scen.deescalation_impact;
        }
      }
    });

    this.updateScenarioPanel();
  }

  setCategory(cat) {
    this.activeCategory = cat;
    this.filterEvents();
    this.updateCategoryChipsUI();
  }

  filterEvents() {
    // Filter events matching geopolitical / war / macro keywords
    const warKeywords = ['สงคราม', 'การเมือง', 'ตะวันออกกลาง', 'อิสราเอล', 'อิหร่าน', 'รัสเซีย', 'ยูเครน', 'สหรัฐ', 'จีน', 'น้ำมัน', 'พลังงาน', 'เงินเฟ้อ', 'ดอกเบี้ย', 'ไต้หวัน', 'ฮอร์มุซ', 'ทะเลแดง', 'ลิเธียม', 'opec', 'fed', 'ecb', 'ทรัมป์', 'trump'];

    this.filteredEvents = this.events21d.filter(ev => {
      const text = `${ev.title || ''} ${ev.summary || ''} ${ev.details || ''} ${ev.category || ''}`.toLowerCase();
      
      if (this.activeCategory === 'geopolitics') {
        return text.includes('สงคราม') || text.includes('การเมือง') || text.includes('อิหร่าน') || text.includes('อิสราเอล') || text.includes('ยูเครน') || text.includes('รัสเซีย') || text.includes('ไต้หวัน') || text.includes('ทะเลแดง') || text.includes('ฮอร์มุซ');
      } else if (this.activeCategory === 'macro') {
        return text.includes('เศรษฐกิจ') || text.includes('เงินเฟ้อ') || text.includes('ดอกเบี้ย') || text.includes('fed') || text.includes('ecb') || text.includes('gdp');
      } else if (this.activeCategory === 'energy') {
        return text.includes('น้ำมัน') || text.includes('พลังงาน') || text.includes('opec') || text.includes('ก๊าซ') || text.includes('ลิเธียม');
      } else if (this.activeCategory === 'crypto') {
        return ev.category === 'คริปโต' || text.includes('คริปโต') || text.includes('บิตคอยน์') || text.includes('bitcoin');
      }
      
      return true;
    });

    // Update visible counter
    const visEl = document.getElementById('mapVisibleCountBadge');
    if (visEl) visEl.innerText = `${this.filteredEvents.length} / ${this.events21d.length}`;

    const warBadge = document.getElementById('mapWarSignalsBadge');
    if (warBadge) {
      const warCount = this.events21d.filter(ev => warKeywords.some(kw => `${ev.title || ''} ${ev.summary || ''} ${ev.details || ''} ${ev.category || ''}`.toLowerCase().includes(kw))).length;
      const pct = Math.round((warCount / (this.events21d.length || 1)) * 100);
      warBadge.innerText = `${pct}%`;
    }

    this.hotspots.forEach(spot => {
      spot.count = this.filteredEvents.filter(ev => this.matchesHotspot(ev, spot)).length;
    });
    const hotspots = document.getElementById('mapHotspotsCountBadge');
    if (hotspots) hotspots.innerText = `${this.hotspots.filter(spot => spot.count > 0).length} โซน`;
    this.renderHotspots();
    document.querySelectorAll('[data-hotspot-count]').forEach(pin => {
      const spot = this.hotspots.find(item => item.id === pin.dataset.hotspotCount);
      if (spot) pin.textContent = spot.count;
    });
    this.renderGeopoliticalFeed();
    this.updateScenarioPanel();
    this.updateRelatedSignals();
  }

  matchesHotspot(event, spot) {
    const text = `${event.title || ''} ${event.summary || ''} ${event.details || ''}`.toLowerCase();
    return spot.keywords.some(keyword => text.includes(keyword.toLowerCase()));
  }

  renderHotspots() {
    if (!this.markersLayer) return;
    this.markersLayer.clearLayers();

    this.hotspots.forEach(spot => {
      // Custom Glowing DivIcon
      const iconHtml = `
        <div class="geo-marker-pulse ${spot.pulseClass}" style="width: 32px; height: 32px;">
          <div style="
            width: 26px; 
            height: 26px; 
            background: #101520; 
            border: 2px solid ${spot.badgeColor}; 
            border-radius: 50%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            color: #ffffff; 
            font-family: 'JetBrains Mono', monospace; 
            font-size: 10px; 
            font-weight: 700;
            box-shadow: 0 0 10px ${spot.badgeColor}80;
          ">
            ${spot.count}
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'custom-geo-pin',
        html: iconHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      const marker = L.marker(spot.coords, { icon: customIcon });

      // Click to inspect hotspot scenario
      marker.on('click', () => {
        this.selectHotspot(spot, true);
      });

      // Tooltip on hover
      marker.bindTooltip(`
        <div style="font-family: 'Prompt', sans-serif; font-size: 12px; color: #fff; padding: 2px 4px;">
          <div style="color: ${spot.badgeColor}; font-weight: 700; font-size: 11px;">● ${escapeNewsHtml(spot.tensionLevel)}</div>
          <div style="font-weight: 600; margin-top: 2px;">${escapeNewsHtml(spot.name)}</div>
          <div style="font-size: 11px; color: #94a3b8;">${spot.count} ข่าวที่เชื่อมโยง (คลิกวิเคราะห์ Scenario)</div>
        </div>
      `, {
        direction: 'top',
        className: 'dark-leaflet-tooltip',
        offset: [0, -14]
      });

      this.markersLayer.addLayer(marker);
    });
  }

  renderConnectionArcs() {
    if (!this.connectionsLayer) return;
    this.connectionsLayer.clearLayers();

    const spotMap = {};
    this.hotspots.forEach(h => spotMap[h.id] = h);

    this.connectionArcs.forEach(arc => {
      const fromSpot = spotMap[arc.from];
      const toSpot = spotMap[arc.to];
      if (!fromSpot || !toSpot) return;

      // Draw subtle dashed golden polyline
      const polyline = L.polyline([fromSpot.coords, toSpot.coords], {
        color: '#e5a93c',
        weight: 1.5,
        opacity: 0.65,
        dashArray: '4, 6',
        lineCap: 'round'
      });

      polyline.bindTooltip(`<span style="font-family: 'JetBrains Mono', monospace; font-size: 10px;">${arc.label}</span>`, {
        sticky: true,
        className: 'dark-leaflet-tooltip'
      });

      this.connectionsLayer.addLayer(polyline);
    });
  }

  selectHotspot(spot, animate = true) {
    if (!spot) return;
    this.selectedHotspot = spot;

    // Center map smoothly if available
    if (this.map) {
      try {
        if (animate) {
          this.map.flyTo(spot.coords, Math.max(this.map.getZoom(), 4), { duration: 1.0, animate: !this.prefersReducedMotion() });
        } else {
          this.map.setView(spot.coords, 3);
        }
      } catch (err) {
        console.warn('Map flyTo warning:', err);
      }
    }

    // Populate Scenario Panel & Related Signals
    this.updateScenarioPanel();
    this.updateRelatedSignals();
  }

  setScenarioMode(mode) {
    this.scenarioMode = mode;

    // Toggle button UI
    const btnEsc = document.getElementById('scenBtnEscalation');
    const btnDeesc = document.getElementById('scenBtnDeescalation');

    if (btnEsc && btnDeesc) {
      if (mode === 'escalation') {
        btnEsc.className = 'px-2.5 py-1 rounded text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/50 transition';
        btnDeesc.className = 'px-2.5 py-1 rounded text-xs font-medium bg-[#131722] text-slate-400 border border-[#1c2333] hover:text-white transition';
      } else {
        btnEsc.className = 'px-2.5 py-1 rounded text-xs font-medium bg-[#131722] text-slate-400 border border-[#1c2333] hover:text-white transition';
        btnDeesc.className = 'px-2.5 py-1 rounded text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 transition';
      }
    }

    this.updateScenarioPanel();
  }

  updateScenarioPanel() {
    if (!this.selectedHotspot) {
      this.selectedHotspot = this.hotspots[0];
    }
    const spot = this.selectedHotspot;
    if (!spot) return;
    const scen = spot.scenario;

    // Title
    const titleEl = document.getElementById('scenarioSignalTitle');
    if (titleEl) {
      titleEl.innerText = `${spot.name} — ระดับตามแม่แบบ: ${spot.tensionLevel}`;
    }

    // Tags
    const tagsEl = document.getElementById('scenarioSignalTags');
    if (tagsEl) {
      const observedCount = this.selectedAnchorDate ? `${spot.count} ข่าว` : 'ยังไม่มีข้อมูลวันที่';
      tagsEl.innerHTML = `
        <span class="px-2 py-0.5 rounded text-[11px] font-bold" style="background-color: ${spot.badgeColor}25; color: ${spot.badgeColor}; border: 1px solid ${spot.badgeColor}50;">
          ● ${escapeNewsHtml(spot.region)}
        </span>
        <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-[#161c28] text-slate-300 border border-[#242e42]">
          📍 ${spot.coords[0].toFixed(2)}°, ${spot.coords[1].toFixed(2)}°
        </span>
        <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-[#161c28] text-[#e5a93c] border border-[#e5a93c]/30 font-semibold">
          ⚡ ข่าวที่จับคู่ด้วยคำหลักในกรอบ 21 วัน: ${escapeNewsHtml(observedCount)}
        </span>
      `;
    }

    // Focus & Open Source Button Links
    const openSourceBtn = document.getElementById('scenarioOpenSourceBtn');
    if (openSourceBtn) {
      openSourceBtn.textContent = 'ข่าวที่จับคู่ด้วยคำหลัก ↗';
      openSourceBtn.setAttribute('aria-label', 'เปิดข่าวที่จับคู่ด้วยคำหลักในกรอบ 21 วัน');
      // Find a matching event from live news if available
      const matching = this.filteredEvents.find(ev => this.matchesHotspot(ev, spot));
      const sourceUrl = matching ? safeNewsUrl(matching.source_url || matching.source_link || '') : '';
      if (sourceUrl) {
        openSourceBtn.href = sourceUrl;
        openSourceBtn.style.display = 'inline-flex';
      } else {
        openSourceBtn.removeAttribute('href');
        openSourceBtn.style.display = 'none';
      }
    }

    // Scenario Matrix Body
    const bodyEl = document.getElementById('scenarioMatrixBody');
    if (!bodyEl) return;
    const templateOrigin = spot.synced_from_sheet ? 'เนื้อหาแม่แบบโหลดจาก Google Sheet' : 'เนื้อหาแม่แบบสำรองภายในระบบ';
    const scenarioNotice = `
      <div class="bg-[#111622] p-2.5 rounded border border-[#1c2333]" data-scenario-notice>
        <p class="text-slate-200 text-xs leading-relaxed">แม่แบบ What-if ตามกฎที่กำหนด ไม่ใช่ข้อสรุปจากข่าวที่จับคู่</p>
        <p class="text-slate-200 text-xs leading-relaxed">ตัวเลขและผลกระทบเป็นสมมติฐาน ต้องตรวจสอบกับข้อมูลปฐมภูมิ ไม่ใช่การคาดการณ์ และไม่ใช่คำแนะนำการลงทุน</p>
        <p class="text-slate-400 text-[11px] mt-1">ที่มาของเนื้อหาแม่แบบ: ${escapeNewsHtml(templateOrigin)}</p>
      </div>
    `;

    if (this.scenarioMode === 'escalation') {
      bodyEl.innerHTML = `
        ${scenarioNotice}
        <!-- Event A Trigger -->
        <div class="bg-rose-950/25 border border-rose-500/35 p-3 rounded">
          <div class="text-rose-400 font-bold text-xs flex items-center gap-1.5 mb-1">
            <span class="w-2 h-2 rounded-full bg-rose-500"></span>
            <span>กรณีจำลองเหตุการณ์ A (What-If Event A):</span>
          </div>
          <p class="text-slate-100 text-[13px] leading-relaxed">
            "${escapeNewsHtml(scen.eventA)}"
          </p>
        </div>

        <!-- Economic Transmission Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          <div class="bg-[#111622] p-2.5 rounded border border-[#1c2333]">
            <div class="text-[#e5a93c] font-bold text-[11px] flex items-center gap-1 mb-1">
              <span>🛢️</span> <span>พลังงาน & อุปทาน (Energy & Supply):</span>
            </div>
            <p class="text-slate-200 text-xs leading-relaxed">${escapeNewsHtml(scen.economicImpact.energy)}</p>
          </div>

          <div class="bg-[#111622] p-2.5 rounded border border-[#1c2333]">
            <div class="text-amber-400 font-bold text-[11px] flex items-center gap-1 mb-1">
              <span>📈</span> <span>เงินเฟ้อ & ดอกเบี้ย (Inflation & Rates):</span>
            </div>
            <p class="text-slate-200 text-xs leading-relaxed">${escapeNewsHtml(scen.economicImpact.inflation)}</p>
          </div>

          <div class="bg-[#111622] p-2.5 rounded border border-[#1c2333]">
            <div class="text-rose-400 font-bold text-[11px] flex items-center gap-1 mb-1">
              <span>📉</span> <span>ตลาดหุ้น & เสี่ยง (Market Sell-Off):</span>
            </div>
            <p class="text-slate-200 text-xs leading-relaxed">${escapeNewsHtml(scen.economicImpact.equities)}</p>
          </div>

          <div class="bg-[#111622] p-2.5 rounded border border-[#1c2333]">
            <div class="text-emerald-400 font-bold text-[11px] flex items-center gap-1 mb-1">
              <span>🛡️</span> <span>สินทรัพย์ปลอดภัย (Safe Haven Flow):</span>
            </div>
            <p class="text-slate-200 text-xs leading-relaxed">${escapeNewsHtml(scen.economicImpact.safeHaven)}</p>
          </div>
        </div>

        <!-- Action Playbook -->
        <div class="bg-gradient-to-r from-[#141a26] to-[#10141f] border border-[#e5a93c]/40 p-3 rounded">
          <div class="text-[#e5a93c] font-bold text-xs flex items-center gap-1.5 mb-1.5 font-mono">
            <span>🎯</span> <span>ประเด็นติดตามและแนวทางเตรียมรับมือ:</span>
          </div>
          <ul class="text-slate-200 text-xs space-y-1.5 leading-relaxed list-disc list-inside">
            <li><strong class="text-white">ปรับพอร์ต (Defensive):</strong> ${escapeNewsHtml(scen.actionPlaybook.portfolio)}</li>
            <li><strong class="text-white">ป้องกันความเสี่ยง (Tactical Hedge):</strong> ${escapeNewsHtml(scen.actionPlaybook.tacticalHedge)}</li>
            ${scen.actionPlaybook.supplyChain ? `<li><strong class="text-white">ซัพพลายเชน (Supply Chain):</strong> ${escapeNewsHtml(scen.actionPlaybook.supplyChain)}</li>` : ''}
            ${scen.actionPlaybook.crypto ? `<li><strong class="text-white">สินทรัพย์ดิจิทัล (Crypto Play):</strong> ${escapeNewsHtml(scen.actionPlaybook.crypto)}</li>` : ''}
          </ul>
        </div>
      `;
    } else {
      // De-escalation mode
      bodyEl.innerHTML = `
        ${scenarioNotice}
        <div class="bg-emerald-950/25 border border-emerald-500/35 p-3 rounded">
          <div class="text-emerald-400 font-bold text-xs flex items-center gap-1.5 mb-1">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>กรณีผ่อนคลายความตึงเครียด (Scenario B: De-Escalation):</span>
          </div>
          <p class="text-slate-100 text-[13px] leading-relaxed">
            "${escapeNewsHtml(scen.eventB || 'การเจรจาทางการทูตประสบความสำเร็จ หรือมีการประกาศข้อตกลงหยุดยิงชั่วคราว')}"
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          <div class="bg-[#111622] p-2.5 rounded border border-[#1c2333]">
            <div class="text-[#e5a93c] font-bold text-[11px] flex items-center gap-1 mb-1">
              <span>🛢️</span> <span>พลังงาน (Energy Market Normalization):</span>
            </div>
            <p class="text-slate-200 text-xs leading-relaxed">${escapeNewsHtml(scen.economicImpactB ? scen.economicImpactB.energy : 'ราคาน้ำมันดิบทยอยปรับตัวลดลงสู่ระดับปกติ')}</p>
          </div>

          <div class="bg-[#111622] p-2.5 rounded border border-[#1c2333]">
            <div class="text-emerald-400 font-bold text-[11px] flex items-center gap-1 mb-1">
              <span>📈</span> <span>ตลาดหุ้น (Relief Rally):</span>
            </div>
            <p class="text-slate-200 text-xs leading-relaxed">${escapeNewsHtml(scen.economicImpactB ? scen.economicImpactB.equities : 'ตลาดหุ้นปรับตัวขึ้นจากความคลายกังวล')}</p>
          </div>
        </div>

        <div class="bg-[#141a26] border border-emerald-500/30 p-3 rounded">
          <div class="text-emerald-400 font-bold text-xs flex items-center gap-1.5 mb-1 font-mono">
            <span>🎯</span> <span>ประเด็นติดตามและแนวทางเตรียมรับมือ:</span>
          </div>
          <ul class="text-slate-200 text-xs space-y-1.5 leading-relaxed list-disc list-inside">
            <li>${escapeNewsHtml(scen.actionPlaybookB ? scen.actionPlaybookB.portfolio : 'ทยอยลดสถานะเงินสด และกลับเข้าสะสมหุ้นกลุ่มเติบโต')}</li>
            <li>${escapeNewsHtml(scen.actionPlaybookB ? scen.actionPlaybookB.tacticalHedge : 'ปิดสถานะทำกำไรจากการ Hedge น้ำมัน')}</li>
          </ul>
        </div>
      `;
    }
  }

  updateRelatedSignals() {
    const listEl = document.getElementById('relatedSignalsList');
    const countEl = document.getElementById('relatedSignalsCount');
    if (!listEl) return;

    if (!this.selectedHotspot) {
      this.selectedHotspot = this.hotspots[0];
    }

    const matches = this.filteredEvents.filter(ev => this.matchesHotspot(ev, this.selectedHotspot)).slice(0, 6);

    if (countEl) countEl.innerText = `${matches.length} ข่าว`;

    if (matches.length === 0) {
      listEl.innerHTML = '<div class="text-slate-500 text-xs p-2">ไม่พบข่าวที่ตรงกับคำสำคัญนี้ในช่วงเวลานี้</div>';
      return;
    }

    listEl.innerHTML = matches.map((ev, index) => {
      const realUrl = safeNewsUrl(ev.source_url || ev.source_link || '');
      const sourceName = escapeNewsHtml(ev.source_name || ev.provider || 'ข่าวต้นทาง');
      const hasRealUrl = Boolean(realUrl);

      return `
        <div class="p-2.5 rounded bg-[#0b0e14] border border-[#1a2232] hover:border-[#e5a93c]/50 transition cursor-pointer" data-event-index="${index}" tabindex="0" role="button">
          <div class="flex items-center justify-between text-[10px] text-slate-400 font-mono mb-1">
            <span class="text-[#e5a93c]">${escapeNewsHtml(ev.category)}</span>
            <span>${escapeNewsHtml(ev.display_time)}</span>
          </div>
          <h5 class="text-xs font-semibold text-white leading-snug line-clamp-2 hover:text-[#e5a93c] transition mb-1">
            ${escapeNewsHtml(ev.title)}
          </h5>
          <div class="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-[#161d2a]">
            <span class="font-mono text-slate-400 truncate max-w-[140px]">${sourceName}</span>
            ${hasRealUrl ? `
              <a href="${escapeNewsHtml(realUrl)}" target="_blank" rel="noopener noreferrer" class="text-[#e5a93c] hover:underline font-mono text-[10px] flex items-center gap-0.5">
                <span>อ่านจริง</span> <span>↗</span>
              </a>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
    this.bindEventCards(listEl, matches);
  }

  renderGeopoliticalFeed() {
    const feedEl = document.getElementById('geoFeedList');
    const badgeEl = document.getElementById('geoFeedCountBadge');
    if (!feedEl) return;

    const list = this.filteredEvents;

    if (badgeEl) badgeEl.innerText = list && list.length > 30 ? `แสดง 30 จาก ${list.length} ข่าว` : `${list ? list.length : 0} ข่าว`;

    if (!list || list.length === 0) {
      feedEl.innerHTML = `
        <div class="editorial-card p-6 text-center text-slate-400 text-xs">
          ไม่พบข่าวในกรอบเวลาและหมวดหมู่ที่เลือก
        </div>
      `;
      return;
    }

    feedEl.innerHTML = list.slice(0, 30).map((ev, index) => {
      const realUrl = safeNewsUrl(ev.source_url || ev.source_link || '');
      const sourceName = escapeNewsHtml(ev.source_name || ev.provider || 'ข่าวต้นทาง');
      const hasRealUrl = Boolean(realUrl);

      // Category badge styling
      let catColor = '#60A5FA';
      let catBorder = 'rgba(96, 165, 250, 0.3)';
      if (ev.category === 'การเมือง') { catColor = '#FB7185'; catBorder = 'rgba(251, 113, 133, 0.3)'; }
      else if (ev.category === 'เศรษฐกิจ') { catColor = '#34D399'; catBorder = 'rgba(52, 211, 153, 0.3)'; }
      else if (ev.category === 'การเงิน') { catColor = '#FBBF24'; catBorder = 'rgba(251, 191, 36, 0.3)'; }
      else if (ev.category === 'คริปโต') { catColor = '#C084FC'; catBorder = 'rgba(192, 132, 252, 0.3)'; }

      return `
        <article class="p-3 rounded bg-[#0e121a] border border-[#1c2333] hover:border-[#e5a93c]/50 transition flex flex-col gap-2">
          <div class="flex items-center justify-between text-[11px]">
            <span class="px-2 py-0.5 rounded font-bold uppercase tracking-wider text-[10px]" style="color: ${catColor}; border: 1px solid ${catBorder}; background: ${catColor}15;">
              ${escapeNewsHtml(ev.category)}
            </span>
            <span class="font-mono text-slate-400 text-[11px]">${escapeNewsHtml(ev.display_time)}</span>
          </div>

          <h4 class="text-xs font-bold text-white leading-snug line-clamp-2 hover:text-[#e5a93c] transition cursor-pointer" data-event-index="${index}" tabindex="0" role="button">
            ${escapeNewsHtml(ev.title)}
          </h4>

          <p class="text-[12px] text-slate-300 line-clamp-2 leading-relaxed">
            ${escapeNewsHtml(ev.summary || 'คลิกเพื่อดูรายละเอียดข่าวและหลักฐานประกอบฉบับเต็ม...')}
          </p>

          <div class="flex items-center justify-between text-xs pt-2 border-t border-[#18202e] text-slate-400 mt-1">
            <div class="font-mono text-[11px] truncate max-w-[160px]">
              <span class="text-slate-500">แหล่ง:</span>
              ${hasRealUrl ? `
                <a href="${escapeNewsHtml(realUrl)}" target="_blank" rel="noopener noreferrer" class="text-[#e5a93c] hover:underline font-medium">
                  ${sourceName} ↗
                </a>
              ` : `<span class="text-slate-300">${sourceName}</span>`}
            </div>

            <button data-event-index="${index}" class="px-2 py-0.5 rounded bg-[#161c28] hover:bg-[#202738] text-slate-200 text-[11px] font-semibold border border-[#2d384e] transition">
              อ่านฉบับเต็ม ➔
            </button>
          </div>
        </article>
      `;
    }).join('');
    this.bindEventCards(feedEl, list);
  }

  bindEventCards(container, events) {
    container.querySelectorAll('[data-event-index]').forEach(card => {
      const event = events[Number(card.dataset.eventIndex)];
      if (!event) return;
      const open = interaction => {
        if (interaction && interaction.target.closest('a')) return;
        if (interaction && window.getSelection) {
          const selection = window.getSelection();
          if (selection && !selection.isCollapsed && (card.contains(selection.anchorNode) || card.contains(selection.focusNode))) return;
        }
        if (window.openDetailModal) window.openDetailModal(event);
      };
      card.addEventListener('click', open);
      card.addEventListener('keydown', interaction => {
        if (interaction.target === card && (interaction.key === 'Enter' || interaction.key === ' ')) {
          interaction.preventDefault();
          open();
        }
      });
    });
  }

  setupCategoryFilterChips() {
    const container = document.getElementById('worldMapCategoryChips');
    if (!container) return;

    const chips = [
      { id: 'all', label: 'ทั้งหมด (All)', icon: '📌' },
      { id: 'geopolitics', label: 'สงคราม & ภูมิรัฐศาสตร์', icon: '⚔️' },
      { id: 'macro', label: 'เศรษฐกิจมหาภาค (Macro)', icon: '🌐' },
      { id: 'energy', label: 'พลังงาน & แร่ยุทธศาสตร์', icon: '🛢️' },
      { id: 'crypto', label: 'คริปโต & สินทรัพย์ดิจิทัล', icon: '🪙' }
    ];

    container.innerHTML = chips.map(c => `
      <button 
        onclick="worldMapEngine.setCategory('${c.id}')"
        class="geo-cat-chip px-2.5 py-1 rounded text-xs font-medium transition flex items-center gap-1.5 ${this.activeCategory === c.id ? 'active bg-[#e5a93c]/20 text-[#e5a93c] border border-[#e5a93c]/50 font-bold' : 'bg-[#131722] text-slate-400 border border-[#1c2333] hover:text-white'}"
        data-cat="${c.id}"
      >
        <span>${c.icon}</span>
        <span>${c.label}</span>
      </button>
    `).join('');
  }

  updateCategoryChipsUI() {
    const chips = document.querySelectorAll('.geo-cat-chip');
    chips.forEach(chip => {
      const cat = chip.dataset.cat;
      if (cat === this.activeCategory) {
        chip.className = 'geo-cat-chip px-2.5 py-1 rounded text-xs transition flex items-center gap-1.5 active bg-[#e5a93c]/20 text-[#e5a93c] border border-[#e5a93c]/50 font-bold';
      } else {
        chip.className = 'geo-cat-chip px-2.5 py-1 rounded text-xs font-medium transition flex items-center gap-1.5 bg-[#131722] text-slate-400 border border-[#1c2333] hover:text-white';
      }
    });
  }

  focusHotspot(hotspotId) {
    const spot = this.hotspots.find(h => h.id === hotspotId);
    if (spot) {
      this.selectHotspot(spot, true);
    }
  }

  focusCurrentEvent() {
    if (this.selectedHotspot && this.map) {
      this.map.flyTo(this.selectedHotspot.coords, 6, { duration: 1.0, animate: !this.prefersReducedMotion() });
    }
  }

  setBasemap(type) {
    if (!this.map) return;
    if (this.baseTileLayer) this.map.removeLayer(this.baseTileLayer);
    if (this.referenceTileLayer) this.map.removeLayer(this.referenceTileLayer);

    if (type === 'satellite') {
      this.baseTileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 18,
        attribution: 'Tiles &copy; Esri'
      }).addTo(this.map);
      this.referenceTileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 18,
        opacity: 0.85
      }).addTo(this.map);
    } else if (type === 'osm') {
      this.baseTileLayer = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap'
      }).addTo(this.map);
    } else {
      // Default: High-Quality ESRI Dark Gray Canvas (No watermark, no key)
      this.baseTileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 16,
        attribution: 'Tiles &copy; Esri'
      }).addTo(this.map);
      this.referenceTileLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 16,
        opacity: 0.75
      }).addTo(this.map);
    }

    if (this.markersLayer) this.markersLayer.bringToFront();
    if (this.connectionsLayer) this.connectionsLayer.bringToFront();
  }

  resetView() {
    if (this.map) {
      this.map.flyTo([22, 25], 2, { duration: 1.2, animate: !this.prefersReducedMotion() });
    }
  }

  prefersReducedMotion() {
    return Boolean(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }

  invalidateSize() {
    if (this.map) {
      try {
        this.map.invalidateSize();
      } catch (err) {
        console.warn('invalidateSize warning:', err);
      }
    }
  }
}

// Global Singleton Instance Available Immediately!
window.worldMapEngine = new WorldMapEngine('leafletMap');

// Fallback switchMainTab if clicked before app.js completes
if (typeof window.switchMainTab !== 'function') {
  window.switchMainTab = function(tabName) {
    const timelineContent = document.getElementById('marketTimelineTabContent');
    const worldMapContent = document.getElementById('worldMapTabContent');
    const tabTimelineBtn = document.getElementById('tabMarketTimelineBtn');
    const tabWorldMapBtn = document.getElementById('tabWorldMapBtn');

    if (tabName === 'world-map') {
      if (timelineContent) { timelineContent.style.display = 'none'; timelineContent.classList.add('hidden'); }
      if (worldMapContent) { worldMapContent.style.display = 'flex'; worldMapContent.classList.remove('hidden'); }

      if (tabTimelineBtn) {
        tabTimelineBtn.classList.remove('active', 'bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/50');
        tabTimelineBtn.classList.add('bg-[#131722]', 'text-slate-300', 'border-[#1c2333]');
      }
      if (tabWorldMapBtn) {
        tabWorldMapBtn.classList.remove('bg-[#131722]', 'text-slate-300', 'border-[#1c2333]');
        tabWorldMapBtn.classList.add('active', 'bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/50');
      }

      if (window.worldMapEngine) {
        if (!window.worldMapEngine.isInitialized) {
          window.worldMapEngine.init();
        }
        setTimeout(() => window.worldMapEngine.invalidateSize(), 150);
      }
    } else {
      if (worldMapContent) { worldMapContent.style.display = 'none'; worldMapContent.classList.add('hidden'); }
      if (timelineContent) { timelineContent.style.display = 'flex'; timelineContent.classList.remove('hidden'); }

      if (tabWorldMapBtn) {
        tabWorldMapBtn.classList.remove('active', 'bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/50');
        tabWorldMapBtn.classList.add('bg-[#131722]', 'text-slate-300', 'border-[#1c2333]');
      }
      if (tabTimelineBtn) {
        tabTimelineBtn.classList.remove('bg-[#131722]', 'text-slate-300', 'border-[#1c2333]');
        tabTimelineBtn.classList.add('active', 'bg-[#e5a93c]/20', 'text-[#e5a93c]', 'border-[#e5a93c]/50');
      }
    }
  };
}
