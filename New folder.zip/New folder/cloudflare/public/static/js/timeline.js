/**
 * Clean Editorial Timeline Engine — WRITE TIME DNA
 * Features:
 * - Minimalist, uncluttered Financial Terminal layout
 * - 5 Clean Category Swimlanes with subtle contrast
 * - Elegant BTC price benchmark curve with soft area fill (rendered in background)
 * - Clean event markers (Dots & Cluster Badges) WITHOUT messy inline text clutter
 * - Dynamic single guideline and time cursor on hover/selection
 * - Rich, floating interactive Tooltip with immediate headline & source
 * - Generous 22px click radius and 4px drag threshold for rock-solid click-to-read
 * - Razor-sharp typography: High-DPI 2x retina scaling and Prompt typography
 */
class TimelineEngine {
  constructor(canvasId, containerId, tooltipId, onEventClick, onWindowChange) {
    this.canvas = document.getElementById(canvasId);
    this.container = document.getElementById(containerId);
    this.tooltip = document.getElementById(tooltipId);
    this.ctx = this.canvas.getContext('2d');
    this.onEventClick = onEventClick;
    this.onWindowChange = onWindowChange;

    // View Window & Limits
    this.minTime = 0;
    this.maxTime = 0;
    this.viewStart = 0;
    this.viewEnd = 0;

    // Data & Filters
    this.events = [];
    this.activeCategories = new Set(['ธุรกิจ', 'เศรษฐกิจ', 'การเงิน', 'การเมือง', 'คริปโต']);
    this.searchQuery = '';
    this.priceCandles = [];
    this.showPriceOverlay = true;
    this.showEventLabels = false;
    this.selectedEvent = null;

    // Interaction State
    this.isMouseDown = false;
    this.hasDragged = false;
    this.mouseDownX = 0;
    this.mouseDownY = 0;
    this.dragStartTimeWindow = { start: 0, end: 0 };
    this.hoveredItem = null;
    this.hoveredMousePos = null;
    this._renderedNodes = [];

    // Clean Editorial Category Theme (Restrained & Elegant)
    this.categories = {
      'ธุรกิจ': { color: '#60A5FA', tint: 'rgba(96, 165, 250, 0.12)', border: 'rgba(96, 165, 250, 0.3)', icon: '🏢' },
      'เศรษฐกิจ': { color: '#34D399', tint: 'rgba(52, 211, 153, 0.12)', border: 'rgba(52, 211, 153, 0.3)', icon: '🌐' },
      'การเงิน': { color: '#FBBF24', tint: 'rgba(251, 191, 36, 0.12)', border: 'rgba(251, 191, 36, 0.3)', icon: '💰' },
      'การเมือง': { color: '#FB7185', tint: 'rgba(251, 113, 133, 0.12)', border: 'rgba(251, 113, 133, 0.3)', icon: '🏛️' },
      'คริปโต': { color: '#C084FC', tint: 'rgba(192, 132, 252, 0.12)', border: 'rgba(192, 132, 252, 0.3)', icon: '🪙' }
    };
    this.categoryNames = Object.keys(this.categories);

    this.bindEvents();
  }

  setData(events, minTime, maxTime, priceCandles = []) {
    this.events = events;
    this.minTime = minTime;
    this.maxTime = maxTime;
    this.priceCandles = priceCandles;

    if (this.viewStart === 0 || this.viewEnd === 0) {
      const defaultDuration = 7 * 24 * 3600 * 1000;
      this.viewEnd = maxTime;
      this.viewStart = Math.max(minTime, maxTime - defaultDuration);
    }
    this.render();
  }

  setSelectedEvent(ev) {
    this.selectedEvent = ev;
    this.render();
  }

  setFilters(activeCategories, searchQuery) {
    this.activeCategories = new Set(activeCategories);
    this.searchQuery = (searchQuery || '').toLowerCase().trim();
    this.render();
  }

  setWindow(start, end) {
    this.viewStart = Math.max(this.minTime, start);
    this.viewEnd = Math.min(this.maxTime, end);
    this.render();
  }

  togglePriceOverlay(enable) {
    this.showPriceOverlay = enable;
    this.render();
  }

  toggleEventLabels(enable) {
    if (typeof enable === 'boolean') {
      this.showEventLabels = enable;
    } else {
      this.showEventLabels = !this.showEventLabels;
    }
    this.render();
  }

  getFilteredEvents() {
    return this.events.filter(ev => {
      if (!this.activeCategories.has(ev.category)) return false;
      if (this.searchQuery) {
        const q = this.searchQuery;
        const matchTitle = ev.title && ev.title.toLowerCase().includes(q);
        const matchSummary = ev.summary && ev.summary.toLowerCase().includes(q);
        const matchDetails = ev.details && ev.details.toLowerCase().includes(q);
        const matchProvider = ev.provider && ev.provider.toLowerCase().includes(q);
        if (!matchTitle && !matchSummary && !matchDetails && !matchProvider) return false;
      }
      return true;
    });
  }

  bindEvents() {
    this.canvas.addEventListener('keydown', (event) => this.handleKeyboard(event));
    // Wheel Zoom
    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const rect = this.canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseRatio = mouseX / rect.width;

      const zoomFactor = e.deltaY > 0 ? 1.25 : 0.8;
      const currentSpan = this.viewEnd - this.viewStart;
      const newSpan = Math.max(2 * 3600 * 1000, Math.min(this.maxTime - this.minTime, currentSpan * zoomFactor));

      const focusTime = this.viewStart + currentSpan * mouseRatio;
      let newStart = Math.max(this.minTime, focusTime - newSpan * mouseRatio);
      let newEnd = Math.min(this.maxTime, newStart + newSpan);

      if (newEnd >= this.maxTime) {
        newStart = Math.max(this.minTime, this.maxTime - newSpan);
      }

      this.viewStart = newStart;
      this.viewEnd = newEnd;
      this.render();
      if (this.onWindowChange) this.onWindowChange(this.viewStart, this.viewEnd);
    }, { passive: false });

    // Drag Pan & Click Handling
    this.canvas.addEventListener('mousedown', (e) => {
      this.canvas.focus({ preventScroll: true });
      this.isMouseDown = true;
      this.hasDragged = false;
      this.mouseDownX = e.clientX;
      this.mouseDownY = e.clientY;
      this.dragStartTimeWindow = { start: this.viewStart, end: this.viewEnd };
    });

    window.addEventListener('mousemove', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;

      // Handle dragging
      if (this.isMouseDown) {
        const dx = e.clientX - this.mouseDownX;
        const dy = e.clientY - this.mouseDownY;

        // Intentional drag threshold: 4px
        if (!this.hasDragged && Math.hypot(dx, dy) > 4) {
          this.hasDragged = true;
          this.canvas.style.cursor = 'grabbing';
          this.hideTooltip();
        }

        if (this.hasDragged) {
          const timePerPx = (this.dragStartTimeWindow.end - this.dragStartTimeWindow.start) / rect.width;
          const dTime = dx * timePerPx;

          let newStart = this.dragStartTimeWindow.start - dTime;
          let newEnd = this.dragStartTimeWindow.end - dTime;

          if (newStart < this.minTime) {
            newEnd += (this.minTime - newStart);
            newStart = this.minTime;
          }
          if (newEnd > this.maxTime) {
            newStart -= (newEnd - this.maxTime);
            newEnd = this.maxTime;
          }

          this.viewStart = Math.max(this.minTime, newStart);
          this.viewEnd = Math.min(this.maxTime, newEnd);
          this.render();
          if (this.onWindowChange) this.onWindowChange(this.viewStart, this.viewEnd);
          return;
        }
      }

      // Hover Hit Detection when not dragging
      if (mx >= 0 && mx <= rect.width && my >= 0 && my <= rect.height) {
        this.hoveredMousePos = { x: mx, y: my };
        const found = this.detectHit(mx, my);

        if (found) {
          this.hoveredItem = found;
          this.canvas.style.cursor = 'pointer';
          this.showTooltip(found, e.clientX, e.clientY);
          this.render();
        } else {
          if (this.hoveredItem) {
            this.hoveredItem = null;
            this.canvas.style.cursor = 'grab';
            this.hideTooltip();
            this.render();
          }
        }
      } else {
        if (this.hoveredItem) {
          this.hoveredItem = null;
          this.hoveredMousePos = null;
          this.hideTooltip();
          this.render();
        }
      }
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
      this.canvas.style.cursor = 'grab';
    });

    // Marker Click -> Open Reading Modal
    this.canvas.addEventListener('click', (e) => {
      // If user intentionally dragged the canvas (> 4px), ignore as pan
      if (this.hasDragged) {
        this.hasDragged = false;
        return;
      }

      const rect = this.canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;

      // Detect hit at exact click coordinates, or fallback to hovered item
      const hit = this.detectHit(mx, my) || this.hoveredItem;
      if (hit) {
        this.canvas.focus({ preventScroll: true });
        const targetEvent = hit.isCluster ? hit.events[0] : hit;
        if (this.onEventClick) {
          this.onEventClick(targetEvent);
        } else if (window.openDetailModal) {
          window.openDetailModal(targetEvent);
        }
      }
    });

    // Make tooltip itself clickable too
    if (this.tooltip) {
      this.tooltip.style.cursor = 'pointer';
      this.tooltip.addEventListener('click', () => {
        if (this.hoveredItem) {
          this.canvas.focus({ preventScroll: true });
          const targetEvent = this.hoveredItem.isCluster ? this.hoveredItem.events[0] : this.hoveredItem;
          if (this.onEventClick) {
            this.onEventClick(targetEvent);
          } else if (window.openDetailModal) {
            window.openDetailModal(targetEvent);
          }
        }
      });
    }

    window.addEventListener('resize', () => this.render());
  }

  announceNavigation(message) {
    const status = document.getElementById('navigationStatus');
    if (status) status.textContent = message;
  }

  handleKeyboard(event) {
    if (event.altKey || event.ctrlKey || event.metaKey || this.maxTime <= this.minTime) return;
    const key = event.key;
    const span = this.viewEnd - this.viewStart;
    const total = this.maxTime - this.minTime;
    const visible = this.getFilteredEvents().filter(item => item.timestamp >= this.viewStart && item.timestamp <= this.viewEnd)
      .sort((left, right) => left.timestamp - right.timestamp);
    if (['ArrowUp', 'ArrowDown', 'Enter', ' '].includes(key)) {
      event.preventDefault();
      if (!visible.length) { this.announceNavigation('ไม่พบข่าวในกรอบเวลานี้'); return; }
      let index = visible.findIndex(item => this.selectedEvent && item.id === this.selectedEvent.id);
      if (key === 'ArrowDown') index = Math.min(visible.length - 1, index + 1);
      else if (key === 'ArrowUp') index = index < 0 ? visible.length - 1 : Math.max(0, index - 1);
      else index = Math.max(0, index);
      const selected = visible[index];
      this.setSelectedEvent(selected);
      this.announceNavigation(`ข่าว ${index + 1} จาก ${visible.length}: ${selected.title || ''}`);
      if (key === 'Enter' || key === ' ') {
        if (this.onEventClick) this.onEventClick(selected);
        else if (window.openDetailModal) window.openDetailModal(selected);
      }
      return;
    }

    let nextStart = this.viewStart;
    let nextSpan = span;
    if (key === 'ArrowLeft' || key === 'ArrowRight') nextStart += (key === 'ArrowLeft' ? -1 : 1) * span * (event.shiftKey ? 0.5 : 0.1);
    else if (key === '+' || key === '=' || key === '-' || key === '_') {
      nextSpan = Math.min(total, Math.max(Math.min(2 * 3600 * 1000, total), span * (key === '+' || key === '=' ? 0.8 : 1.25)));
      nextStart += (span - nextSpan) / 2;
    } else if (key === 'Home') nextStart = this.minTime;
    else if (key === 'End') nextStart = this.maxTime - span;
    else return;
    event.preventDefault();
    this.viewStart = Math.max(this.minTime, Math.min(this.maxTime - nextSpan, nextStart));
    this.viewEnd = this.viewStart + nextSpan;
    this.hideTooltip();
    this.render();
    if (this.onWindowChange) this.onWindowChange(this.viewStart, this.viewEnd);
    this.announceNavigation(`กรอบเวลา ${this.formatDateTime(new Date(this.viewStart))} ถึง ${this.formatDateTime(new Date(this.viewEnd))}`);
  }

  detectHit(mx, my) {
    if (!this._renderedNodes || this._renderedNodes.length === 0) return null;

    let closestNode = null;
    let closestDist = Infinity;

    for (let node of this._renderedNodes) {
      const dist = Math.hypot(node.x - mx, node.y - my);
      const hitRadius = node.isCluster ? 24 : 20;

      let isHit = dist <= hitRadius;

      // When labels are enabled, also allow clicking on the headline pill to the right
      if (!isHit && this.showEventLabels) {
        const dx = mx - node.x;
        const dy = Math.abs(my - node.y);
        if (dx >= 0 && dx <= 240 && dy <= 14) {
          isHit = true;
        }
      }

      if (isHit) {
        if (dist < closestDist) {
          closestDist = dist;
          closestNode = node;
        }
      }
    }
    return closestNode;
  }

  formatDateTime(d) {
    const months = ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}, ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')} น.`;
  }

  showTooltip(item, clientX, clientY) {
    if (!this.tooltip) return;

    if (item.isCluster) {
      this.tooltip.innerHTML = `
        <div class="flex items-center gap-2 mb-1.5">
          <span class="text-[11px] font-mono px-2 py-0.5 rounded bg-[#e5a93c]/20 text-[#e5a93c] border border-[#e5a93c]/40 font-semibold flex items-center gap-1">
            <span>●</span> ${escapeNewsHtml(item.count)} ข่าวในช่วงเวลานี้
          </span>
          <span class="text-[11px] font-mono text-slate-400">${this.formatDateTime(new Date(item.timestamp))}</span>
        </div>
        <h4 class="text-[13px] font-bold text-white leading-snug line-clamp-2 mb-2 font-sans">${escapeNewsHtml(item.events[0].title)}</h4>
        <div class="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-[#1c2333]">
          <span class="text-[#e5a93c] font-semibold flex items-center gap-1">
            <span>👆 คลิกอ่านข่าวแรก</span>
          </span>
          <span class="text-slate-500 text-[11px]">หรือซูมดูแยกจุด</span>
        </div>
      `;
    } else {
      const ev = item;
      const cfg = this.categories[ev.category] || this.categories['ธุรกิจ'];
      const realUrl = safeNewsUrl(ev.source_url || ev.source_link || '');
      const sourceName = escapeNewsHtml(ev.source_name || ev.provider || 'ข่าวต้นทาง');
      const hasRealUrl = Boolean(realUrl);

      this.tooltip.innerHTML = `
        <div class="flex items-center gap-2 mb-1.5">
          <span class="text-[11px] font-semibold px-2 py-0.5 rounded flex items-center gap-1" style="background-color: ${cfg.tint}; color: ${cfg.color}; border: 1px solid ${cfg.border}">
            <span>${cfg.icon}</span> <span>${escapeNewsHtml(ev.category)}</span>
          </span>
          <span class="text-[11px] font-mono text-slate-400 ml-auto">${this.formatDateTime(new Date(ev.timestamp))}</span>
        </div>
        <h4 class="text-[13px] font-bold text-white leading-snug line-clamp-2 mb-2 font-sans">${escapeNewsHtml(ev.title)}</h4>
        <div class="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-[#1c2333]">
          <span class="font-mono text-slate-300 flex items-center gap-1">
            <span>แหล่ง:</span>
            <span class="text-[#e5a93c] font-medium">${sourceName}</span>
            ${hasRealUrl ? '<span class="text-[9px]">↗</span>' : ''}
          </span>
          <span class="text-[#e5a93c] font-semibold flex items-center gap-1">
            <span>👆 คลิกอ่านข่าวเต็ม</span>
          </span>
        </div>
      `;
    }

    const containerRect = this.container.getBoundingClientRect();
    let left = clientX - containerRect.left + 15;
    let top = clientY - containerRect.top - 20;

    if (left + 330 > containerRect.width) left = left - 350;
    left = Math.max(8, Math.min(left, Math.max(8, containerRect.width - 338)));
    if (top + 150 > containerRect.height) top = containerRect.height - 160;
    if (top < 10) top = 10;

    this.tooltip.style.left = `${left}px`;
    this.tooltip.style.top = `${top}px`;
    this.tooltip.classList.remove('hidden');
  }

  hideTooltip() {
    if (this.tooltip) this.tooltip.classList.add('hidden');
  }

  timeToX(t, w) {
    return ((t - this.viewStart) / (this.viewEnd - this.viewStart)) * w;
  }

  render() {
    // Enforce at least 2x DPR for ultra-crisp vector and text rendering across all monitors
    const dpr = Math.max(window.devicePixelRatio || 1, 2);
    const w = this.canvas.clientWidth;
    const h = this.canvas.clientHeight;

    if (this.canvas.width !== Math.round(w * dpr) || this.canvas.height !== Math.round(h * dpr)) {
      this.canvas.width = Math.round(w * dpr);
      this.canvas.height = Math.round(h * dpr);
    }

    const ctx = this.ctx;
    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, w, h);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.textBaseline = 'middle';

    const headerH = 36;
    const laneH = (h - headerH) / this.categoryNames.length;
    const viewDuration = this.viewEnd - this.viewStart;

    // 1. Time Axis Header Background
    ctx.fillStyle = '#0d111a';
    ctx.fillRect(0, 0, w, headerH);
    ctx.strokeStyle = '#1a2232';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, headerH);
    ctx.lineTo(w, headerH);
    ctx.stroke();

    // 2. Dynamic Time Ticks & Grid Lines (Soft subtle hairline)
    let tickInterval = 24 * 3600 * 1000;
    if (viewDuration <= 36 * 3600 * 1000) tickInterval = 4 * 3600 * 1000;
    else if (viewDuration <= 96 * 3600 * 1000) tickInterval = 12 * 3600 * 1000;
    else if (viewDuration > 14 * 24 * 3600 * 1000) tickInterval = 3 * 24 * 3600 * 1000;

    const firstTick = Math.floor(this.viewStart / tickInterval) * tickInterval;
    for (let t = firstTick; t <= this.viewEnd + tickInterval; t += tickInterval) {
      const x = this.timeToX(t, w);
      if (x < -50 || x > w + 50) continue;

      ctx.strokeStyle = '#151b27';
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 4]);
      ctx.beginPath();
      ctx.moveTo(x, headerH);
      ctx.lineTo(x, h);
      ctx.stroke();
      ctx.setLineDash([]);

      const d = new Date(t);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '500 12px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';

      let label = `${d.getDate()} ${['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'][d.getMonth()]}`;
      if (tickInterval < 24 * 3600 * 1000) {
        label = `${String(d.getHours()).padStart(2, '0')}:00`;
      }
      ctx.fillText(label, x, headerH / 2);
    }

    // 3. Draw 5 Category Swimlanes (Subtle background shift, no clutter)
    this.categoryNames.forEach((cat, idx) => {
      const yTop = headerH + idx * laneH;
      const cfg = this.categories[cat];
      const isCatActive = this.activeCategories.has(cat);

      // Alternating deep dark surfaces
      ctx.fillStyle = !isCatActive
        ? 'rgba(9, 12, 18, 0.95)'
        : (idx % 2 === 0 ? 'rgba(14, 18, 27, 0.45)' : 'rgba(11, 14, 21, 0.65)');
      ctx.fillRect(0, yTop, w, laneH);

      // Delicate lane divider
      ctx.strokeStyle = '#161d2a';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, yTop + laneH);
      ctx.lineTo(w, yTop + laneH);
      ctx.stroke();

      // Compact, elegant category badge on left margin (Prompt crisp font)
      ctx.fillStyle = isCatActive ? 'rgba(18, 24, 35, 0.92)' : 'rgba(15, 18, 24, 0.5)';
      ctx.beginPath();
      ctx.roundRect(12, yTop + 7, 94, 24, 5);
      ctx.fill();
      ctx.strokeStyle = isCatActive ? cfg.border : 'rgba(35, 43, 56, 0.5)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = isCatActive ? cfg.color : '#94a3b8';
      ctx.font = '600 12.5px "Prompt", "IBM Plex Sans Thai", sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(
        isCatActive ? `${cfg.icon} ${cat}` : `${cfg.icon} ${cat} (ปิด)`,
        18,
        yTop + 19
      );
    });

    // 4. Market Price Benchmark Overlay (Soft gold hairline + subtle area gradient in background)
    if (this.showPriceOverlay && this.priceCandles && this.priceCandles.length > 0) {
      this.renderPriceCurve(ctx, w, h, headerH);
    }

    // 5. Draw Clustered Event Markers (CLEAN, NO PERMANENT STEMS, NO INLINE TEXT CLUTTER)
    const filteredEvents = this.getFilteredEvents();
    this._renderedNodes = [];

    const laneEvents = {};
    this.categoryNames.forEach(c => laneEvents[c] = []);

    filteredEvents.forEach(ev => {
      if (ev.timestamp >= this.viewStart - (viewDuration * 0.05) && ev.timestamp <= this.viewEnd + (viewDuration * 0.05)) {
        if (laneEvents[ev.category]) laneEvents[ev.category].push(ev);
      }
    });

    const CLUSTER_DISTANCE = 24; // Clustering distance threshold

    this.categoryNames.forEach((cat, catIdx) => {
      if (!this.activeCategories.has(cat)) return;

      const laneY = headerH + catIdx * laneH;
      const cfg = this.categories[cat];
      const evs = laneEvents[cat];
      if (evs.length === 0) return;

      // Group close events into clusters
      const clusters = [];
      let currentCluster = null;

      evs.forEach(ev => {
        const x = this.timeToX(ev.timestamp, w);
        if (!currentCluster) {
          currentCluster = { x, events: [ev] };
        } else {
          if (Math.abs(x - currentCluster.x) < CLUSTER_DISTANCE) {
            currentCluster.events.push(ev);
          } else {
            clusters.push(currentCluster);
            currentCluster = { x, events: [ev] };
          }
        }
      });
      if (currentCluster) clusters.push(currentCluster);

      // Render markers cleanly
      clusters.forEach((cl, i) => {
        const isCluster = cl.events.length > 1;
        const count = cl.events.length;
        const x = cl.x;
        // Position neatly within the lane
        const y = laneY + 23 + (i % 2) * 20;

        const isHovered = this.hoveredItem && (
          (this.hoveredItem.isCluster && this.hoveredItem.x === x) ||
          (!this.hoveredItem.isCluster && cl.events.some(e => e.id === this.hoveredItem.id))
        );

        const isSelected = this.selectedEvent && cl.events.some(e => e.id === this.selectedEvent.id);

        const nodeRecord = isCluster 
          ? { isCluster: true, count, events: cl.events, x, y, timestamp: cl.events[0].timestamp, category: cat }
          : Object.assign({}, cl.events[0], { isCluster: false, x, y });
        this._renderedNodes.push(nodeRecord);

        // ONLY draw vertical guideline if hovered or selected (removes the barcode clutter!)
        if (isHovered || isSelected) {
          ctx.strokeStyle = '#e5a93c';
          ctx.lineWidth = 1;
          ctx.setLineDash([3, 3]);
          ctx.beginPath();
          ctx.moveTo(x, headerH);
          ctx.lineTo(x, h);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        if (isCluster) {
          // Cluster Badge [N]
          if (isSelected) {
            ctx.fillStyle = 'rgba(229, 169, 60, 0.25)';
            ctx.beginPath();
            ctx.roundRect(x - 16, y - 12, 32, 24, 5);
            ctx.fill();
            ctx.strokeStyle = '#e5a93c';
            ctx.lineWidth = 1.5;
            ctx.stroke();
          }

          // Badge pill
          ctx.fillStyle = isHovered ? '#e5a93c' : (isSelected ? '#e5a93c' : '#141a26');
          ctx.beginPath();
          ctx.roundRect(x - 12, y - 9, 24, 18, 4);
          ctx.fill();

          ctx.strokeStyle = isHovered || isSelected ? '#ffffff' : cfg.border;
          ctx.lineWidth = 1.25;
          ctx.stroke();

          ctx.fillStyle = isHovered || isSelected ? '#0b0e14' : cfg.color;
          ctx.font = 'bold 11px "JetBrains Mono", monospace';
          ctx.textAlign = 'center';
          ctx.fillText(String(count), x, y);

          // Optional News Headline Label for Cluster (Sharp Prompt typography)
          if (this.showEventLabels && cl.events.length > 0) {
            const leadTitle = cl.events[0].title || '';
            const clusterSnippet = leadTitle.length > 26 ? leadTitle.substring(0, 25) + '…' : leadTitle;

            ctx.font = isHovered || isSelected ? '600 13px "Prompt", "IBM Plex Sans Thai", sans-serif' : '500 12px "Prompt", "IBM Plex Sans Thai", sans-serif';
            const textWidth = ctx.measureText(clusterSnippet).width;

            ctx.fillStyle = isHovered || isSelected ? 'rgba(20, 26, 38, 0.98)' : 'rgba(13, 17, 24, 0.95)';
            ctx.beginPath();
            ctx.roundRect(x + 16, y - 11, textWidth + 14, 22, 5);
            ctx.fill();
            ctx.strokeStyle = isHovered || isSelected ? '#e5a93c' : 'rgba(255, 255, 255, 0.22)';
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.fillStyle = isHovered || isSelected ? '#ffffff' : '#f8fafc';
            ctx.textAlign = 'left';
            ctx.fillText(clusterSnippet, x + 23, y);
          }
        } else {
          const ev = cl.events[0];

          // Single Event Marker (Clean Luminous Dot)
          if (isSelected) {
            ctx.fillStyle = 'rgba(229, 169, 60, 0.25)';
            ctx.beginPath();
            ctx.arc(x, y, 14, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#e5a93c';
            ctx.lineWidth = 1.5;
            ctx.stroke();
          }

          if (isHovered && !isSelected) {
            ctx.fillStyle = 'rgba(229, 169, 60, 0.25)';
            ctx.beginPath();
            ctx.arc(x, y, 12, 0, Math.PI * 2);
            ctx.fill();
          }

          // Center Event Circle
          ctx.fillStyle = isHovered || isSelected ? '#e5a93c' : cfg.color;
          ctx.beginPath();
          ctx.arc(x, y, isHovered || isSelected ? 6.5 : 5, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = '#0b0e14';
          ctx.lineWidth = 1.5;
          ctx.stroke();

          // Optional News Headline Label for Single Event (Sharp Prompt typography)
          if (this.showEventLabels) {
            const rawTitle = ev.title || '';
            const titleSnippet = rawTitle.length > 28 ? rawTitle.substring(0, 26) + '…' : rawTitle;

            ctx.font = isHovered || isSelected ? '600 13px "Prompt", "IBM Plex Sans Thai", sans-serif' : '500 12px "Prompt", "IBM Plex Sans Thai", sans-serif';
            const textWidth = ctx.measureText(titleSnippet).width;

            ctx.fillStyle = isHovered || isSelected ? 'rgba(20, 26, 38, 0.98)' : 'rgba(13, 17, 24, 0.95)';
            ctx.beginPath();
            ctx.roundRect(x + 10, y - 11, textWidth + 14, 22, 5);
            ctx.fill();
            ctx.strokeStyle = isHovered || isSelected ? '#e5a93c' : 'rgba(255, 255, 255, 0.22)';
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.fillStyle = isHovered || isSelected ? '#ffffff' : '#f8fafc';
            ctx.textAlign = 'left';
            ctx.fillText(titleSnippet, x + 17, y);
          }
        }
      });
    });

    ctx.restore();
  }

  renderPriceCurve(ctx, w, h, headerH) {
    const candlesInView = this.priceCandles.filter(c => 
      c.time >= this.viewStart - 3600000 && c.time <= this.viewEnd + 3600000
    );
    if (candlesInView.length < 2) return;

    let minPrice = Infinity;
    let maxPrice = -Infinity;
    candlesInView.forEach(c => {
      if (c.close < minPrice) minPrice = c.close;
      if (c.close > maxPrice) maxPrice = c.close;
    });

    const pricePadding = (maxPrice - minPrice) * 0.15 || 100;
    minPrice -= pricePadding;
    maxPrice += pricePadding;

    const priceToY = (p) => {
      return (h - 18) - ((p - minPrice) / (maxPrice - minPrice)) * (h - headerH - 32);
    };

    // 1. Soft Area Gradient Under Price Line (Subtle Depth)
    const firstX = this.timeToX(candlesInView[0].time, w);
    const lastX = this.timeToX(candlesInView[candlesInView.length - 1].time, w);

    ctx.beginPath();
    ctx.moveTo(firstX, h);
    candlesInView.forEach((c) => {
      ctx.lineTo(this.timeToX(c.time, w), priceToY(c.close));
    });
    ctx.lineTo(lastX, h);
    ctx.closePath();

    const areaGrad = ctx.createLinearGradient(0, headerH, 0, h);
    areaGrad.addColorStop(0, 'rgba(229, 169, 60, 0.05)');
    areaGrad.addColorStop(1, 'rgba(229, 169, 60, 0.00)');
    ctx.fillStyle = areaGrad;
    ctx.fill();

    // 2. Refined Gold Hairline
    ctx.beginPath();
    candlesInView.forEach((c, idx) => {
      const x = this.timeToX(c.time, w);
      const y = priceToY(c.close);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });

    ctx.strokeStyle = 'rgba(229, 169, 60, 0.7)';
    ctx.lineWidth = 1.25;
    ctx.stroke();

    // 3. Right-edge Benchmark Price Badge (Subtle Dark Pill)
    const lastCandle = candlesInView[candlesInView.length - 1];
    const badgeX = Math.min(w - 78, this.timeToX(lastCandle.time, w) + 6);
    const badgeY = Math.max(headerH + 18, Math.min(h - 18, priceToY(lastCandle.close)));

    ctx.fillStyle = 'rgba(16, 21, 31, 0.95)';
    ctx.beginPath();
    ctx.roundRect(badgeX, badgeY - 11, 74, 22, 5);
    ctx.fill();
    ctx.strokeStyle = 'rgba(229, 169, 60, 0.6)';
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = '#e5a93c';
    ctx.font = 'bold 11px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`$${Math.round(lastCandle.close).toLocaleString()}`, badgeX + 37, badgeY);
  }
}
