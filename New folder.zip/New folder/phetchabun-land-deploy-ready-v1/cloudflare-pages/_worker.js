// Cloudflare Pages Advanced Mode Worker for Phetchabun Land
// Persistent storage via Cloudflare KV (env.DB)

const INITIAL_PROPERTIES = [
  {
    id: 'LAN-MUANG-35R',
    title: 'ที่ดิน 35 ไร่ ติดถนนสระบุรี-หล่มสัก (กม.21)',
    district: 'เมืองเพชรบูรณ์',
    purpose: 'เพื่อการลงทุน',
    rai: 35,
    ngan: 0,
    wah: 0,
    price: 112000000,
    road: 'ถนนสระบุรี-หล่มสัก (กม.21) หน้ากว้าง 6 เสาไฟฟ้า',
    features: 'ติดถนนใหญ่สายหลัก เชื่อมต่อไปศูนย์ราชการเพชรบูรณ์ เหมาะโครงการพาณิชย์และจัดสรร',
    palette: 0,
    latitude: 16.432,
    longitude: 101.156,
    cover_url: ''
  },
  {
    id: 'LAN-SADIANG-111W',
    title: 'ที่ดิน 111 ตร.ว. ต.สะเดียง ในเขตเทศบาลเมืองเพชรบูรณ์',
    district: 'เมืองเพชรบูรณ์',
    purpose: 'เพื่ออยู่อาศัย',
    rai: 0,
    ngan: 1,
    wah: 11,
    price: 1850000,
    road: 'ซอยเพชรพิสุทธิ์ ตรงข้ามประตูหลัง กศน. เข้าซอยเพียง 10 ม.',
    features: 'อยู่ในเขตชุมชน ไฟฟ้า ประปาเข้าถึง เหมาะสร้างบ้านพักอาศัยหรือหอพัก',
    palette: 1,
    latitude: 16.419,
    longitude: 101.148,
    cover_url: ''
  },
  {
    id: 'LAN-THAPHON-2R',
    title: 'ที่ดินติดถนนสระบุรี-หล่มสัก บ้านแดง 2 ไร่ หน้ากว้าง 40 ม.',
    district: 'เมืองเพชรบูรณ์',
    purpose: 'เพื่อการพาณิชย์',
    rai: 2,
    ngan: 0,
    wah: 0,
    price: 8500000,
    road: 'ถนนสระบุรี-หล่มสัก หน้ากว้าง 40 เมตร ก่อนถึงตลาดท่าพล 1 กม.',
    features: 'ติดถนนใหญ่ 4 ช่องจราจร ทำเลค้าขาย ปั๊มน้ำมัน โชว์รูม คลังสินค้า',
    palette: 2,
    latitude: 16.521,
    longitude: 101.162,
    cover_url: ''
  },
  {
    id: 'LAN-KHAOKHO-3R',
    title: 'ที่ดินแปลงสวยวิวทะเลหมอกเขาค้อ 3 ไร่ 2 งาน 50 ตร.ว.',
    district: 'เขาค้อ',
    purpose: 'เพื่อการท่องเที่ยว',
    rai: 3,
    ngan: 2,
    wah: 50,
    price: 14500000,
    road: 'ถนนทางหลวงชนบทสาย 2196 วิวทิวทัศน์ 360 องศา',
    features: 'วิวภูเขาสลับซับซ้อน อากาศเย็นสบายตลอดปี เหมาะทำรีสอร์ท คาเฟ่ บ้านพักตากอากาศ',
    palette: 3,
    latitude: 16.634,
    longitude: 101.002,
    cover_url: ''
  },
  {
    id: 'LAN-LOMKAO-5R',
    title: 'ที่ดินเพื่อการเกษตรและพักผ่อน 5 ไร่เศษ ต.หล่มเก่า',
    district: 'หล่มเก่า',
    purpose: 'เพื่อเกษตรกรรม',
    rai: 5,
    ngan: 1,
    wah: 20,
    price: 3200000,
    road: 'ถนนคอนกรีตเชื่อมหมู่บ้าน มีทางน้ำเพื่อการเกษตร',
    features: 'ดินอุดมสมบูรณ์ ใกล้เส้นทางขึ้นภูทับเบิก มองเห็นทิวเขา เหมาะทำสวนเกษตรผสมผสาน',
    palette: 4,
    latitude: 16.815,
    longitude: 101.228,
    cover_url: ''
  },
  {
    id: 'LAN-LOMSAK-8R',
    title: 'ที่ดินทำเลศักยภาพ ใกล้สี่แยกพ่อขุนผาเมือง หล่มสัก 8 ไร่',
    district: 'หล่มสัก',
    purpose: 'เพื่อการลงทุน',
    rai: 8,
    ngan: 0,
    wah: 0,
    price: 24000000,
    road: 'ถนนบายพาสหล่มสัก ทางหลวงหมายเลข 21 เชื่อมต่อ 12',
    features: 'จุดยุทธศาสตร์การเดินทางภาคเหนือตอนล่างและภาคอีสาน เหมาะสร้างโกดังหรือจุดกระจายสินค้า',
    palette: 5,
    latitude: 16.772,
    longitude: 101.241,
    cover_url: ''
  }
];

function randomHex(length) {
  const bytes = new Uint8Array(Math.ceil(length / 2));
  crypto.getRandomValues(bytes);
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('').slice(0, length).toUpperCase();
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    }
  });
}

// KV Helpers
async function getKV(env, key, defaultVal = null) {
  if (!env || !env.DB) return defaultVal;
  try {
    const val = await env.DB.get(key, 'json');
    return val !== null ? val : defaultVal;
  } catch {
    return defaultVal;
  }
}

async function putKV(env, key, value) {
  if (!env || !env.DB) return;
  try {
    await env.DB.put(key, JSON.stringify(value));
  } catch (err) {
    console.error('KV Put Error:', err);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type'
        }
      });
    }

    if (url.pathname.startsWith('/api/')) {
      const endpoint = url.pathname.slice(5);

      if (endpoint === 'health' || endpoint === 'status') {
        return jsonResponse({
          status: 'ok',
          service: 'Phetchabun Land Portal',
          platform: 'Cloudflare Pages with KV Storage',
          kv_active: !!env.DB,
          asof: new Date().toISOString()
        });
      }

      let payload = {};
      if (request.method === 'POST') {
        try {
          payload = await request.json();
        } catch {
          payload = {};
        }
      }

      // 1. getPublishedListings
      if (endpoint === 'getPublishedListings') {
        let listings = await getKV(env, 'listings:list', null);
        if (!listings || listings.length === 0) {
          listings = INITIAL_PROPERTIES;
          await putKV(env, 'listings:list', listings);
        }
        return jsonResponse({ result: listings });
      }

      // 2. submitInquiry (Lead)
      if (endpoint === 'submitInquiry') {
        const leadId = 'LEAD-' + randomHex(12);
        const record = {
          lead_id: leadId,
          property_id: payload.propertyId || '',
          customer_name: payload.customerName || 'ผู้สนใจ',
          customer_phone: payload.customerPhone || '',
          note: payload.note || '',
          lead_status: 'new',
          submitted_at: new Date().toISOString()
        };

        const leads = await getKV(env, 'leads:list', []);
        leads.unshift(record);
        await putKV(env, 'leads:list', leads);
        await putKV(env, 'lead:' + leadId, record);

        return jsonResponse({
          result: {
            ok: true,
            lead_id: leadId
          }
        });
      }

      // 3. submitConsignment (ฝากขายที่ดิน)
      if (endpoint === 'submitConsignment') {
        const consignmentId = 'CON-' + randomHex(12);
        const trackingCode = randomHex(32);
        const record = {
          consignment_id: consignmentId,
          tracking_code: trackingCode,
          seller_name: payload.sellerName || '',
          seller_phone: payload.sellerPhone || '',
          seller_role: payload.sellerRole || 'owner',
          district: payload.district || 'เมืองเพชรบูรณ์',
          asking_price_thb: Number(payload.askingPriceThb) || 0,
          area_sq_wah: Number(payload.areaSqWah) || 0,
          desired_agreement_type: payload.desiredAgreementType || 'exclusive',
          proposed_commission_pct: Number(payload.proposedCommissionPct) || 3,
          title_deed_type: payload.titleDeedType || 'chanote',
          status: 'submitted',
          verification_status: 'reviewing',
          submitted_at: new Date().toISOString()
        };

        const consignments = await getKV(env, 'consignments:list', []);
        consignments.unshift(record);
        await putKV(env, 'consignments:list', consignments);
        await putKV(env, 'consignment:' + consignmentId, record);
        await putKV(env, 'tracking:' + trackingCode, consignmentId);

        return jsonResponse({
          result: {
            ok: true,
            consignment_id: consignmentId,
            tracking_code: trackingCode
          }
        });
      }

      // 4. getConsignmentStatus (ติดตามสถานะ)
      if (endpoint === 'getConsignmentStatus') {
        const id = String(payload.consignmentId || '').trim();
        const code = String(payload.trackingCode || '').trim().toUpperCase();

        let found = null;
        if (id) found = await getKV(env, 'consignment:' + id, null);
        if (!found && code) {
          const targetId = await getKV(env, 'tracking:' + code, null);
          if (targetId) found = await getKV(env, 'consignment:' + targetId, null);
        }

        if (found) {
          return jsonResponse({
            result: {
              consignment_id: found.consignment_id,
              status: found.status || 'submitted',
              verification_status: found.verification_status || 'reviewing',
              property_id: found.property_id || '',
              checked_at: new Date().toISOString()
            }
          });
        }

        return jsonResponse({
          result: {
            consignment_id: id || ('CON-' + randomHex(12)),
            status: 'submitted',
            verification_status: 'reviewing',
            property_id: '',
            checked_at: new Date().toISOString()
          }
        });
      }

      // 5. adminBootstrap (โหลดข้อมูลหน้าเจ้าหน้าที่)
      if (endpoint === 'adminBootstrap') {
        const consignments = await getKV(env, 'consignments:list', []);
        const leads = await getKV(env, 'leads:list', []);
        let listings = await getKV(env, 'listings:list', null);
        if (!listings || listings.length === 0) {
          listings = INITIAL_PROPERTIES;
          await putKV(env, 'listings:list', listings);
        }

        const listingsRows = listings.map(p => ({
          property_id: p.id,
          title: p.title,
          district: p.district,
          price_thb: p.price,
          status: 'published',
          published_at: '2026-11-15'
        }));

        const agreements = await getKV(env, 'agreements:list', []);
        const deals = await getKV(env, 'deals:list', []);
        const splitRules = await getKV(env, 'split_rules:list', []);
        const payouts = await getKV(env, 'payouts:list', []);
        const collections = await getKV(env, 'collections:list', []);
        let agents = await getKV(env, 'agents:list', null);
        if (!agents || agents.length === 0) {
          agents = [
            { agent_id: 'AGT-001', name: 'Ratchapon (Jib) Ban Rimdoy', role: 'listing_agent', status: 'active' },
            { agent_id: 'AGT-002', name: 'Phetchabun Land Central', role: 'company', status: 'active' }
          ];
          await putKV(env, 'agents:list', agents);
        }

        const rows = {
          Consignments: consignments,
          Agreements: agreements,
          Listings: listingsRows,
          Leads: leads,
          Deals: deals,
          SplitRules: splitRules,
          Payouts: payouts,
          Collections: collections,
          Agents: agents
        };

        const sections = ['Consignments', 'Agreements', 'Listings', 'Leads', 'Deals', 'SplitRules', 'Payouts', 'Collections', 'Agents'];
        const counts = Object.fromEntries(sections.map(s => [s, (rows[s] || []).length]));

        return jsonResponse({
          result: {
            email: 'openclaw-bot@phetchabun-land.internal',
            counts,
            rows,
            asof: new Date().toISOString()
          }
        });
      }

      // 6. admin mutations
      if (endpoint === 'reviewConsignment') {
        const { consignmentId, decision, note } = payload;
        const consignments = await getKV(env, 'consignments:list', []);
        const item = consignments.find(c => c.consignment_id === consignmentId);
        if (item) {
          item.verification_status = decision === 'approve' ? 'verified' : (decision === 'reject' ? 'rejected' : 'reviewing');
          item.status = decision === 'approve' ? 'approved' : (decision === 'reject' ? 'rejected' : 'reviewing');
          if (note) item.notes_private = note;
          await putKV(env, 'consignments:list', consignments);
          await putKV(env, 'consignment:' + consignmentId, item);
        }
        return jsonResponse({ result: { ok: true, consignment_id: consignmentId } });
      }

      return jsonResponse({
        result: { ok: true, asof: new Date().toISOString() }
      });
    }

    // Static asset fetch
    return env.ASSETS.fetch(request);
  }
};
