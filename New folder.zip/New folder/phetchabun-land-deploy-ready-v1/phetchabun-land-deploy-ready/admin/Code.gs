/**
 * PHETCHABUN LAND — RESTRICTED ADMIN APPS SCRIPT WEB APP
 * DEPLOY IN A DIFFERENT SCRIPT PROJECT from /public.
 * Execute as: USER ACCESSING THE WEB APP; Access: signed-in users.
 * Script property ADMIN_EMAILS = comma-separated email allowlist.
 * Each authorized user must have edit access to the RESTRICTED spreadsheet.
 * Security: EVERY callable server action starts with adminAuth_().
 * Forms / contract/PDF workflow: staff-verified; NOT an electronic-signature service.
 */
const ADM_SHEET_ID = '1idxj5laI7Y4bdhTdDvpD63ernjRaEP34CitpOi8mFgo';
const ADM_TABLES=['Listings','Locations','Images','Sellers','Consignments','Agreements','Agents','Leads','Deals','SplitRules','Payouts','Collections','PriceHistory','DocumentIndex','AuditLog'];
const ADM_DISTRICTS=['เมืองเพชรบูรณ์','ชนแดน','หล่มสัก','หล่มเก่า','วิเชียรบุรี','ศรีเทพ','หนองไผ่','บึงสามพัน','น้ำหนาว','วังโป่ง','เขาค้อ'];

function doGet(){
  return HtmlService.createHtmlOutputFromFile('Admin')
    .setTitle('Phetchabun Land | Private Operations');
}
function adminAuth_(){
  const email=String(Session.getActiveUser().getEmail()||'').trim().toLowerCase();
  const allowed=String(PropertiesService.getScriptProperties().getProperty('ADMIN_EMAILS')||'')
    .split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);
  if(!email||!allowed.includes(email))throw new Error('ไม่ได้รับสิทธิ์ผู้ดูแล: กรุณาตรวจสอบบัญชี Google และ ADMIN_EMAILS');
  const file=DriveApp.getFileById(ADM_SHEET_ID);
  if(file.getSharingAccess()!==DriveApp.Access.PRIVATE)
    throw new Error('SECURITY BLOCK: Google Sheet ต้องตั้งค่า General access เป็น Restricted ก่อน');
  return email;
}
function admSheet_(name){
  if(!ADM_TABLES.includes(name))throw new Error('Invalid table');
  const sh=SpreadsheetApp.openById(ADM_SHEET_ID).getSheetByName(name);
  if(!sh)throw new Error('Missing database table: '+name);
  return sh;
}
function admHeader_(name){return admSheet_(name).getRange(1,1,1,admSheet_(name).getLastColumn()).getValues()[0].map(String);}
function admSafe_(v){return v instanceof Date ? Utilities.formatDate(v,'Asia/Bangkok',"yyyy-MM-dd'T'HH:mm:ss") : v;}
function admAll_(name,maxRows){
  const sh=admSheet_(name),last=sh.getLastRow();if(last<2)return [];
  const max=maxRows||5000;
  if(last-1>max)throw new Error('Table too large for spreadsheet MVP: '+name);
  const grid=sh.getRange(1,1,last,sh.getLastColumn()).getValues(),hdr=grid.shift().map(String);
  return grid.map((row,index)=>{
    const o={_row:index+2};hdr.forEach((h,i)=>{if(h)o[h]=admSafe_(row[i]);});return o;
  }).filter(o=>hdr.some(h=>o[h]!==''&&o[h]!==null));
}
function admFind_(name,key,id){
  const found=admAll_(name).find(x=>String(x[key])===String(id));
  if(!found)throw new Error('ไม่พบ '+name+': '+id);
  return found;
}
function admWrite_(name,row,updates){
  const sh=admSheet_(name),hdr=admHeader_(name);
  Object.keys(updates).forEach(k=>{
    const index=hdr.indexOf(k);
    if(index<0)throw new Error('Missing column '+name+'.'+k);
    sh.getRange(row,index+1).setValue(updates[k]);
  });
}
function admAppend_(name,data){
  const sh=admSheet_(name),header=admHeader_(name);
  Object.keys(data).forEach(k=>{if(!header.includes(k))throw new Error('Missing '+name+'.'+k);});
  sh.appendRow(header.map(h=>data[h]===undefined?'':data[h]));
}
function admId_(prefix){return prefix+'-'+Utilities.getUuid().replace(/-/g,'').slice(0,12).toUpperCase();}
function admText_(v,max,needed){
  const s=String(v==null?'':v).trim();
  if((needed&&!s)||s.length>max||/^[=+@-]/.test(s)||/[\x00-\x1F\x7F]/.test(s))throw new Error('ข้อมูลข้อความไม่ถูกต้อง');
  return s;
}
function admNum_(v,min,max){
  if(v===''||v==null)throw new Error('กรอกตัวเลขให้ครบ');
  const n=Number(v);if(!Number.isFinite(n)||n<min||n>max)throw new Error('ตัวเลขไม่ถูกต้อง');return n;
}
function admDate_(str){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(String(str)))throw new Error('ใช้วันที่ YYYY-MM-DD');
  const d=new Date(String(str)+'T12:00:00+07:00');
  if(!Number.isFinite(d.getTime())||Utilities.formatDate(d,'Asia/Bangkok','yyyy-MM-dd')!==str)throw new Error('วันที่ไม่ถูกต้อง');
  return d;
}
function admLocked_(fn){
  const lock=LockService.getScriptLock();if(!lock.tryLock(20000))throw new Error('กำลังมีผู้แก้ไขข้อมูล กรุณาลองใหม่');
  try{return fn();}finally{lock.releaseLock();}
}
function admLog_(actor,action,entity,id,before,after){
  const json=x=>JSON.stringify(x||{}).slice(0,3500);
  admAppend_('AuditLog',{event_id:admId_('EVT'),occurred_at:new Date(),actor_id:actor,
    action,entity_type:entity,entity_id:id,before_json:json(before),after_json:json(after),source:'admin-web'});
}
function admDocId_(urlOrId){
  const s=String(urlOrId||'').trim();
  const m=s.match(/\/d\/([A-Za-z0-9_-]{15,})/);
  const id=m?m[1]:s;
  if(!/^[A-Za-z0-9_-]{15,}$/.test(id))throw new Error('Google Drive file ID ไม่ถูกต้อง');
  return id;
}
function admPrivateFile_(id,isPdf){
  const file=DriveApp.getFileById(admDocId_(id));
  if(file.getSharingAccess()!==DriveApp.Access.PRIVATE)throw new Error('เอกสารต้องตั้ง Share → Restricted ก่อน');
  if(isPdf&&file.getMimeType()!=='application/pdf')throw new Error('เอกสารลงนามต้องเป็นไฟล์ PDF');
  return file;
}
function admHash_(file){
  if(file.getSize()>15*1024*1024)throw new Error('ไฟล์หลักฐานใหญ่เกิน 15MB');
  const bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,file.getBlob().getBytes());
  return bytes.map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');
}
function admEnsureAgreement_(conId){
  const con=admFind_('Consignments','consignment_id',conId);
  if(con.verification_status!=='verified')throw new Error('คำขอฝากขายยังไม่ผ่านการตรวจสอบ');
  const matches=admAll_('Agreements').filter(a=>a.consignment_id===conId&&a.status==='active'&&a.signature_status==='signed');
  if(matches.length!==1)throw new Error('ต้องมีสัญญา signed/active ที่ตรวจสอบแล้ว 1 ฉบับ');
  const a=matches[0];
  if(a.expires_at && (new Date(a.expires_at).getTime()+86400000)<Date.now())throw new Error('สัญญาหมดอายุ');
  return{con,a};
}
function admCommission_(a,closed){
  if(a.commission_type==='fixed')return Math.round(admNum_(a.commission_fixed_thb,0,1e12)*100)/100;
  return Math.round(closed*admNum_(a.commission_rate_pct,0,100))/100;
}

/** List and overview. Dates are returned as strings for google.script.run serialization. */
function adminBootstrap(){
  const email=adminAuth_();
  const sections=['Consignments','Agreements','Listings','Leads','Deals','SplitRules','Payouts','Collections','Agents'];
  const counts=Object.fromEntries(sections.map(x=>[x,admAll_(x).length]));
  const rows={};
  for(const name of sections)rows[name]=admAll_(name,1200).slice(-300);
  return{email,counts,rows,asof:new Date().toISOString()};
}
function adminList(name){
  adminAuth_();
  if(!ADM_TABLES.includes(name))throw new Error('Invalid table');
  return admAll_(name,3000).slice(-500);
}
function adminCreateAgent(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const id=admId_('AGT'),name=admText_(f.name,120,true),role=admText_(f.role,50,true);
    if(!['listing_agent','buyer_agent','referral','company','other'].includes(role))throw new Error('role ไม่รองรับ');
    const phone=admText_(f.phone||'',30,false),email=admText_(f.email||'',150,false);
    admAppend_('Agents',{agent_id:id,name,role,phone,email,status:'active',created_at:new Date()});
    admLog_(actor,'create_agent','Agents',id,null,{role});return{id};
  });
}
function adminReviewConsignment(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const con=admFind_('Consignments','consignment_id',f.consignmentId);
    if(!['submitted','reviewing','approved'].includes(con.status))throw new Error('สถานะคำขอไม่เปิดให้ตรวจสอบ');
    if(admAll_('Agreements').some(a=>a.consignment_id===con.consignment_id&&['draft','active'].includes(a.status)))
      throw new Error('คำขอนี้มีสัญญาแล้ว ไม่อนุญาตให้แก้ไขผลตรวจย้อนหลัง');
    const decision=String(f.decision||'');
    if(!['reviewing','approve','reject'].includes(decision))throw new Error('ผลตรวจไม่ถูกต้อง');
    if(decision==='approve'&&f.confirmed!==true)throw new Error('ต้องยืนยันการตรวจสอบเจ้าของ/เอกสารสิทธิจริง');
    const note=admText_(f.note||'',900,false);
    const next=decision==='approve'?'approved':decision==='reject'?'rejected':'reviewing';
    const verify=decision==='approve'?'verified':decision==='reject'?'rejected':'in_review';
    const updates={status:next,verification_status:verify,verified_by:actor,verified_at:new Date(),notes_private:note};
    admWrite_('Consignments',con._row,updates);
    if(decision==='approve'){
      const seller=admFind_('Sellers','seller_id',con.seller_id);
      admWrite_('Sellers',seller._row,{identity_verification_status:'verified',seller_status:'active',updated_at:new Date()});
    }
    admLog_(actor,'review_consignment','Consignments',con.consignment_id,{status:con.status},{status:next,verification_status:verify});
    return{ok:true,status:next};
  });
}
/** Creates private Google Docs DRAFT; legal counsel / both parties must review before using. */
function adminCreateAgreement(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const con=admFind_('Consignments','consignment_id',f.consignmentId);
    if(con.verification_status!=='verified'||con.status==='rejected')throw new Error('ต้องตรวจสอบคำขอฝากขายก่อน');
    if(admAll_('Agreements').some(a=>a.consignment_id===con.consignment_id&&['draft','active'].includes(a.status)))
      throw new Error('มีสัญญาที่ยังไม่สิ้นสุดสำหรับคำขอนี้');
    const seller=admFind_('Sellers','seller_id',con.seller_id);
    const type=String(f.agreementType),commissionType=String(f.commissionType);
    if(!['open','exclusive'].includes(type)||!['percentage','fixed'].includes(commissionType))throw new Error('ประเภทสัญญาไม่ถูกต้อง');
    const rate=commissionType==='percentage'?admNum_(f.commissionRatePct,0,100):0;
    const fixed=commissionType==='fixed'?admNum_(f.commissionFixedThb,0,1e12):0;
    const start=admDate_(f.startDate),end=admDate_(f.endDate);
    if(end<=start)throw new Error('วันสิ้นสุดต้องหลังวันเริ่มต้น');
    const trigger=admText_(f.triggerCondition,350,true);
    if(!/โอนกรรมสิทธิ์|transfer/i.test(trigger))throw new Error('เวอร์ชันนี้รองรับการเกิดสิทธิที่ตรวจสอบด้วยหลักฐานโอนกรรมสิทธิ์เท่านั้น');
    const agreementId=admId_('AGR');
    const doc=DocumentApp.create('DRAFT - สัญญาแต่งตั้งนายหน้า '+agreementId);
    const body=doc.getBody();
    body.appendParagraph('ร่างสัญญาแต่งตั้งนายหน้าเพื่อขายอสังหาริมทรัพย์').setHeading(DocumentApp.ParagraphHeading.HEADING1);
    body.appendParagraph('เลขอ้างอิง: '+agreementId+' | ฉบับร่าง ยังไม่ใช่สัญญาที่ลงนาม');
    body.appendParagraph('เอกสารนี้เป็นร่างเพื่อพิจารณา ต้องให้ผู้เชี่ยวชาญกฎหมายทบทวนข้อกำหนดก่อนคู่สัญญาลงนาม');
    body.appendParagraph('ผู้ฝากขาย: '+seller.full_name+' (ผู้มีสิทธิต้องยืนยันตัวบุคคลและอำนาจอีกครั้ง)');
    body.appendParagraph('นายหน้า: [กรอกชื่อบุคคล/นิติบุคคลผู้รับแต่งตั้ง, ที่อยู่, เลขทะเบียนที่เกี่ยวข้อง]');
    body.appendParagraph('ทรัพย์สิน: อำเภอ'+con.district+' จังหวัดเพชรบูรณ์ | เนื้อที่ '+con.area_sq_wah+' ตารางวา | เอกสารสิทธิ '+con.title_deed_type);
    body.appendParagraph('เลขโฉนด/ที่ตั้งละเอียด/เจ้าของกรรมสิทธิ์ตามเอกสาร: [ต้องตรวจสอบและกรอกให้ครบ]');
    body.appendParagraph('ราคาเสนอขาย: '+Number(con.asking_price_thb).toLocaleString('en-US')+' บาท');
    body.appendParagraph('ลักษณะการแต่งตั้ง: '+(type==='exclusive'?'เฉพาะผู้เดียว (ต้องระบุข้อยกเว้นอย่างชัดเจน)':'ทั่วไป ไม่ผูกขาด'));
    body.appendParagraph('ระยะเวลา: '+f.startDate+' ถึง '+f.endDate);
    body.appendParagraph('ค่าบำเหน็จ: '+(commissionType==='percentage'?rate+'% ของราคาซื้อขายตามเงื่อนไขที่ตกลง':fixed+' บาท'));
    body.appendParagraph('การเกิดสิทธิเรียกค่านายหน้า: '+trigger);
    body.appendParagraph('การจ่ายเงินจริง, ภาษี, VAT (ถ้ามี), การยกเลิก, การแนะนำลูกค้าหลังหมดอายุ และข้อยกเว้น: [ต้องเจรจาและระบุเงื่อนไข]');
    body.appendParagraph('การอนุญาตเผยแพร่ภาพ/ที่ตั้ง/พิกัด และการประมวลผลข้อมูลส่วนบุคคล: [ระบุให้ชัดเจน]');
    body.appendParagraph('ลงชื่อผู้ฝากขาย __________________ วันที่ __________');
    body.appendParagraph('ลงชื่อนายหน้า __________________ วันที่ __________');
    doc.saveAndClose();
    const now=new Date();
    admAppend_('Agreements',{agreement_id:agreementId,consignment_id:con.consignment_id,
      seller_id:con.seller_id,agreement_type:type,commission_type:commissionType,
      commission_rate_pct:rate,commission_fixed_thb:fixed,commission_base:'closed_price_thb',
      start_at:start,expires_at:end,trigger_condition:trigger,document_drive_id:doc.getId(),
      signature_status:'not_sent',status:'draft',version:1,updated_at:now});
    admAppend_('DocumentIndex',{doc_id:admId_('DOC'),consignment_id:con.consignment_id,
      agreement_id:agreementId,doc_type:'agreement_draft',drive_file_id:doc.getId(),
      access_level:'private',version:1,uploaded_at:now,verified_by:actor});
    admLog_(actor,'create_agreement_draft','Agreements',agreementId,null,{consignment_id:con.consignment_id,rate,fixed});
    return{agreementId,draftUrl:doc.getUrl(),status:'draft'};
  });
}
/** Manual signed PDF registration. Verifies restricted file and computes true SHA-256. */
function adminRecordSignedAgreement(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    if(f.confirmed!==true)throw new Error('ต้องยืนยันว่าได้ตรวจสอบลายมือชื่อคู่สัญญาแล้ว');
    const a=admFind_('Agreements','agreement_id',f.agreementId);
    if(a.status!=='draft'||a.signature_status!=='not_sent')throw new Error('บันทึกลงนามได้เฉพาะสัญญาร่างที่ยังไม่ลงนาม');
    const file=admPrivateFile_(f.signedPdfId,true),sha=admHash_(file),signed=admDate_(f.signedAt);
    admWrite_('Agreements',a._row,{document_drive_id:file.getId(),document_sha256:sha,
      signature_status:'signed',signed_at:signed,status:'active',updated_at:new Date()});
    admAppend_('DocumentIndex',{doc_id:admId_('DOC'),consignment_id:a.consignment_id,
      agreement_id:a.agreement_id,doc_type:'agreement_signed_pdf',drive_file_id:file.getId(),
      access_level:'private',version:a.version||1,uploaded_at:new Date(),verified_by:actor,
      checksum_sha256:sha});
    admLog_(actor,'record_signed_agreement','Agreements',a.agreement_id,{status:a.status},{status:'active',sha256:sha});
    return{ok:true,sha256:sha};
  });
}
/** Write around ARRAYFORMULA in Listings!K2:L. Never overwrite those cells. */
function admAddListingRow_(data){
  const sh=admSheet_('Listings'),hdr=admHeader_('Listings');
  const currentLast=Math.max(2,sh.getLastRow());
  const ids=sh.getRange(2,1,currentLast-1,1).getValues();
  const free=ids.findIndex(r=>!r[0]);
  const at=free<0?currentLast+1:free+2;
  if(at>sh.getMaxRows())sh.insertRowsAfter(sh.getMaxRows(),100);
  const values=hdr.map(k=>data[k]===undefined?'':data[k]);
  const skip=['area_sq_wah','price_per_sq_wah'];
  if(hdr[10]!==skip[0]||hdr[11]!==skip[1])throw new Error('Unexpected Listings formula columns');
  sh.getRange(at,1,1,10).setValues([values.slice(0,10)]);
  sh.getRange(at,13,1,hdr.length-12).setValues([values.slice(12)]);
  return at;
}
function adminCreateListing(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const {con,a}=admEnsureAgreement_(f.consignmentId);
    if(con.property_id)throw new Error('คำขอนี้มีประกาศแล้ว');
    const rai=admNum_(f.rai,0,1000000),ngan=admNum_(f.ngan,0,3),wah=admNum_(f.wah,0,99.99);
    if(!Number.isInteger(rai)||!Number.isInteger(ngan))throw new Error('ไร่และงานต้องเป็นจำนวนเต็ม');
    const area=400*rai+100*ngan+wah;
    if(area<=0||Math.abs(area-Number(con.area_sq_wah))>0.1)throw new Error('เนื้อที่ไม่ตรงกับคำขอฝากขาย กรุณาตรวจสอบ');
    const district=String(con.district);
    if(!ADM_DISTRICTS.includes(district))throw new Error('อำเภอไม่อยู่ในเพชรบูรณ์');
    const price=f.priceThb==null||f.priceThb===''?Number(con.asking_price_thb):admNum_(f.priceThb,1,1e12);
    const id=admId_('PB'),now=new Date();
    admAddListingRow_({property_id:id,consignment_id:con.consignment_id,
      title:admText_(f.title,150,true),province:'เพชรบูรณ์',district,
      subdistrict:admText_(f.subdistrict||'',90,false),price_thb:price,rai,ngan,wah,
      purpose:admText_(f.purpose||'ที่ดิน',80,true),title_deed_type:con.title_deed_type,
      road_access:admText_(f.roadAccess||'',250,false),description:admText_(f.description||'',900,false),
      location_precision:'approximate',status:'draft',updated_at:now,verified_at:now});
    admWrite_('Consignments',con._row,{property_id:id,status:'approved'});
    admLog_(actor,'create_listing','Listings',id,null,{consignment_id:con.consignment_id,agreement_id:a.agreement_id,price});
    return{propertyId:id,status:'draft'};
  });
}
function adminSetListingStatus(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const l=admFind_('Listings','property_id',f.propertyId),status=String(f.status);
    if(!['draft','pending_review','published','reserved','sold','archived'].includes(status))throw new Error('สถานะไม่ถูกต้อง');
    if(l.status==='sold'&&status!=='sold')throw new Error('ประกาศที่ขายแล้วไม่สามารถเปิดกลับเป็นขายได้');
    if(status==='published'){
      const {con}=admEnsureAgreement_(l.consignment_id);
      if(!['approved','published'].includes(con.status))throw new Error('คำขอยังไม่อนุมัติ');
      if(!l.title||Number(l.price_thb)<=0)throw new Error('ข้อมูลประกาศไม่ครบ');
      admWrite_('Consignments',con._row,{status:'published'});
    }
    if(status==='sold'&&!admAll_('Deals').some(d=>d.property_id===l.property_id&&d.status==='transferred'))
      throw new Error('ต้องบันทึกดีลโอนกรรมสิทธิ์ก่อนปิดเป็น sold');
    admWrite_('Listings',l._row,{status,updated_at:new Date(),published_at:status==='published'?(l.published_at||new Date()):l.published_at});
    admLog_(actor,'change_listing_status','Listings',l.property_id,{status:l.status},{status});
    return{ok:true,status};
  });
}
function adminChangePrice(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const l=admFind_('Listings','property_id',f.propertyId),price=admNum_(f.newPriceThb,1,1e12);
    if(['sold','archived'].includes(l.status))throw new Error('ประกาศที่ขายแล้วหรือเก็บเข้าคลังไม่อนุญาตให้เปลี่ยนราคา');
    if(Number(l.price_thb)===price)throw new Error('ราคาใหม่เท่ากับเดิม');
    admWrite_('Listings',l._row,{price_thb:price,updated_at:new Date()});
    admAppend_('PriceHistory',{history_id:admId_('PRICE'),property_id:l.property_id,changed_at:new Date(),
      old_price_thb:Number(l.price_thb),new_price_thb:price,changed_by:actor,reason:admText_(f.reason||'',250,false)});
    admLog_(actor,'change_listing_price','Listings',l.property_id,{price:l.price_thb},{price});
    return{ok:true};
  });
}
function adminAddImage(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const l=admFind_('Listings','property_id',f.propertyId);
    const url=admText_(f.imageUrl,1200,true);
    if(!/^https:\/\/[^\s"'<>]+$/i.test(url))throw new Error('รูปภาพต้องเป็น HTTPS URL ที่เข้าถึงสาธารณะได้');
    const id=admId_('IMG');
    admAppend_('Images',{image_id:id,property_id:l.property_id,image_url:url,
      image_type:admText_(f.imageType||'photo',80,true),sort_order:admNum_(f.sortOrder||0,0,1000),
      is_cover:f.isCover===true,approved_public:f.approvedPublic===true,uploaded_at:new Date()});
    admLog_(actor,'add_image','Images',id,null,{property_id:l.property_id,approvedPublic:f.approvedPublic===true});
    return{id};
  });
}
function adminUpdateLead(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const lead=admFind_('Leads','lead_id',f.leadId),status=String(f.status);
    if(!['new','contacted','viewing','negotiating','closed','lost'].includes(status))throw new Error('สถานะ Lead ไม่ถูกต้อง');
    const notes=admText_(f.note||'',900,false),updates={lead_status:status,notes_private:notes};
    if(f.agentId){admFind_('Agents','agent_id',f.agentId);updates.assigned_agent_id=String(f.agentId);}
    admWrite_('Leads',lead._row,updates);
    admLog_(actor,'update_lead','Leads',lead.lead_id,{status:lead.lead_status},{status});
    return{ok:true};
  });
}
function adminCreateDeal(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const l=admFind_('Listings','property_id',f.propertyId);
    if(!['published','reserved'].includes(l.status))throw new Error('ประกาศไม่ได้อยู่ในสถานะเปิดขาย');
    const {a}=admEnsureAgreement_(l.consignment_id);
    if(admAll_('Deals').some(d=>d.property_id===l.property_id&&['open','reserved','transferred'].includes(d.status)))
      throw new Error('ทรัพย์นี้มีดีลที่ยังใช้งานหรือขายแล้ว');
    const price=admNum_(f.closedPriceThb,1,1e12),lead=String(f.leadId||'');
    if(lead){const found=admFind_('Leads','lead_id',lead);if(found.property_id!==l.property_id)throw new Error('Lead ไม่ตรงกับทรัพย์');}
    const id=admId_('DEAL');
    admAppend_('Deals',{deal_id:id,property_id:l.property_id,agreement_id:a.agreement_id,
      lead_id:lead,closed_price_thb:price,agreement_signed_at:a.signed_at,
      commission_receivable_thb:'',commission_collected_thb:0,status:'open',updated_at:new Date()});
    admWrite_('Listings',l._row,{status:'reserved',updated_at:new Date()});
    admLog_(actor,'create_deal','Deals',id,null,{property_id:l.property_id,closed_price:price});
    return{dealId:id,status:'open'};
  });
}
/** Human attestation of contract's earned-trigger with private documentary evidence. */
function adminConfirmCommissionEarned(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    if(f.confirmed!==true||f.transferConfirmed!==true)throw new Error('ต้องยืนยันการโอนกรรมสิทธิ์และเงื่อนไขเกิดสิทธิรับค่านายหน้า');
    const deal=admFind_('Deals','deal_id',f.dealId);
    if(!['open','reserved'].includes(deal.status)||deal.commission_earned_at)throw new Error('ดีลนี้ไม่สามารถยืนยันซ้ำ');
    const a=admFind_('Agreements','agreement_id',deal.agreement_id);
    if(a.status!=='active'||a.signature_status!=='signed')throw new Error('ไม่มีสัญญาที่ลงนามครบ');
    const proof=admPrivateFile_(f.evidenceDriveFileId,false),reason=admText_(f.evidenceNote,900,true);
    if(reason.length<15)throw new Error('อธิบายเหตุผลที่เกิดสิทธิอย่างน้อย 15 ตัวอักษร');
    const fee=admCommission_(a,Number(deal.closed_price_thb));
    const now=new Date(), l=admFind_('Listings','property_id',deal.property_id);
    admWrite_('Deals',deal._row,{ownership_transferred_at:now,commission_earned_at:now,
      commission_receivable_thb:fee,status:'transferred',updated_at:now});
    admWrite_('Listings',l._row,{status:'sold',updated_at:now});
    admAppend_('DocumentIndex',{doc_id:admId_('DOC'),consignment_id:a.consignment_id,
      agreement_id:a.agreement_id,doc_type:'commission_trigger_evidence',drive_file_id:proof.getId(),
      access_level:'private',version:1,uploaded_at:now,verified_by:actor,notes_private:reason});
    admLog_(actor,'commission_earned','Deals',deal.deal_id,{status:deal.status},{status:'transferred',fee,proof_id:proof.getId()});
    return{fee,status:'transferred'};
  });
}
function adminCollectCommission(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const deal=admFind_('Deals','deal_id',f.dealId);
    const earned=Number(deal.commission_receivable_thb);
    if(deal.status!=='transferred'||!(earned>=0)||!deal.commission_earned_at)throw new Error('ค่านายหน้ายังไม่เกิดสิทธิ');
    const amount=admNum_(f.amountThb,0.01,1e12),ref=admText_(f.paymentRef,120,true);
    const existing=admAll_('Collections').filter(x=>x.deal_id===deal.deal_id);
    if(existing.some(x=>x.payment_ref===ref))throw new Error('payment_ref นี้เคยบันทึกแล้ว');
    const paid=existing.reduce((s,x)=>s+Number(x.amount_thb||0),0);
    if(Math.round((paid+amount)*100)>Math.round(earned*100))throw new Error('รับเงินรวมเกินสิทธิค่าคอมมิชชัน');
    const id=admId_('COL');
    admAppend_('Collections',{collection_id:id,deal_id:deal.deal_id,amount_thb:amount,
      collected_at:new Date(),payment_ref:ref,received_by:actor,note:admText_(f.note||'',300,false)});
    admWrite_('Deals',deal._row,{commission_collected_thb:Math.round((paid+amount)*100)/100,updated_at:new Date()});
    admLog_(actor,'collect_commission','Collections',id,null,{deal_id:deal.deal_id,amount});
    return{id,received:paid+amount,receivable:earned};
  });
}
function adminApproveSplits(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const deal=admFind_('Deals','deal_id',f.dealId),fee=Number(deal.commission_receivable_thb);
    if(deal.status!=='transferred'||!deal.commission_earned_at||!Number.isFinite(fee)||fee<=0)
      throw new Error('ต้องเกิดสิทธิรับค่านายหน้าก่อนจัดสรรส่วนแบ่ง');
    if(admAll_('SplitRules').some(x=>x.deal_id===deal.deal_id))throw new Error('ดีลนี้มีรายการแบ่งค่านายหน้าแล้ว ห้ามบันทึกซ้ำ');
    const parts=f.items;
    if(!Array.isArray(parts)||parts.length<1||parts.length>20)throw new Error('ต้องมีรายการแบ่ง 1–20 รายการ');
    const seen=new Set();let sum=0,allocated=0;
    const normalized=parts.map((x,i)=>{
      const agent=admFind_('Agents','agent_id',String(x.agentId||''));
      if(agent.status!=='active'||seen.has(agent.agent_id))throw new Error('นายหน้าไม่พร้อมใช้งานหรือซ้ำ');
      seen.add(agent.agent_id);
      const pct=admNum_(x.splitPct,0.01,100);sum+=pct;
      const value=i===parts.length-1?Math.round((fee-allocated)*100)/100:Math.round((fee*pct/100)*100)/100;
      allocated+=value;
      return{agentId:agent.agent_id,role:agent.role,pct,value};
    });
    if(Math.abs(sum-100)>0.000001)throw new Error('ส่วนแบ่งค่านายหน้าต้องรวม 100%');
    normalized.forEach(p=>{
      const splitId=admId_('SPL');
      admAppend_('SplitRules',{split_id:splitId,deal_id:deal.deal_id,agent_id:p.agentId,
        role:p.role,split_pct:p.pct,split_amount_thb:p.value,
        approved_by:actor,approved_at:new Date(),status:'approved',rule_version:1});
      // Company-retained share is not a bank payout. Reconciliation tracks it separately.
      if(p.role!=='company')admAppend_('Payouts',{payout_id:admId_('PAY'),split_id:splitId,amount_thb:p.value,
        withholding_tax_thb:0,net_paid_thb:0,status:'pending',updated_at:new Date()});
    });
    admLog_(actor,'approve_splits','Deals',deal.deal_id,null,{sum,allocation:normalized});
    return{ok:true,total:normalized.reduce((s,x)=>s+x.value,0)};
  });
}
function adminApprovePayout(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const p=admFind_('Payouts','payout_id',f.payoutId);
    if(p.status!=='pending')throw new Error('อนุมัติได้เฉพาะ pending');
    const split=admFind_('SplitRules','split_id',p.split_id);
    if(split.status!=='approved')throw new Error('Split ยังไม่อนุมัติ');
    admWrite_('Payouts',p._row,{status:'approved',approved_by:actor,updated_at:new Date()});
    admLog_(actor,'approve_payout','Payouts',p.payout_id,{status:p.status},{status:'approved'});
    return{ok:true};
  });
}
function adminPayPayout(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const p=admFind_('Payouts','payout_id',f.payoutId);
    if(p.status!=='approved')throw new Error('จ่ายได้เฉพาะรายการที่ approved');
    const split=admFind_('SplitRules','split_id',p.split_id),deal=admFind_('Deals','deal_id',split.deal_id);
    const gross=Number(p.amount_thb),tax=admNum_(f.withholdingTaxThb,0,gross),ref=admText_(f.paymentRef,140,true);
    if(admAll_('Payouts').some(x=>x.payment_ref===ref&&x.status==='paid'))throw new Error('payment_ref ถูกใช้แล้ว');
    const collected=admAll_('Collections').filter(x=>x.deal_id===deal.deal_id).reduce((s,x)=>s+Number(x.amount_thb||0),0);
    const splitIndex=Object.fromEntries(admAll_('SplitRules').map(x=>[x.split_id,x.deal_id]));
    const priorPaid=admAll_('Payouts').filter(x=>x.status==='paid'&&splitIndex[x.split_id]===deal.deal_id)
      .reduce((s,x)=>s+Number(x.amount_thb||0),0);
    if(Math.round((priorPaid+gross)*100)>Math.round(collected*100))throw new Error('ยอดจ่ายเกินเงินค่านายหน้าที่ได้รับจริง');
    admWrite_('Payouts',p._row,{withholding_tax_thb:tax,net_paid_thb:Math.round((gross-tax)*100)/100,
      paid_at:new Date(),payment_ref:ref,status:'paid',updated_at:new Date()});
    admLog_(actor,'pay_commission','Payouts',p.payout_id,{status:p.status},{status:'paid',gross,tax,ref});
    return{ok:true,gross,net:Math.round((gross-tax)*100)/100};
  });
}
function adminReconcileDeal(dealId){
  adminAuth_();
  const deal=admFind_('Deals','deal_id',dealId),fee=Number(deal.commission_receivable_thb||0);
  const receipts=admAll_('Collections').filter(x=>x.deal_id===dealId).reduce((s,x)=>s+Number(x.amount_thb||0),0);
  const splits=admAll_('SplitRules').filter(x=>x.deal_id===dealId&&x.status==='approved');
  const payouts=admAll_('Payouts'),ids=new Set(splits.map(s=>s.split_id));
  const paid=payouts.filter(p=>ids.has(p.split_id)&&p.status==='paid').reduce((s,x)=>s+Number(x.amount_thb||0),0);
  const allocated=splits.reduce((s,x)=>s+Number(x.split_amount_thb||0),0);
  const companyRetained=splits.filter(x=>x.role==='company').reduce((s,x)=>s+Number(x.split_amount_thb||0),0);
  return{dealId,fee,receipts,receiptsRecorded:Number(deal.commission_collected_thb||0),
    receiptDifference:Math.round((receipts-Number(deal.commission_collected_thb||0))*100)/100,
    allocated,companyRetained,splitPercentage:splits.reduce((s,x)=>s+Number(x.split_pct||0),0),paid,
    remainingToCollect:Math.max(0,Math.round((fee-receipts)*100)/100),
    remainingToDisburse:Math.max(0,Math.round((allocated-companyRetained-paid)*100)/100)};
}

/** Terminate or expire a contract; published listings are moved to archived for safety. */
function adminCloseAgreement(f){
  const actor=adminAuth_();
  return admLocked_(()=>{
    const a=admFind_('Agreements','agreement_id',f.agreementId),status=String(f.status);
    if(!['terminated','expired'].includes(status))throw new Error('เลือก terminated หรือ expired');
    if(!['draft','active'].includes(a.status))throw new Error('ไม่สามารถปิดสัญญาที่ปิดแล้ว');
    const reason=admText_(f.reason,400,true);
    admWrite_('Agreements',a._row,{status,updated_at:new Date()});
    const cons=admFind_('Consignments','consignment_id',a.consignment_id);
    if(cons.property_id){
      const l=admFind_('Listings','property_id',cons.property_id);
      if(l.status==='published')admWrite_('Listings',l._row,{status:'archived',updated_at:new Date()});
    }
    admLog_(actor,'close_agreement','Agreements',a.agreement_id,{status:a.status},{status,reason});
    return{ok:true,status};
  });
}
