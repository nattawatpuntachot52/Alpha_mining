# เพชรบูรณ์ แลนด์ — Deployment Package

**ระบบเว็บไซต์ขายและรับฝากขายที่ดิน + Backoffice (Google Sheets / Google Apps Script)**

**วันที่แพ็กเกจ:** 15 พฤศจิกายน 2026  
**Target database:** https://docs.google.com/spreadsheets/d/1idxj5laI7Y4bdhTdDvpD63ernjRaEP34CitpOi8mFgo/edit  
**สถาปัตยกรรม:** แยก Google Apps Script เป็น 2 *คนละโปรเจ็กต์* ที่เชื่อม Google Sheet ไฟล์เดียวกัน

## สถานะที่ยืนยันได้

- [x] Google Sheet มีฐานข้อมูลรวม **16 แท็บ** รวม `Collections` และคอลัมน์รหัสติดตาม (ไม่มีข้อมูลลูกค้า / ดีลจำลองเพิ่มไว้)
- [x] Source Code สำหรับ Public Web App และ Private Admin Web App อยู่ใน ZIP
- [x] ผ่านการตรวจ JavaScript syntax ของ Server + Browser และ End-to-End backend แบบ **mock** (`node tests/test_system.js`)
- [x] มีตัวป้องกันการเขียนข้อมูลส่วนตัวเมื่อ Sheet ยังแชร์สาธารณะ, Admin Allowlist, การตรวจความสอดคล้องของข้อมูล / ยอดเงิน
- [ ] **ยังไม่ได้ Deploy โปรเจ็กต์ Apps Script สองตัว** และยังไม่ได้ Live E2E กับบริการ Google จริง
- [ ] **ยังไม่ได้เปลี่ยนสิทธิ์แชร์ Google Sheet ของคุณ**: ตรวจล่าสุดยังเป็น `Anyone with the link → Editor` (เป็น blocker สำคัญ)
- [ ] สัญญาตัวอย่างต้องให้ผู้เชี่ยวชาญกฎหมายตรวจ; ไม่มีระบบ e-Sign อัตโนมัติ / โอนเงินผ่านธนาคาร
- [ ] Privacy Notice, ชื่อผู้ดำเนินการ, อีเมลติดต่อและนโยบายรักษาข้อมูลต้องใส่ให้ครบก่อนรับข้อมูลจริง

## สิ่งที่มีในแพ็กเกจ

| โฟลเดอร์ | ส่วนประกอบ | วัตถุประสงค์ |
|---|---|---|
| `public/Code.gs` | Public backend | แสดงประกาศที่อนุมัติ รับฝากขาย รับ Lead ตรวจสถานะฝากขายด้วยรหัสลับ |
| `public/Index.html` | Public website | ค้นหาที่ดิน กรอง ดูรายละเอียด ติดต่อและฝากขาย |
| `public/appsscript.json` | Manifest | Deploy เป็น `USER_DEPLOYING` / `ANYONE_ANONYMOUS` |
| `admin/Code.gs` | Private backend | ตรวจรับฝากขาย สัญญา ประกาศ ดีล ค่าคอมมิชชั่น ค่าตอบแทน รายการรับ/จ่าย |
| `admin/Admin.html` | Private operations UI | Dashboard, ตาราง, ฟอร์มดำเนินการ, กระทบยอด |
| `admin/appsscript.json` | Manifest | Deploy เป็น `USER_ACCESSING` / `ANYONE` (ต้องตรวจ Admin allowlist ใน Server) |
| `docs/DEPLOY_TH.md` | คู่มือ | ขั้นตอนติดตั้งจาก Google Sheets |
| `docs/SCHEMA.md` | Data schema | ตาราง/กฎความสัมพันธ์ |
| `docs/GO_LIVE_CHECKLIST.md` | Acceptance checklist | สิ่งต้องทดสอบก่อนเปิดใช้งานจริง |
| `docs/SECURITY_AND_LIMITATIONS.md` | Security / risks | ข้อจำกัด MVP และการคุ้มครองข้อมูล |
| `docs/PRIVACY_NOTICE_TEMPLATE.md` | ข้อความตั้งต้น | ต้องปรับโดยผู้ควบคุมข้อมูลและที่ปรึกษา |
| `docs/AGREEMENT_REVIEW.md` | คู่มือสัญญา | ประเด็นต้องตรวจในสัญญานายหน้า |
| `tests/test_system.js` | Automated mocks | ทดสอบ Happy-path + Security/Financial invariants |

## ลำดับงานครบเส้นทางหลัก

เจ้าของส่งคำขอ (`Consignments`) → เจ้าหน้าที่ตรวจเจ้าของ/โฉนด → Admin สร้างร่างสัญญาใน Google Docs → คู่สัญญาลงนามนอกระบบ → Admin อัปโหลดและบันทึก PDF ที่ลงนามแล้ว → สร้างประกาศ (`draft`) → `published` → ผู้ซื้อส่งคำขอ (`Leads`) → สร้าง `Deals` → ยืนยันการโอนกรรมสิทธิ์พร้อมเอกสาร → `commission_receivable_thb` → รับเงิน (`Collections`) → แบ่งค่านายหน้า 100% (`SplitRules`) → อนุมัติ/จ่าย (`Payouts`) → กระทบยอดและตรวจ `AuditLog`.

ผู้ขายสามารถใช้ **รหัสติดตามลับ 32 ตัว** เช็กสถานะคำขอ ไม่สามารถดูข้อมูลส่วนตัวหรือสัญญาผ่านหน้า Public ได้

## ขั้นตอนแรกที่ต้องทำ

1. เปลี่ยนสิทธิ์ Google Sheet เป็น **Share → General access → Restricted** ทันที (อย่าเผยแพร่ไฟล์ Spreadsheet ให้ผู้ซื้อ)
2. ให้สิทธิ์ **Editor** เฉพาะเจ้าของงานและผู้ดูแลที่เชื่อถือได้
3. ติดตั้ง **Public project** และ **Admin project** แยกกัน ตาม `docs/DEPLOY_TH.md`
4. ตั้งค่า Admin Script Property `ADMIN_EMAILS` เป็นอีเมลจริงที่อนุญาต
5. ทดสอบ 1 วงจรด้วยข้อมูลทดสอบและเอกสารทดสอบใน Drive ที่ Restricted
6. ตรวจจุดห้ามผิดพลาดทั้งหมดใน `docs/GO_LIVE_CHECKLIST.md` ก่อนเปิดใช้งานจริง

> **ขอบเขต:** ระบบนี้เป็น **deployable operational MVP** ที่ยึด Google Sheets เป็น database; ไม่ใช่ระบบบัญชี / ระบบสัญญา / ระบบ e-signature ที่ผ่านการรับรองจากภายนอก ข้อมูลและไฟล์เงินจริงต้องมีขั้นตอนตรวจยืนยันอีกชั้น
