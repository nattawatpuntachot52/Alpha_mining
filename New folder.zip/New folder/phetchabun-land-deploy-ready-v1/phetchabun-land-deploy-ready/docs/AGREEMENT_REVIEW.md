# Review checklist — Brokerage agreement (Thailand)

**Draft generation only. No e-signing service is included.**

Before issuing or signing, counsel should verify at least:

1. Identity and legal capacity of land owner(s), nominee, co-owner, authorized agent.
2. Title deed number, exact land area, physical boundaries and road/access rights.
3. Correct appointment type: open/non-exclusive or exclusive, including exceptions and owner's direct sales.
4. Asking price; authority and approval process for price revisions or offers.
5. Commission basis (closed price vs other base), percentage or fixed fee, VAT/tax treatment as applicable.
6. Event triggering the right to commission, attribution to broker, conditions precedent, cancellations and refunds.
7. Payment due date, payer identity, bank details, receipt/withholding documentation.
8. Term, renewals, termination, notice, introduced-buyer/tail provisions, dispute handling.
9. Permission to use photos, location data and marketing materials; protection of personal data.
10. Signatures of authorized parties; any separate powers of attorney are dealt with outside the brokerage agreement.

System workflow only allows recording `signed` after staff upload a private signed PDF and explicitly confirm its review. The system hashes the PDF but does not authenticate a human signatory. Evaluate whether stamp-duty or other formality requirements apply to the particular arrangement. Consult licensed Thai legal and tax professionals.
