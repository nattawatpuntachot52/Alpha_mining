# Google Sheets Schema (Native Sheet)

Spreadsheet: `1idxj5laI7Y4bdhTdDvpD63ernjRaEP34CitpOi8mFgo`  
Time zone: `Asia/Bangkok`

| Tab | Primary key | Description | Access |
|---|---|---|---|
| `Listings` | `property_id` | ประกาศราคา พื้นที่ สถานะ แสดงเฉพาะ `published` | PUBLIC via **whitelisted API only** |
| `Images` | `image_id` | รูปภาพ URL ลำดับ approved_public | Public only approved URLs |
| `Locations` | `property_id` | พิกัดจริง/ประมาณ ทางเข้า สาธารณูปโภค | ADMIN (private exact location) |
| `Sellers` | `seller_id` | เจ้าของที่ดิน เบอร์โทร consent | ADMIN |
| `Consignments` | `consignment_id` | คำขอฝากขายและผลตรวจ | ADMIN; token-check status only |
| `Agreements` | `agreement_id` | เงื่อนไข นายหน้า PDF SHA-256 สถานะ | ADMIN |
| `Agents` | `agent_id` | สมาชิกในทีมและบทบาท | ADMIN |
| `Leads` | `lead_id` | ข้อมูลลูกค้าสนใจ (ไม่เปิดเผยต่อ Public) | ADMIN |
| `Deals` | `deal_id` | ราคาปิด สถานะ โอน สิทธิค่าคอม | ADMIN |
| `SplitRules` | `split_id` | สัดส่วนแบ่งค่านายหน้า approved | ADMIN |
| `Payouts` | `payout_id` | จ่าย/หักภาษี/เลขอ้างอิง | ADMIN |
| `Collections` | `collection_id` | เงินค่านายหน้าที่รับจริง | ADMIN |
| `PriceHistory` | `history_id` | ประวัติการปรับราคา | ADMIN |
| `DocumentIndex` | `doc_id` | Drive ID และ SHA256 เอกสารส่วนตัว | ADMIN |
| `AuditLog` | `event_id` | ผู้แก้ไข/การดำเนินการ/วันเวลา | ADMIN |
| `START_HERE` | — | คำแนะนำ Schema และ Warning | ADMIN |

Relations: `Consignments.seller_id → Sellers.seller_id`; `Listings.consignment_id → Consignments.consignment_id`; `Agreements.consignment_id → Consignments.consignment_id`; `Leads.property_id → Listings.property_id`; `Deals.agreement_id → Agreements.agreement_id`; `SplitRules.deal_id → Deals.deal_id`; `Payouts.split_id → SplitRules.split_id`; `Collections.deal_id → Deals.deal_id`.

### Invariants

1. Public returns **only** `Listings.status = published`, photos approved, and the explicitly enumerated fields
2. Intake never directly creates a Listing or Agreement
3. Agreement signing record requires restricted PDF (verified type/size/hash) plus human confirmation
4. Listing `published` only if verified consignment and one active/signed agreement
5. A deal becomes `transferred` only after human confirmation of land transfer with private evidence
6. Commission receivable = percentage × actual closed price / 100, or fixed amount per agreement
7. Collections require unique `payment_ref` per deal and cannot exceed commission receivable
8. Split percentages **must sum to 100.000000%**; last allocation receives rounding remainder
9. `Agents.role = company` is retained business revenue, not a bank payout
10. Total Payout gross across deal cannot exceed money actually collected
11. `Listings!K2:L` are **ArrayFormula** columns for area and price per sq.wah; code writes around them
12. `Consignments.tracking_token_hash` stores SHA-256 hash of secret (32-char code delivered once)

### ID and Status conventions

IDs: `SEL-...`, `CON-...`, `AGR-...`, `PB-...`, `LEAD-...`, `DEAL-...`, `SPL-...`, `PAY-...`, `COL-...`, `DOC-...`. Do not use row number as key.

Status values are used as ASCII tokens (`submitted`, `approved`, `published`, `signed`, `transferred`, `paid` etc.). Do not translate the stored status codes; translate in the UI instead.

**Atomicity caveat:** Multi-sheet writes are not database transactions. AuditLog, seller + consignment writes, or split + payout writes can be partially committed if Google stops an execution. Verify/reconcile after errors. A real production finance application should migrate to a transactional DB with append-only ledger and enforce strong authentication.
