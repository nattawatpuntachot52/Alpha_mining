# Go-Live Acceptance Checklist

## P0 — MUST pass before real names, documents or money

- [ ] Google Sheet `Share → General access → Restricted` and Editor list reviewed; no public share nor Publish to web
- [ ] Public and Admin are **separate Apps Script projects**; deployed permissions match readme
- [ ] Admin `ADMIN_EMAILS` is configured with verified addresses; outsider login blocked
- [ ] Owner/privacy contact details, privacy notice, retention period and rights request method published
- [ ] Lawyer reviewed actual brokerage contract, commission trigger, termination, tax, stamp-duty issues
- [ ] Signed files and identity evidence hosted privately; nobody can access through public website URL
- [ ] Admin cannot change paid split after approval; staff verifies payment reference and bank evidence
- [ ] Backup + recovery procedure ready; reconciliation process and human approver defined

## Functional smoke tests

- [ ] Public opens on phone and computer; site lists only `published` with approved images
- [ ] Public cannot see Sellers, Leads, exact coordinates, signed documents or payouts in page/API responses
- [ ] Public request creates unique `Sellers` + `Consignments`; status token returned once
- [ ] Wrong status token rejected; correct status token reveals only status
- [ ] Approve after checking owner rights and title deed; rejected request cannot publish
- [ ] Draft agreement creates Google Doc; cannot mark signed without restricted PDF and verification
- [ ] Published Listing appears after complete approval; sold listing disappears
- [ ] Contact form creates `Leads` only for published listing and requires consent
- [ ] Deal created with closed price; no commission earned without confirmed land-transfer evidence
- [ ] Add partial receipts; duplicated bank reference rejected; total receipts limited to earned fee
- [ ] Split 90% rejected and 100% accepted; company share not created as bank Payout
- [ ] Cannot pay more than receipts; withhold tax and payment reference recorded; double payment rejected
- [ ] Reconciliation of `fee`, `receipts`, `allocation`, `paid` matches expected data
- [ ] Blocker test: temporarily public-share a separate TEST sheet and confirm intake/admin fail closed; **never test with real PII**

## Operational controls

- [ ] Data retention and deletion request procedure approved
- [ ] Contract expiry reviewed daily; manual archiving workflow known
- [ ] Error log / Apps Script Execution dashboard monitored
- [ ] Admin edits reviewed through restricted AuditLog and monthly backup
- [ ] Business owner tests all form flows with dummy records before real customer data
- [ ] Apps Script quotas and traffic growth monitored; upgrade plan to DB documented

## Test evidence included in ZIP

Run locally: `node tests/test_system.js` — tests syntax + mocked end-to-end and security invariants. This **does not replace live Google / browser tests**.
