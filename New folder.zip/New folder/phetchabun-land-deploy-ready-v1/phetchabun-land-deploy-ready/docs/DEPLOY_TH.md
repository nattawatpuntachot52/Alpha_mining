# คู่มือ Deploy (Google Apps Script × 2)

**Spreadsheet ID ที่ตั้งไว้ใน Code.gs ทั้งสองโปรเจ็กต์:**
`1idxj5laI7Y4bdhTdDvpD63ernjRaEP34CitpOi8mFgo`

## 0. ความปลอดภัย — ต้องทำก่อน

Google Sheets → **Share → General access → Restricted**. ยกเลิกการเปิด `Anyone with the link – Editor` ก่อนเริ่มส่งข้อมูลจริง. ให้สิทธิ์ Edit เฉพาะบัญชี Google ของเจ้าของระบบและผู้ดูแล. เจ้าหน้าที่ที่ใช้ Admin Project แบบ Execute as *User accessing* ต้องมีสิทธิ์แก้ไขไฟล์นี้โดยตรงด้วย

ห้าม **File → Share → Publish to web** เพราะไฟล์เดียวกันมีข้อมูลผู้ขาย/ลูกค้า/สัญญา/เงินค่าตอบแทน.

## 1. Public App (โปรเจ็กต์ A)

1. เปิด `https://script.google.com/home/projects/create` ด้วยบัญชีเจ้าของ Google Sheet
2. ตั้งชื่อ `Phetchabun Land - PUBLIC` แล้ววาง `public/Code.gs` ลง `Code.gs`
3. คลิก `+` > `HTML` และตั้งชื่อ `Index`; วาง `public/Index.html`
4. เปิด **Project Settings → Show "appsscript.json" manifest file** และใส่เนื้อหา `public/appsscript.json`
5. คลิก **Deploy → New deployment → Web app**
   - Execute as: **Me** (บัญชีเจ้าของไฟล์)
   - Who has access: **Anyone** (หากมีตัวเลือก anonymous และต้องการผู้เข้าชมทั่วไป)
6. ยืนยัน Authorization ที่ถามด้วยบัญชีเจ้าของ — ตรวจ Scopes ก่อนกดยินยอม
7. คัดลอก URL ลงท้าย `/exec` เพื่อเป็น **Public Website URL**
8. ตรวจว่าหน้าเว็บเปิดได้โดยไม่ล็อกอิน; เมื่อยังไม่มี Listings ที่ `published` ต้องแสดง Empty State โดยไม่สร้างข้อมูลสมมติ

Public Web App มี server functions ที่เรียกจาก Browser ได้เฉพาะ `getPublishedListings()`, `submitConsignment(form)`, `submitInquiry(form)` และ `getConsignmentStatus(form)` (รวม `doGet`). ส่วน helper ลงท้าย `_` ตามรูปแบบ Apps Script ไม่เปิดให้หน้าเว็บเรียก

## 2. Admin App (โปรเจ็กต์ B — โปรเจ็กต์ใหม่ที่แยกขาด)

1. เปิด `https://script.google.com/home/projects/create` และตั้งชื่อ `Phetchabun Land - ADMIN`
2. วาง `admin/Code.gs` ลง `Code.gs`; เพิ่มไฟล์ HTML ชื่อ `Admin` จาก `admin/Admin.html`
3. ใส่ `admin/appsscript.json` ลง Manifest
4. เปิด **Project Settings → Script Properties → Add script property**
   - Property: `ADMIN_EMAILS`
   - Value: `owner@example.com,agent@example.com` **แทนด้วยบัญชีจริง** (อีเมลต้องตรงแบบเป๊ะ)
5. ให้ผู้ดูแลแต่ละคนมีสิทธิ์ **Editor** ของ Google Sheet (`Restricted`) และใช้บัญชีเดียวกันเข้าระบบ
6. **Deploy → New deployment → Web app**
   - Execute as: **User accessing the web app**
   - Who has access: **Anyone with a Google account** (ต้อง Login; จากนั้น Server ตรวจ `ADMIN_EMAILS` เพิ่ม)
   - หาก Workspace รองรับเฉพาะสมาชิก Domain ให้จำกัดระดับ Domain เพิ่มด้วย
7. ใช้ URL `/exec` ของ Admin แยกเก็บเฉพาะเจ้าหน้าที่ อย่าใส่ไว้ในเว็บสาธารณะ
8. ทดสอบบัญชี **ไม่อยู่ใน `ADMIN_EMAILS`** ต้องถูกปฏิเสธ, และบัญชีใน Allowlist ต้องเข้าถึง Dashboard ได้

**สำคัญ:** Do not combine Public and Admin `Code.gs` in one project. Apps Script public server functions สามารถถูกเรียกจากหน้าเว็บที่ใช้งาน Script เดียวกันได้ จึงต้องแยกโปรเจ็กต์ทางสิทธิ์จริง

## 3. เริ่มใช้งาน

1. Admin → คำขอฝากขาย → ตรวจสอบเอกสารเจ้าของและอำนาจก่อนกด `approve`
2. Admin → สัญญานายหน้า → สร้างร่าง (Google Docs) → ตรวจโดยผู้เชี่ยวชาญ → ลงนาม **ภายนอกระบบ**
3. อัปโหลด PDF ที่ลงนามแล้วไปยัง Google Drive แบบ `Restricted`; ตรวจลายมือชื่อ แล้วบันทึก URL หรือ File ID ใน Admin
4. Admin → ประกาศที่ดิน → สร้างประกาศ (เนื้อที่ต้องตรงกับคำขอ) → `published`; เพิ่มรูป HTTPS สาธารณะที่ได้รับอนุญาต
5. ผู้ซื้อกดรายละเอียดแปลงแล้วส่ง Lead → ปรากฏใน Admin
6. Admin → ดีล → สร้างดีลและระบุราคาซื้อขายจริง
7. เมื่อ **โอนกรรมสิทธิ์จริง** และมีหลักฐาน → Admin ยืนยันเกิดสิทธิค่าคอม
8. บันทึกเงินที่ได้รับจริงใน `Collections` โดยอ้างอิงใบรับเงิน/ธนาคาร
9. ตั้งค่าส่วนแบ่งรวม 100% ให้แต่ละ Agent (รวม `company` ถ้ามีส่วนแบ่งบริษัท)
10. อนุมัติ Payout แล้วบันทึกยอดภาษี ณ ที่จ่ายและเลขอ้างอิงการจ่ายเงินจริง
11. ใช้ `ตรวจสอบยอด` ในหน้า Deals เพื่อตรวจค่า Receivable / Collected / Allocated / Paid

## 4. Google Drive เอกสาร / รูป

- **เอกสารสิทธิ สัญญาลงนาม และหลักฐานโอน** ต้องอยู่ใน Drive ที่จำกัดสิทธิ์ แยกจากรูปประกาศ
- URL ภาพแปลงที่นำขึ้น `Images.image_url` ต้องเป็น HTTPS ที่ผู้เข้าชมเปิดได้ และมี `approved_public=true`
- ห้ามใช้ลิงก์ Drive ไฟล์โฉนด/บัตรประชาชน/สัญญาเป็นรูปประกาศ
- URL เอกสารลงนามต้องเป็น PDF; Server คำนวณ `SHA-256` จากไฟล์จริง (≤15 MB) ตอนบันทึก

## 5. การแก้ไขโปรเจ็กต์หลัง Deploy

แก้ Code แล้วสร้าง **New version** และ **Manage deployments → Edit → เลือก version ใหม่** (อย่าคาดว่า URL `/exec` จะอ่านโค้ดล่าสุดอัตโนมัติ). ทดสอบ `/dev` โดยผู้มีสิทธิ์แก้ Script ก่อนปล่อย version ใหม่

## 6. ปัญหาที่พบบ่อย

- `SECURITY BLOCK`: Google Sheet ยังแชร์แบบ Anyone/Domain; เปลี่ยนเป็น `Restricted`
- `ไม่ได้รับสิทธิ์ผู้ดูแล`: ใช้บัญชี Google ไม่ตรง `ADMIN_EMAILS`, Admin web app ไม่ใช่ Execute as User accessing, หรือ Session email ถูกซ่อน
- `ไม่พบแท็บ`: ตรวจว่าชื่อแท็บใน Google Sheets ตรงกับ `docs/SCHEMA.md`
- `Unauthorized` หรือ Permission denied: บัญชี Admin ไม่ได้ถูกเพิ่มเป็น Editor ของ Sheets/Drive files
- `DocumentApp`/`DriveApp` scope: ใช้บัญชีเดียวกันอนุญาต OAuth ให้ครบเมื่อ Deploy/Test
- `Quota`: Apps Script/Google Sheets มีขีดจำกัดรายวันและระยะเวลาประมวลผล — ดูเอกสาร Google

## เอกสารอ้างอิงทางเทคนิค

- https://developers.google.com/apps-script/guides/web
- https://developers.google.com/apps-script/guides/html/communication
- https://developers.google.com/apps-script/guides/services/quotas
