'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const crypto=require('node:crypto');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const script=(f)=>fs.readFileSync(path.join(root,f),'utf8');
const publicJS=script('public/Index.html').match(/<script>([\s\S]*?)<\/script>/)?.[1];
const adminJS=script('admin/Admin.html').match(/<script>([\s\S]*?)<\/script>/)?.[1];
for(const [file,s] of [['public Code.gs',script('public/Code.gs')],['admin Code.gs',script('admin/Code.gs')],['public HTML JS',publicJS],['admin HTML JS',adminJS]]){
 assert(s,'Missing '+file); new vm.Script(s,{filename:file}); console.log('PARSE OK:',file);
}
function fakeDB(){
 const names={
 Listings:'property_id consignment_id title province district subdistrict price_thb rai ngan wah area_sq_wah price_per_sq_wah purpose title_deed_type road_access description cover_image_url latitude_public longitude_public location_precision status published_at updated_at verified_at',
 Locations:'property_id latitude_exact longitude_exact latitude_public longitude_public location_precision frontage_m road_width_m terrain utilities map_url updated_at',
 Images:'image_id property_id image_url image_type sort_order is_cover approved_public uploaded_at',
 Sellers:'seller_id full_name phone email line_id identity_verification_status seller_status created_at updated_at notes_private consent_at submission_role privacy_notice_version',
 Consignments:'consignment_id property_id seller_id submitted_at asking_price_thb status verification_status verified_by verified_at assigned_agent_id notes_private district area_sq_wah seller_role title_deed_type desired_agreement_type proposed_commission_pct consent_at source tracking_token_hash privacy_notice_version',
 Agreements:'agreement_id consignment_id seller_id agreement_type commission_type commission_rate_pct commission_fixed_thb commission_base start_at expires_at trigger_condition document_drive_id document_sha256 signature_status signed_at status version updated_at',
 Agents:'agent_id name phone email role status created_at',
 Leads:'lead_id property_id customer_name customer_phone customer_email source lead_status submitted_at consent_at assigned_agent_id notes_private',
 Deals:'deal_id property_id agreement_id lead_id closed_price_thb agreement_signed_at ownership_transferred_at commission_earned_at commission_receivable_thb commission_collected_thb status updated_at notes_private',
 SplitRules:'split_id deal_id agent_id role split_pct split_amount_thb approved_by approved_at status rule_version',
 Payouts:'payout_id split_id amount_thb withholding_tax_thb net_paid_thb paid_at payment_ref status approved_by updated_at',
 Collections:'collection_id deal_id amount_thb collected_at payment_ref received_by note',
 PriceHistory:'history_id property_id changed_at old_price_thb new_price_thb changed_by reason',
 DocumentIndex:'doc_id consignment_id agreement_id doc_type drive_file_id access_level version uploaded_at verified_by checksum_sha256 notes_private',
 AuditLog:'event_id occurred_at actor_id action entity_type entity_id before_json after_json source'
 };
 class FakeRange{
  constructor(sheet,r,c,n,m){Object.assign(this,{sheet,r,c,n,m})}
  getValues(){return Array.from({length:this.n},(_,i)=>Array.from({length:this.m},(_,j)=>this.sheet.grid[this.r-1+i]?.[this.c-1+j]??''))}
  getValue(){return this.getValues()[0][0]}
  setValue(x){return this.setValues([[x]])}
  setValues(rows){assert.equal(rows.length,this.n);rows.forEach((cells,i)=>{assert.equal(cells.length,this.m);const ri=this.r-1+i;this.sheet.grid[ri]??=[];cells.forEach((v,j)=>this.sheet.grid[ri][this.c-1+j]=v)});return this;}
 }
 class FakeSheet{
  constructor(name,headers){this.name=name;this.headers=headers;this.grid=[headers.slice()];}
  getLastRow(){let i=this.grid.length;while(i>1&&!this.grid[i-1]?.some(v=>v!==''&&v!==undefined))i--;return i}
  getLastColumn(){return this.headers.length}
  getMaxRows(){return 1000}
  insertRowsAfter(){return null}
  getRange(r,c,n=1,m=1){return new FakeRange(this,r,c,n,m)}
  appendRow(values){assert.equal(values.length,this.headers.length);this.grid.push(values.slice());}
  deleteRow(row){this.grid.splice(row-1,1)}
 }
 const sheets=Object.fromEntries(Object.entries(names).map(([n,head])=>[n,new FakeSheet(n,head.split(' '))]));
 return {sheets,rows(name){const s=sheets[name];return s.grid.slice(1).filter(r=>r?.some(v=>v!==''))
   .map(r=>Object.fromEntries(s.headers.map((h,i)=>[h,r[i]])))},
  make(name,body){const s=sheets[name];s.appendRow(s.headers.map(h=>body[h]===undefined?'':body[h]))}};
}
const db=fakeDB();let restricted=true,sessionEmail='admin@example.com',counter=0;
const docs={};let cache=new Map();
const mocks={
 SpreadsheetApp:{openById:()=>({getSheetByName:n=>db.sheets[n]})},
 DriveApp:{Access:{PRIVATE:'PRIVATE',ANYONE:'ANYONE'},getFileById:id=>({getSharingAccess:()=>restricted?'PRIVATE':'ANYONE',getId:()=>id,
  getMimeType:()=>id.startsWith('PDF')?'application/pdf':'application/octet-stream',getSize:()=>1024,getBlob:()=>({getBytes:()=>Array.from(Buffer.from('pdf content'))})})},
 Session:{getActiveUser:()=>({getEmail:()=>sessionEmail})},
 PropertiesService:{getScriptProperties:()=>({getProperty:name=>name==='ADMIN_EMAILS'?'admin@example.com':null})},
 LockService:{getScriptLock:()=>({tryLock:()=>true,releaseLock:()=>true})},
 CacheService:{getScriptCache:()=>({get:k=>cache.get(k),put:(k,v)=>cache.set(k,v)})},
 Utilities:{getUuid:()=>(++counter).toString(16).padStart(8,'0')+'-0000-4000-8000-000000000000',
  computeDigest:(alg,str)=>Array.from(crypto.createHash('sha256').update(typeof str==='string'?str:Buffer.from(str)).digest()).map(x=>x>127?x-256:x),
  DigestAlgorithm:{SHA_256:'SHA256'},formatDate:(d,tz,fmt)=>{
    const iso=new Date(d).toISOString();return fmt==='yyyy-MM-dd'?iso.slice(0,10):iso.slice(0,19);
  }},
 DocumentApp:{ParagraphHeading:{HEADING1:'H1'},create:(title)=>{
  const id='DOC'+(++counter).toString().padStart(18,'0');let txt=[];docs[id]=txt;
  return{getId:()=>id,getUrl:()=>`https://docs.google.com/document/d/${id}/edit`,getBody:()=>({appendParagraph:t=>{txt.push(t);return{setHeading:()=>true}}}),saveAndClose:()=>true};
 }},
 HtmlService:{createHtmlOutputFromFile:()=>({setTitle:()=>({})})},
 console,Date,JSON,Number,Object,String,Array,Math,RegExp,Set,Error,isNaN
};
function context(src){const c=vm.createContext({...mocks});vm.runInContext(src,c);return c}
const pub=context(script('public/Code.gs')),admin=context(script('admin/Code.gs'));
const submit=pub.submitConsignment({sellerName:'สมชาย',sellerPhone:'0812345678',sellerRole:'เจ้าของกรรมสิทธิ์',district:'เขาค้อ',areaSqWah:920,askingPriceThb:3800000,desiredAgreementType:'ทั่วไป',proposedCommissionPct:3,titleDeedType:'โฉนด',privacyConsent:true});
assert.equal(db.rows('Sellers').length,1);assert.equal(db.rows('Consignments').length,1);
assert(submit.tracking_code.length>=32);
assert.equal(pub.getConsignmentStatus({consignmentId:submit.consignment_id,trackingCode:submit.tracking_code}).status,'submitted');
assert.throws(()=>pub.getConsignmentStatus({consignmentId:submit.consignment_id,trackingCode:'0'.repeat(32)}));
assert.equal(pub.getPublishedListings().length,0);
restricted=false;
assert.throws(()=>pub.submitConsignment({}),/ฐานข้อมูลยังเปิดแชร์สาธารณะ/);
assert.throws(()=>admin.adminBootstrap(),/SECURITY BLOCK/);
restricted=true;
sessionEmail='outsider@example.com';assert.throws(()=>admin.adminBootstrap(),/ไม่ได้รับสิทธิ์/);sessionEmail='admin@example.com';
const conId=submit.consignment_id;
admin.adminReviewConsignment({consignmentId:conId,decision:'approve',confirmed:true,note:'ตรวจสอบสำเนาโฉนดและเจ้าของแล้ว'});
assert.equal(db.rows('Consignments')[0].verification_status,'verified');
const agr=admin.adminCreateAgreement({consignmentId:conId,agreementType:'open',commissionType:'percentage',commissionRatePct:3,commissionFixedThb:0,startDate:'2026-11-16',endDate:'2027-05-16',triggerCondition:'เมื่อโอนกรรมสิทธิ์จริงตามสัญญา'});
assert(agr.draftUrl.includes('docs.google.com'));
assert.equal(db.rows('Agreements')[0].signature_status,'not_sent');
admin.adminRecordSignedAgreement({agreementId:agr.agreementId,signedPdfId:'PDF00000000000000000001',signedAt:'2026-11-16',confirmed:true});
const l=admin.adminCreateListing({consignmentId:conId,title:'ที่ดินสวยเขาค้อ',priceThb:3800000,rai:2,ngan:1,wah:20,purpose:'บ้านพัก',subdistrict:'แคมป์สน',description:'วิวภูเขา'});
assert.equal(db.rows('Listings').length,1);assert.equal(db.rows('Listings')[0].status,'draft');
admin.adminSetListingStatus({propertyId:l.propertyId,status:'published'});
assert.equal(pub.getPublishedListings().length,1);
const lead=pub.submitInquiry({propertyId:l.propertyId,customerName:'ลูกค้าทดสอบ',customerPhone:'0898765432',note:'นัดดูที่ดิน',privacyConsent:true});
assert.equal(db.rows('Leads').length,1);assert.equal(pub.getPublishedListings()[0].seller_id,undefined);
const agent1=admin.adminCreateAgent({name:'นายหน้าผู้ขาย',role:'listing_agent'}).id;
const agent2=admin.adminCreateAgent({name:'นายหน้าผู้ซื้อ',role:'buyer_agent'}).id;
const deal=admin.adminCreateDeal({propertyId:l.propertyId,leadId:lead.lead_id,closedPriceThb:4000000});
assert.throws(()=>admin.adminConfirmCommissionEarned({dealId:deal.dealId,evidenceDriveFileId:'PROOF000000000000001',confirmed:true,evidenceNote:'ตรวจสอบการโอนครบถ้วนแล้ว'}),/ต้องยืนยัน/);
const earned=admin.adminConfirmCommissionEarned({dealId:deal.dealId,evidenceDriveFileId:'PROOF000000000000001',confirmed:true,transferConfirmed:true,evidenceNote:'มีหลักฐานการจดทะเบียนโอนครบถ้วนแล้ว'});
assert.equal(earned.fee,120000);
assert.equal(db.rows('Listings')[0].status,'sold');
admin.adminCollectCommission({dealId:deal.dealId,amountThb:50000,paymentRef:'BANK-001'});
assert.throws(()=>admin.adminCollectCommission({dealId:deal.dealId,amountThb:50000,paymentRef:'BANK-001'}),/เคยบันทึก/);
assert.throws(()=>admin.adminApproveSplits({dealId:deal.dealId,items:[{agentId:agent1,splitPct:20},{agentId:agent2,splitPct:70}]}),/100%/);
const split=admin.adminApproveSplits({dealId:deal.dealId,items:[{agentId:agent1,splitPct:50},{agentId:agent2,splitPct:50}]});
assert.equal(split.total,120000);
let payouts=db.rows('Payouts');
assert.equal(payouts.length,2);
admin.adminApprovePayout({payoutId:payouts[0].payout_id});
assert.throws(()=>admin.adminPayPayout({payoutId:payouts[0].payout_id,withholdingTaxThb:0,paymentRef:'PAY-001'}),/ยอดจ่ายเกิน/);
admin.adminCollectCommission({dealId:deal.dealId,amountThb:70000,paymentRef:'BANK-002'});
admin.adminPayPayout({payoutId:payouts[0].payout_id,withholdingTaxThb:1800,paymentRef:'PAY-001'});
admin.adminApprovePayout({payoutId:payouts[1].payout_id});
admin.adminPayPayout({payoutId:payouts[1].payout_id,withholdingTaxThb:1800,paymentRef:'PAY-002'});
const balance=admin.adminReconcileDeal(deal.dealId);
assert.equal(balance.fee,120000);assert.equal(balance.receipts,120000);assert.equal(balance.allocated,120000);assert.equal(balance.paid,120000);assert.equal(balance.receiptDifference,0);assert.equal(balance.splitPercentage,100);
assert.equal(db.rows('AuditLog').length>=13,true);
const boot=admin.adminBootstrap();assert.equal(boot.counts.Listings,1);assert.equal(boot.counts.Payouts,2);
console.log('PASS end-to-end: seller intake → verify → signed PDF → published → lead → deal → transfer → collections → splits → payouts → reconciliation');
console.log('PASS security: public share block, admin allowlist, tracking token invalid');
console.log('PASS invariants: no pre-collection payout, split sum 100%, duplicate receipt rejected, public no PII');
