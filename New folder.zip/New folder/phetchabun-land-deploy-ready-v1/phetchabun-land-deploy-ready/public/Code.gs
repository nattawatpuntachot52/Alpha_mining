/**
 * PHETCHABUN LAND — PUBLIC GOOGLE APPS SCRIPT WEB APP
 * Deploy as: Execute as ME / Access ANYONE (anonymous).
 * NEVER paste admin code/functions into this public Apps Script project.
 * Property data: spreadsheet bound to ID below.
 * API surface: getPublishedListings, submitConsignment, submitInquiry.
 * 2026-11-15
 */
const PBL_SHEET_ID = '1idxj5laI7Y4bdhTdDvpD63ernjRaEP34CitpOi8mFgo';
const PBL_DISTRICTS = ['เมืองเพชรบูรณ์','ชนแดน','หล่มสัก','หล่มเก่า','วิเชียรบุรี','ศรีเทพ','หนองไผ่','บึงสามพัน','น้ำหนาว','วังโป่ง','เขาค้อ'];

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('เพชรบูรณ์ แลนด์ | ค้นหาและฝากขายที่ดิน');
}

function pblSheet_(name) {
  const sh = SpreadsheetApp.openById(PBL_SHEET_ID).getSheetByName(name);
  if (!sh) throw new Error('Database schema missing: '+name);
  return sh;
}
function pblRead_(name, maximum) {
  const s=pblSheet_(name), n=s.getLastRow();
  if(n<2)return [];
  if(n-1>maximum)throw new Error('Dataset exceeds public limit: '+name);
  const data=s.getRange(1,1,n,s.getLastColumn()).getValues();
  const heads=data.shift().map(String);
  return data.map(row=>Object.fromEntries(heads.map((key,i)=>[key,row[i]])))
    .filter(x=>Object.values(x).some(v=>v!==''));
}
function pblTxt_(v,max,required) {
  const text=String(v==null?'':v).trim();
  if((required&&!text)||text.length>max||/^[=+@\-]/.test(text)||/[\x00-\x1F\x7F]/.test(text))
    throw new Error('กรุณาตรวจสอบข้อมูลที่กรอก');
  return text;
}
function pblPhone_(v){
  const s=String(v==null?'':v).trim().replace(/[\s()-]/g,'');
  if(!/^(?:0\d{8,9}|\+66\d{8,9})$/.test(s))throw new Error('เบอร์โทรศัพท์ไม่ถูกต้อง');
  return s[0]==='+'?'0'+s.slice(3):s;
}
function pblNum_(v,min,max){
  if(v===''||v==null)throw new Error('กรุณากรอกตัวเลขให้ครบ');
  const x=Number(v);
  if(!Number.isFinite(x)||x<min||x>max)throw new Error('ตัวเลขอยู่นอกช่วงที่อนุญาต');
  return x;
}
function pblKey_(prefix){return prefix+'-'+Utilities.getUuid().replace(/-/g,'').slice(0,12).toUpperCase();}
function pblHash_(str){
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(str))
    .map(v=>('0'+((v+256)%256).toString(16)).slice(-2)).join('');
}
function pblSafeWrite_(){
  // Absolutely deny saving PII while the database is linked to Everyone / domain members.
  if(DriveApp.getFileById(PBL_SHEET_ID).getSharingAccess()!==DriveApp.Access.PRIVATE)
    throw new Error('ฐานข้อมูลยังเปิดแชร์สาธารณะ: กรุณาเปลี่ยน Share → General access → Restricted ก่อนรับข้อมูล');
}
function pblThrottle_(kind,phone){
  const digest=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,kind+phone)
    .map(v=>(v+256)%256).map(v=>v.toString(16).padStart(2,'0')).join('');
  const cache=CacheService.getScriptCache(),key='intake-'+digest;
  if(cache.get(key))throw new Error('เพิ่งได้รับคำขอนี้แล้ว กรุณารอสักครู่ก่อนส่งอีกครั้ง');
  cache.put(key,'1',90);
}
function pblAppend_(sheetName,data){
  const sh=pblSheet_(sheetName);
  const hdr=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String);
  Object.keys(data).forEach(k=>{if(hdr.indexOf(k)<0)throw new Error('Missing schema field: '+sheetName+'.'+k);});
  sh.appendRow(hdr.map(k=>data[k]===undefined?'':data[k]));
}
function pblAudit_(entity,id,action){
  pblAppend_('AuditLog',{event_id:pblKey_('EVT'),occurred_at:new Date(),actor_id:'public-web',action,entity_type:entity,entity_id:id,source:'public-web'});
}
/** PUBLIC: never returns private seller/contact/agreements/commission fields. */
function getPublishedListings(){
  const photos={};
  pblRead_('Images',15000).filter(im=>im.approved_public===true).forEach(im=>{
    const url=String(im.image_url||'');
    if(!/^https:\/\/[^\s"'<>]+$/i.test(url))return;
    const key=String(im.property_id||'');
    if(key&&(!photos[key]||im.is_cover===true))photos[key]=url;
  });
  const rows=pblRead_('Listings',20000);
  return rows.filter(p=>p.status==='published'&&Number(p.price_thb)>0&&/^[A-Za-z0-9-]{3,64}$/.test(String(p.property_id)))
   .map((p,i)=>({
    id:String(p.property_id),title:String(p.title||'').slice(0,150),
    district:String(p.district||'').slice(0,80),
    subdistrict:String(p.subdistrict||'').slice(0,80),
    purpose:String(p.purpose||'').slice(0,80),
    rai:Number(p.rai)||0,ngan:Number(p.ngan)||0,wah:Number(p.wah)||0,
    price:Number(p.price_thb),road:String(p.road_access||'').slice(0,250),
    features:String(p.description||'').slice(0,900),palette:i%6,
    cover_url:photos[String(p.property_id)]||'',
    latitude:Number(p.latitude_public)||null,longitude:Number(p.longitude_public)||null,
    location_precision:String(p.location_precision||'approximate')
   }));
}
/** PUBLIC intake. Creates private seller + consignment request, never a listing/contract. */
function submitConsignment(f){
  pblSafeWrite_();
  if(!f||typeof f!=='object'||f.privacyConsent!==true||f.companyWebsite)throw new Error('กรุณากรอกแบบฟอร์มให้ครบ');
  const input={
    name:pblTxt_(f.sellerName,120,true),phone:pblPhone_(f.sellerPhone),
    role:pblTxt_(f.sellerRole,100,true),district:pblTxt_(f.district,80,true),
    deed:pblTxt_(f.titleDeedType,100,true),type:pblTxt_(f.desiredAgreementType,120,true),
    area:pblNum_(f.areaSqWah,1,100000000),price:pblNum_(f.askingPriceThb,1,1e12),
    pct:pblNum_(f.proposedCommissionPct,0,100)
  };
  if(!PBL_DISTRICTS.includes(input.district))throw new Error('กรุณาเลือกอำเภอในจังหวัดเพชรบูรณ์');
  const lock=LockService.getScriptLock();
  if(!lock.tryLock(12000))throw new Error('ระบบมีคำขอจำนวนมาก กรุณาลองอีกครั้ง');
  let sellerRow=null,sellerId='';
  try{
    pblThrottle_('seller',input.phone);
    const now=new Date(),conId=pblKey_('CON');sellerId=pblKey_('SEL');
    const trackingCode=Utilities.getUuid().replace(/-/g,'').toUpperCase();
    const s=pblSheet_('Sellers');
    pblAppend_('Sellers',{seller_id:sellerId,full_name:input.name,phone:input.phone,
      identity_verification_status:'unverified',seller_status:'new',created_at:now,updated_at:now,
      consent_at:now,submission_role:input.role,privacy_notice_version:"2026-11-v1"});
    sellerRow=s.getLastRow();
    pblAppend_('Consignments',{consignment_id:conId,seller_id:sellerId,submitted_at:now,
      asking_price_thb:input.price,status:'submitted',verification_status:'unverified',
      district:input.district,area_sq_wah:input.area,seller_role:input.role,
      title_deed_type:input.deed,desired_agreement_type:input.type,
      proposed_commission_pct:input.pct,consent_at:now,source:'website',
      tracking_token_hash:pblHash_(trackingCode),privacy_notice_version:'2026-11-v1'});
    try{pblAudit_('Consignments',conId,'submit_request');}catch(logError){console.error('AuditLog failed',logError);}
    return{ok:true,consignment_id:conId,tracking_code:trackingCode};
  }catch(err){
    // Best-effort rollback only if consignment was not written.
    if(sellerRow&&!pblRead_('Consignments',20000).some(c=>c.seller_id===sellerId)){
      try{const s=pblSheet_('Sellers');if(s.getRange(sellerRow,1).getValue()===sellerId)s.deleteRow(sellerRow);}catch(e){}
    }
    throw err;
  }finally{lock.releaseLock();}
}
/** PUBLIC inquiry: write a lead only. Must reference a currently published listing. */
function submitInquiry(f){
  pblSafeWrite_();
  if(!f||typeof f!=='object'||f.privacyConsent!==true||f.companyWebsite)throw new Error('กรุณารับทราบนโยบายข้อมูลส่วนบุคคล');
  const propertyId=pblTxt_(f.propertyId,64,true),name=pblTxt_(f.customerName,120,true),
    phone=pblPhone_(f.customerPhone),note=pblTxt_(f.note||'',700,false);
  if(!getPublishedListings().some(p=>p.id===propertyId))throw new Error('ประกาศนี้ไม่ได้เปิดรับการติดต่อแล้ว');
  const lock=LockService.getScriptLock();
  if(!lock.tryLock(12000))throw new Error('ระบบมีคำขอจำนวนมาก กรุณาลองอีกครั้ง');
  try{
    pblThrottle_('lead-'+propertyId,phone);
    const id=pblKey_('LEAD'),now=new Date();
    pblAppend_('Leads',{lead_id:id,property_id:propertyId,customer_name:name,
      customer_phone:phone,source:'website',lead_status:'new',submitted_at:now,
      consent_at:now,notes_private:note});
    try{pblAudit_('Leads',id,'submit_inquiry');}catch(logError){console.error('AuditLog failed',logError);}
    return{ok:true,lead_id:id};
  }finally{lock.releaseLock();}
}

/** Public status check: high-entropy one-time secret, returns NO PII. */
function getConsignmentStatus(f){
  if(!f||typeof f!=='object')throw new Error('ข้อมูลตรวจสอบไม่ถูกต้อง');
  const id=String(f.consignmentId||'').trim(),code=String(f.trackingCode||'').trim().toUpperCase();
  if(!/^CON-[A-Z0-9]{12}$/.test(id)||!/^[A-F0-9]{32}$/.test(code))
    throw new Error('เลขที่คำขอหรือรหัสติดตามไม่ถูกต้อง');
  const row=pblRead_('Consignments',20000).find(r=>String(r.consignment_id)===id);
  if(!row||pblHash_(code)!==String(row.tracking_token_hash||''))
    throw new Error('เลขที่คำขอหรือรหัสติดตามไม่ถูกต้อง');
  return{consignment_id:id,status:String(row.status||'submitted'),
    verification_status:String(row.verification_status||'unverified'),
    property_id:String(row.property_id||''),checked_at:new Date().toISOString()};
}
