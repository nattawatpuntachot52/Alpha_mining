import os
import io
import re
import tempfile
import urllib.parse
import datetime as dt
from pathlib import Path
from typing import Dict, Any, List, Optional
import requests
import pandas as pd
import openpyxl
from app.config import EXCEL_PATH, GOOGLE_SHEET_XLSX_URL

# Default Pre-curated Geopolitical & Macro Scenarios (Fallback if tab not created yet)
DEFAULT_GEO_SCENARIOS: List[Dict[str, Any]] = [
    {
        "id": "hormuz",
        "name": "ช่องแคบฮอร์มุซ & ตะวันออกกลาง (Strait of Hormuz)",
        "region": "Middle East",
        "severity": 5,
        "tension_level": "วิกฤติตึงเครียดระดับสูงสุด (Critical Tension)",
        "event_a": "กองกำลังในภูมิภาคประกาศปิดกั้นช่องแคบฮอร์มุซ หรือเปิดฉากโจมตีเรือบรรทุกน้ำมันและโรงกลั่นพลังงานขนาดใหญ่",
        "energy_impact": "ราคาน้ำมันดิบ Brent และ WTI พุ่งทะลุ $105 - $120/บาร์เรล ต้นทุนค่าระวางเรือพาณิชย์และเบี้ยประกันความเสี่ยงสงครามพุ่ง 250%",
        "inflation_impact": "เงินเฟ้อทั่วไป (Headline Inflation) โลกดีดกลับฉับพลัน ธนาคารกลางสหรัฐ (Fed) และ ECB จำเป็นต้องชะลอการปรับลดอัตราดอกเบี้ย",
        "equities_impact": "ภาวะ Risk-off ฉับพลัน ตลาดหุ้นโลกปรับฐาน -5% ถึง -10% กลุ่มสายการบิน ขนส่ง ยานยนต์ และค้าปลีกเผชิญแรงเทขายรุนแรง",
        "safe_haven_impact": "เงินทุนแห่เข้าพักในสินทรัพย์ปลอดภัย ดัชนีดอลลาร์ (DXY) แข็งค่า ทองคำ (Gold) พุ่งสร้างสถิติ All-Time High ใหม่",
        "action_cash_pct": "25-30%",
        "action_portfolio": "ขยับสัดส่วนถือเงินสด (Cash/USD) และพันธบัตรรัฐบาลระยะสั้นขึ้นเป็น 25-30% เพื่อลดความผันผวนของพอร์ตหลัก",
        "action_hedge": "เปิดสถานะ Long สัญญาน้ำมันดิบ / กองทุนพลังงานต้นน้ำ (Energy Equities) ควบคู่กับถือทองคำแท่ง/Gold ETF เป็นเกราะกำบัง",
        "action_supply_chain": "เร่งสำรองสต็อกเชื้อเพลิง วางแผนสัญญาจัดซื้อล่วงหน้า และเปลี่ยนเส้นทางขนส่งทางบกหรือเลี่ยงเข้าท่าเรือสำรอง",
        "action_crypto": "ระวังแรงเทขายช่วงแรกจากภาวะขาดสภาพคล่อง (Liquidity Crunch) แล้วรอตั้งรับสะสม Bitcoin ในช่วงราคาสร้างฐาน",
        "event_b": "สหรัฐฯ และพันธมิตรจัดตั้งกองเรือคุ้มกันสำเร็จ และเปิดช่องทางการทูตเพื่อเจรจาหยุดยิง",
        "deescalation_impact": "ราคาน้ำมันดิบทิ้งตัวลงสู่ $72 - $76/บาร์เรล ตลาดหุ้นเกิด Relief Rally",
        "last_updated": "2026-10-31"
    },
    {
        "id": "taiwan",
        "name": "ช่องแคบไต้หวัน & ทะเลจีนใต้ (Taiwan Strait & East Asia)",
        "region": "East Asia",
        "severity": 5,
        "tension_level": "จุดเปราะบางเซมิคอนดักเตอร์โลก (Semiconductor Chokepoint)",
        "event_a": "การปิดล้อมทางทะเลหรือการซ้อมรบทางอากาศรอบเกาะไต้หวัน กระทบต่อการขนส่งชิปเซมิคอนดักเตอร์ขั้นสูง",
        "energy_impact": "เส้นทางเดินเรือพาณิชย์ในเอเชียตะวันออกต้องเปลี่ยนทิศทาง ต้นทุนโลจิสติกส์เอเชียพุ่งสูง",
        "inflation_impact": "วิกฤตขาดแคลนชิปทั่วโลกส่งผลให้ราคาสินค้าอิเล็กทรอนิกส์ ยานยนต์ และคอมพิวเตอร์พุ่งสูงทันที",
        "equities_impact": "หุ้นกลุ่มเซมิคอนดักเตอร์และบิ๊กเทค (Nvidia, Apple, TSMC, AMD) ดิ่งลงฉับพลัน ฉุดตลาดหุ้นทั่วโลก",
        "safe_haven_impact": "ทองคำและพันธบัตรรัฐบาลสหรัฐฯ พุ่งสูง ขณะที่สกุลเงินเอเชีย (TWD, KRW, JPY) เผชิญแรงกดดันอ่อนค่า",
        "action_cash_pct": "30%",
        "action_portfolio": "ตั้งจุดตัดขาดทุน (Stop-Loss) ในหุ้นเทคโนโลยีที่มีความเปราะบางต่อซัพพลายเชนชิป",
        "action_hedge": "กระจายการลงทุนสู่ผู้ผลิตชิปนอกไต้หวัน (เช่น Intel, Samsung) และถือทองคำเป็นสินทรัพย์คุ้มกัน",
        "action_supply_chain": "บริษัทเทคโนโลยีต้องเร่งกระจายกำลังการผลิตและการสำรองสินค้าสำเร็จรูป",
        "action_crypto": "จับตาโทเคนกลุ่ม AI และโครงสร้างพื้นฐานกระจายศูนย์",
        "event_b": "การลดระดับการซ้อมรบและการเจรจาระหว่างสหรัฐฯ และจีน",
        "deescalation_impact": "หุ้นกลุ่มเซมิคอนดักเตอร์ดีดตัวกลับอย่างรวดเร็ว",
        "last_updated": "2026-10-31"
    },
    {
        "id": "redsea",
        "name": "ทะเลแดง & ช่องแคบบับเอลมันเดบ (Red Sea & Suez Corridor)",
        "region": "Red Sea",
        "severity": 4,
        "tension_level": "เส้นทางขนส่งทางทะเลหยุดชะงัก (Maritime Disruption)",
        "event_a": "การโจมตีเรือพาณิชย์ระลอกใหม่ในทะเลแดง บังคับให้กองเรือขนส่งสินค้าทั่วโลกต้องเดินทางอ้อมแหลมกู๊ดโฮปต่อเนื่อง",
        "energy_impact": "ระยะเวลาขนส่งสินค้าระหว่างเอเชียและยุโรปเพิ่มขึ้น 10-14 วัน เพิ่มการบริโภคน้ำมันเชื้อเพลิงเรือเดินสมุทร",
        "inflation_impact": "ค่าระวางตู้คอนเทนเนอร์ (Container Freight Rate) พุ่งขึ้น 150-200% ดันราคาสินค้านำเข้าในยุโรป",
        "equities_impact": "หุ้นกลุ่มเดินเรือตู้คอนเทนเนอร์มีรายได้ค่าระวางพุ่งขึ้น ขณะที่กลุ่มค้าปลีกและยานยนต์เผชิญปัญหาสินค้าล่าช้า",
        "safe_haven_impact": "เงินดอลลาร์สหรัฐแข็งค่าในฐานะสกุลเงินหลักที่ใช้ชำระค่าระวางและพลังงาน",
        "action_cash_pct": "20%",
        "action_portfolio": "เลือกลงทุนในหุ้นกลุ่มเดินเรือและโลจิสติกส์ที่ได้ประโยชน์จากค่าระวางสูง",
        "action_hedge": "ป้องกันความเสี่ยงด้านเวลาด้วยการเพิ่มสินค้าคงคลังสำรอง (Safety Stock) 1-2 เดือน",
        "action_supply_chain": "ทำสัญญาจองระวางเรือล่วงหน้าและพิจารณาทางเลือกการขนส่งผสมทางบก/อากาศ",
        "action_crypto": "ติดตามการชำระเงินข้ามแดนและโซลูชันด้านการค้า",
        "event_b": "กองเรือพันธมิตรควบคุมความปลอดภัยเส้นทางเดินเรือทะเลแดงได้สำเร็จ",
        "deescalation_impact": "ค่าระวางเรือตู้คอนเทนเนอร์ปรับตัวลดลงสู่ระดับปกติ",
        "last_updated": "2026-10-31"
    },
    {
        "id": "ukraine",
        "name": "ยูเครน & ยุโรปตะวันออก (Eastern Europe Frontline)",
        "region": "Eastern Europe",
        "severity": 4,
        "tension_level": "สงครามยืดเยื้อและมาตรการคว่ำบาตร (Active War Zone)",
        "event_a": "การยกระดับการโจมตีโครงสร้างพื้นฐานพลังงานในยุโรปตะวันออก และการเพิ่มมาตรการคว่ำบาตรต่อชาติพันธมิตร",
        "energy_impact": "ราคาก๊าซธรรมชาติในยุโรป (Dutch TTF) ดีดตัวขึ้น กระทบต้นทุนค่าไฟฟ้าและภาคอุตสาหกรรมหนักในเยอรมนี/ฝรั่งเศส",
        "inflation_impact": "Core Inflation ของยูโรโซนทรงตัวในระดับสูง กดดันให้ ECB ต้องคงอัตราดอกเบี้ยเป็นเวลานานขึ้น",
        "equities_impact": "หุ้นภาคการผลิตและเคมีภัณฑ์ในยุโรปเผชิญแรงกดดันด้านอัตรากำไร ขณะที่หุ้นกลุ่มอุตสาหกรรมป้องกันประเทศ (Defense) พุ่งขึ้น",
        "safe_haven_impact": "เงินยูโร (EUR) อ่อนค่าเมื่อเทียบกับดอลลาร์สหรัฐ",
        "action_cash_pct": "20%",
        "action_portfolio": "ลดน้ำหนักหุ้นยุโรปกลุ่ม Cyclical และเพิ่มการลงทุนในกลุ่ม Defense & European Utilities",
        "action_hedge": "ถือสัญญา Long European Natural Gas หรือสเปรดราคาก๊าซ",
        "action_supply_chain": "กระจายแหล่งจัดซื้อก๊าซธรรมชาติเหลว (LNG) จากสหรัฐฯ และกาตาร์",
        "action_crypto": "จับตาธุรกรรมการโอนเงินและความช่วยเหลือข้ามพรมแดน",
        "event_b": "การเปิดโต๊ะเจรจาข้อตกลงพลังงานและทางออกทางการทูต",
        "deescalation_impact": "ราคาก๊าซธรรมชาติยุโรปปรับตัวลดลง",
        "last_updated": "2026-10-31"
    },
    {
        "id": "lithium",
        "name": "สามเหลี่ยมลิเธียม อาร์เจนตินา (Lithium Basin Argentina)",
        "region": "Latin America",
        "severity": 2,
        "tension_level": "ยุทธศาสตร์แร่หายาก & พลังงานสะอาด (Strategic Resource)",
        "event_a": "การขยายตัวของการลงทุน $1.18 พันล้านเหรียญในอาร์เจนตินา ท่ามกลางการแข่งขันชิงซัพพลายเชนแร่พลังงานสะอาด",
        "energy_impact": "เพิ่มเสถียรภาพอุปทานลิเธียมคาร์บอเนตสำหรับอุตสาหกรรมยานยนต์ไฟฟ้าและระบบกักเก็บพลังงาน (BESS) ทั่วโลก",
        "inflation_impact": "ช่วยกดดันต้นทุนการผลิตแบตเตอรี่ EV ในระยะกลาง-ยาวให้ลดลง ส่งเสริมเป้าหมายการเปลี่ยนผ่านพลังงานสะอาด",
        "equities_impact": "หุ้นกลุ่มเหมืองแร่ยักษ์ใหญ่ (Rio Tinto, Albemarle, SQM) ได้รับอานิสงส์เชิงบวกและดึงดูดเม็ดเงินลงทุนสถาบัน",
        "safe_haven_impact": "ค่าเงินและดุลบัญชีเดินสะพัดของอาร์เจนตินาได้รับแรงหนุนจากเม็ดเงินลงทุนโดยตรงจากต่างประเทศ (FDI)",
        "action_cash_pct": "15%",
        "action_portfolio": "กระจายการลงทุนเข้าสู่ห่วงโซ่อุตสาหกรรมแร่พลังงานและวัสดุสำหรับเทคโนโลยีอนาคต",
        "action_hedge": "ติดตามความเสี่ยงด้านนโยบายสัมปทานแร่และภาษีส่งออกของรัฐบาลท้องถิ่น",
        "action_supply_chain": "ผู้ผลิตแบตเตอรี่ควรเร่งทำสัญญาซื้อขายระยะยาว (Offtake Agreement) เพื่อการันตีวัตถุดิบ",
        "action_crypto": "เชื่อมโยงสู่โทเคนกลุ่ม Real-World Asset (RWA) ที่อิงกับทรัพยากรธรรมชาติ",
        "event_b": "การขยายโรงกลั่นลิเธียมเพิ่มขึ้นและข้อตกลงส่งมอบแร่ระยะยาว",
        "deescalation_impact": "ราคาต้นทุนแบตเตอรี่ EV ลดลงอย่างมีเสถียรภาพ",
        "last_updated": "2026-10-31"
    },
    {
        "id": "fed",
        "name": "ธนาคารกลางสหรัฐฯ วอชิงตัน ดี.ซี. (Federal Reserve & US Policy)",
        "region": "North America",
        "severity": 3,
        "tension_level": "ศูนย์กลางนโยบายการเงินโลก (Global Monetary Core)",
        "event_a": "ธนาคารกลางสหรัฐฯ ส่งสัญญาณคงอัตราดอกเบี้ยสูงยาวนานขึ้น (Higher-for-Longer) จากความเสี่ยงเงินเฟ้อสงคราม",
        "energy_impact": "ราคาสินค้าโภคภัณฑ์ในรูปดอลลาร์เผชิญแรงกดดันจากต้นทุนการกู้ยืมที่สูงขึ้น",
        "inflation_impact": "อัตราผลตอบแทนพันธบัตรรัฐบาลสหรัฐฯ 10 ปี (US 10Y Yield) ดีดตัวขึ้นสู่ 4.5%+",
        "equities_impact": "หุ้นกลุ่ม Growth / Tech ที่ซื้อขายบน Valuation สูงเผชิญแรงกดดันปรับฐาน",
        "safe_haven_impact": "ดัชนีดอลลาร์ (DXY) ปรับตัวแข็งแกร่ง กระทบค่าเงินในตลาดเกิดใหม่ (EM Currencies)",
        "action_cash_pct": "25%",
        "action_portfolio": "ล็อกผลตอบแทนด้วยตราสารหนี้คุณภาพสูงระยะสั้น (Short-Duration T-Bills) ที่ให้ยีลด์ 4-5%",
        "action_hedge": "ลดสัดส่วนหนี้สินและงดเว้นการใช้ Margin ในการลงทุน",
        "action_supply_chain": "บริหารจัดการกระแสเงินสดและป้องกันความเสี่ยงจากอัตราแลกเปลี่ยน (FX Hedging)",
        "action_crypto": "จับตาระดับ Liquidity ของเงินดอลลาร์ รอจังหวะสะสมเมื่อแนวโน้มดอกเบี้ยเริ่มถึงจุดสูงสุดชัดเจน",
        "event_b": "ตัวเลขเงินเฟ้อผ่อนคลายและ Fed เริ่มเปิดทางปรับลดอัตราดอกเบี้ย",
        "deescalation_impact": "สินทรัพย์เสี่ยงและตลาดหุ้นเกิด Relief Rally",
        "last_updated": "2026-10-31"
    },
    {
        "id": "ecb",
        "name": "ธนาคารกลางยุโรป แฟรงก์เฟิร์ต (European Central Bank)",
        "region": "Europe",
        "severity": 3,
        "tension_level": "นโยบายเศรษฐกิจยุโรป (European Macro Policy)",
        "event_a": "ภาวะเศรษฐกิจชะลอตัวในยูโรโซนบีบให้ ECB ต้องปรับลดดอกเบี้ยสวนทางกับแรงกดดันเงินเฟ้อด้านพลังงาน",
        "energy_impact": "ค่าเงินยูโรอ่อนค่าลงซ้ำเติมต้นทุนการนำเข้าน้ำมันและก๊าซธรรมชาติ",
        "inflation_impact": "ภาวะ Stagflation อ่อนๆ ในกลุ่มประเทศอุตสาหกรรมยุโรป",
        "equities_impact": "ตลาดหุ้นยุโรปผันผวน กลุ่มธนาคารเผชิญส่วนต่างดอกเบี้ยที่ลดลง",
        "safe_haven_impact": "เงินทุนโยกย้ายข้ามฝั่งไปยังตลาดทุนสหรัฐฯ",
        "action_cash_pct": "20%",
        "action_portfolio": "กระจายความเสี่ยงออกนอกตลาดยุโรป มุ่งเน้นสินทรัพย์ที่มีรายได้สกุลดอลลาร์เป็นหลัก",
        "action_hedge": "เปิดสถานะป้องกันความเสี่ยงค่าเงินยูโร (Hedge EUR)",
        "action_supply_chain": "ประเมินผลกระทบต้นทุนพลังงานในฐานการผลิตยุโรป",
        "action_crypto": "ติดตามการกำกับดูแลสินทรัพย์ดิจิทัลตามกรอบ MiCA",
        "event_b": "เศรษฐกิจยุโรปฟื้นตัวและเงินเฟ้อพลังงานลดลง",
        "deescalation_impact": "ความเชื่อมั่นในตลาดยุโรปเริ่มฟื้นตัว",
        "last_updated": "2026-10-31"
    },
    {
        "id": "malacca",
        "name": "ช่องแคบมะละกา (Strait of Malacca, Southeast Asia)",
        "region": "Southeast Asia",
        "severity": 2,
        "tension_level": "เส้นทางเดินเรือเอเชีย (Asian Maritime Artery)",
        "event_a": "การซ้อมรบทางทะเลหรืออุบัติเหตุการชนในร่องน้ำแคบกระทบการสัญจรทางเรือของเอเชียตะวันออก",
        "energy_impact": "กระทบการนำเข้าน้ำมันดิบของจีนและญี่ปุ่น โรงกลั่นในเอเชียต้องดึงสต็อกสำรอง",
        "inflation_impact": "ค่าขนส่งและเบี้ยประกันเรือในเอเชียตะวันออกเฉียงใต้ปรับตัวขึ้น",
        "equities_impact": "หุ้นท่าเรือและโลจิสติกส์ในภูมิภาคเผชิญความล่าช้า",
        "safe_haven_impact": "เงินดอลลาร์สิงคโปร์ (SGD) และเยนญี่ปุ่นผันผวน",
        "action_cash_pct": "15%",
        "action_portfolio": "พิจารณาโครงสร้างพื้นฐานพลังงานทดแทนและท่าเรือสำรองในภูมิภาค",
        "action_hedge": "กระจายเส้นทางขนส่งสินค้าทางเรือ",
        "action_supply_chain": "สำรองน้ำมันเชื้อเพลิงและวัตถุดิบสำหรับโรงงานในอาเซียน",
        "action_crypto": "จับตาฮับสินทรัพย์ดิจิทัลในสิงคโปร์",
        "event_b": "การเปิดร่องน้ำเดินเรือเป็นปกติ",
        "deescalation_impact": "การจราจรทางเรือในช่องแคบมะละกากลับสู่ภาวะปกติ",
        "last_updated": "2026-10-31"
    }
]

class FactnewsParser:
    """
    Parser for Factnews real-time news data.
    Supports live fetching from Google Sheets with local Excel caching and offline fallback.
    Extracts real source hyperlinks from Excel =HYPERLINK() formulas.
    """

    def __init__(self, excel_path: Optional[Path] = None, google_sheet_url: str = GOOGLE_SHEET_XLSX_URL):
        self.excel_path = Path(excel_path) if excel_path else EXCEL_PATH
        self.google_sheet_url = google_sheet_url
        self.last_fetch_source = "Not loaded"
        self._last_live_success_at: Optional[str] = None

    def parse(self, prefer_live: bool = True) -> Dict[str, Any]:
        """Read validated live news, or explicitly identify the local fallback."""
        live_requested = prefer_live and bool(self.google_sheet_url)
        checked_at = None
        fetch_error = None
        if live_requested:
            checked_at = dt.datetime.now(dt.timezone.utc).isoformat()
            try:
                resp = requests.get(self.google_sheet_url, timeout=12)
                if resp.status_code != 200:
                    raise ValueError(f"Live feed returned HTTP {resp.status_code}")
                if not resp.content:
                    raise ValueError("Live feed returned an empty workbook")
                data = self._parse_excel_bytes(
                    resp.content, source="Live Realtime Feed", validate_live=True
                )
            except Exception as e:
                fetch_error = self._bounded_error(e)
                print(f"[Parser Warning] Live feed fetch failed: {fetch_error}. Falling back to local cache.")
            else:
                self._last_live_success_at = dt.datetime.now(dt.timezone.utc).isoformat()
                cache_write_error = None
                try:
                    self._save_cache(resp.content)
                except Exception as e:
                    cache_write_error = self._bounded_error(e)
                    print(f"[Parser Warning] Failed to save local cache: {cache_write_error}")
                self.last_fetch_source = "Live Realtime Feed"
                data["freshness"] = self._freshness(
                    "live", "degraded" if cache_write_error else "fresh",
                    checked_at, cache_write_error=cache_write_error
                )
                return data

        if not self.excel_path.exists():
            raise FileNotFoundError(f"Neither live feed nor local file found at: {self.excel_path}")
        with open(self.excel_path, "rb") as f_in:
            file_bytes = f_in.read()
        data = self._parse_excel_bytes(file_bytes, source="Local Database Cache")
        self.last_fetch_source = "Local Database (Cache)"
        data["freshness"] = self._freshness(
            "cache_fallback" if live_requested else "local",
            "stale" if live_requested else "local", checked_at, fetch_error=fetch_error
        )
        return data

    @staticmethod
    def _bounded_error(error: Exception) -> str:
        return " ".join(f"{type(error).__name__}: {error}".split())[:300]

    def _freshness(self, source_mode: str, status: str, checked_at: Optional[str],
                   fetch_error: Optional[str] = None,
                   cache_write_error: Optional[str] = None) -> Dict[str, Any]:
        try:
            cache_updated_at = dt.datetime.fromtimestamp(
                self.excel_path.stat().st_mtime, dt.timezone.utc
            ).isoformat()
        except OSError:
            cache_updated_at = None
        return {
            "source_mode": source_mode,
            "status": status,
            "stale": status == "stale",
            "checked_at": checked_at,
            "last_live_success_at": self._last_live_success_at,
            "cache_updated_at": cache_updated_at,
            "fetch_error": fetch_error,
            "cache_write_error": cache_write_error,
        }

    def _save_cache(self, excel_bytes: bytes):
        """Replace only after validation; leave the previous workbook on failure."""
        temporary_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb", dir=self.excel_path.parent,
                prefix=f".{self.excel_path.name}.", suffix=".tmp", delete=False
            ) as temporary:
                temporary_path = Path(temporary.name)
                temporary.write(excel_bytes)
                temporary.flush()
                os.fsync(temporary.fileno())
            os.replace(temporary_path, self.excel_path)
        finally:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)

    def _parse_excel_bytes(self, excel_bytes: bytes, source: str,
                           validate_live: bool = False) -> Dict[str, Any]:
        wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), data_only=False)
        sheet_name = "Factnews" if "Factnews" in wb.sheetnames else wb.sheetnames[0]
        sheet = wb[sheet_name]

        # Detect header row index (1-based)
        header_row_idx = 7
        header_found = False
        for r in range(1, 15):
            row_vals = [str(sheet.cell(row=r, column=c).value or '').lower() for c in range(1, 12)]
            row_str = " ".join(row_vals)
            if "description" in row_str and "category" in row_str:
                header_row_idx = r
                header_found = True
                break
        if validate_live and not header_found:
            raise ValueError("Live workbook is missing Description/Category headers")

        headers = [str(sheet.cell(row=header_row_idx, column=c).value or '').strip() for c in range(1, sheet.max_column + 1)]
        col_map = {name: idx + 1 for idx, name in enumerate(headers) if name}

        date_col = col_map.get("Date", 1)
        cat_col = col_map.get("Category", 2)
        desc_col = col_map.get("Description", 3)
        prov_col = col_map.get("Provider", 4)
        src_col = col_map.get("Source link", 5)
        pub_col = col_map.get("Published at", 6)

        hyperlink_pattern = re.compile(r'HYPERLINK\s*\(\s*"(https?://[^"]+)"\s*(?:,\s*"([^"]*)")?\s*\)', re.IGNORECASE)

        known_domains = {
            'thai pbs': 'https://www.thaipbs.or.th/news',
            'coindesk': 'https://www.coindesk.com',
            'the guardian': 'https://www.theguardian.com/business',
            'the guardian business': 'https://www.theguardian.com/business',
            'cnbc': 'https://www.cnbc.com/world/',
            'bbc': 'https://www.bbc.com/news',
            'the standard wealth': 'https://thestandard.co/wealth/'
        }

        events: List[Dict[str, Any]] = []
        for r in range(header_row_idx + 1, sheet.max_row + 1):
            raw_desc = str(sheet.cell(row=r, column=desc_col).value or '').strip()
            if not raw_desc or raw_desc in ('None', 'nan'):
                continue

            lines = [line.strip() for line in raw_desc.split("\n") if line.strip()]
            title = lines[0] if lines else "ไม่มีหัวข้อข่าว"
            summary = lines[1] if len(lines) > 1 else ""
            details = " ".join(lines[2:]) if len(lines) > 2 else ""

            category = str(sheet.cell(row=r, column=cat_col).value or 'ทั่วไป').strip()
            if category in ('None', 'nan', ''):
                category = 'ทั่วไป'

            provider = str(sheet.cell(row=r, column=prov_col).value or 'Factnews AI').strip()
            if provider in ('None', 'nan', ''):
                provider = 'Factnews AI'

            # Extract real hyperlink formula or target
            src_cell = sheet.cell(row=r, column=src_col)
            raw_src_val = str(src_cell.value or '').strip()

            source_url = None
            source_name = None

            m = hyperlink_pattern.search(raw_src_val)
            if m:
                source_url = m.group(1).strip()
                source_name = m.group(2).strip() if m.group(2) else source_url
            elif src_cell.hyperlink and src_cell.hyperlink.target:
                source_url = src_cell.hyperlink.target.strip()
                source_name = raw_src_val if raw_src_val not in ('None', 'nan', '') else source_url
            elif raw_src_val.startswith('http://') or raw_src_val.startswith('https://'):
                source_url = raw_src_val
                source_name = raw_src_val
            elif raw_src_val and raw_src_val not in ('None', 'nan'):
                source_name = raw_src_val
                clean_name_key = source_name.lower().strip()
                if clean_name_key in known_domains:
                    source_url = known_domains[clean_name_key]
                else:
                    source_url = f"https://www.google.com/search?q={urllib.parse.quote(title + ' ' + source_name)}"
            else:
                source_name = provider or 'Factnews AI'
                source_url = f"https://www.google.com/search?q={urllib.parse.quote(title)}"

            pub_val = sheet.cell(row=r, column=pub_col).value
            date_val = sheet.cell(row=r, column=date_col).value
            pub_dt = self._parse_datetime(pub_val, date_val)

            iso_time = pub_dt.strftime("%Y-%m-%dT%H:%M:%S+07:00") if pub_dt else ""
            timestamp_ms = int(pub_dt.timestamp() * 1000) if pub_dt else 0

            events.append({
                "id": f"evt-{len(events) + 1:04d}",
                "title": title,
                "summary": summary,
                "details": details,
                "category": category,
                "provider": provider,
                "source_name": source_name,
                "source_url": source_url,
                "source_link": source_url,
                "published_at": iso_time,
                "timestamp": timestamp_ms,
                "display_time": pub_dt.strftime("%d/%m/%Y %H:%M") if pub_dt else ""
            })

        if validate_live and not events:
            raise ValueError("Live workbook contains no news events")

        # Sort chronologically
        events.sort(key=lambda x: x["timestamp"])

        category_counts: Dict[str, int] = {}
        for ev in events:
            c = ev["category"]
            category_counts[c] = category_counts.get(c, 0) + 1

        now_str = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Parse Geopolitical Scenarios Tab (Live from Google Sheets or Fallback)
        geo_scenarios = self._parse_geo_scenarios(wb)

        return {
            "status": "success",
            "source": source,
            "total_count": len(events),
            "file_name": self.excel_path.name,
            "last_sync_time": now_str,
            "category_counts": category_counts,
            "min_timestamp": events[0]["timestamp"] if events else 0,
            "max_timestamp": events[-1]["timestamp"] if events else 0,
            "events": events,
            "geo_scenarios": geo_scenarios
        }

    def _parse_scenario_table(self, wb: openpyxl.Workbook, sheet_name: str, required: List[str]) -> List[Dict[str, str]]:
        if sheet_name not in wb.sheetnames:
            return []
        ws = wb[sheet_name]
        if ws.max_row < 2:
            return []
        header_row = -1
        col_map: Dict[str, int] = {}
        for r in range(1, min(11, ws.max_row + 1)):
            names = {
                str(ws.cell(row=r, column=c).value or "").strip().lower(): c
                for c in range(1, min(33, ws.max_column + 1))
            }
            if all(k in names for k in required):
                header_row = r
                col_map = {k: names[k] for k in required}
                break
        if header_row < 0:
            return []
        rows: List[Dict[str, str]] = []
        for r in range(header_row + 1, ws.max_row + 1):
            row_dict: Dict[str, str] = {}
            for key in required:
                cell = ws.cell(row=r, column=col_map[key])
                val = cell.value
                if isinstance(val, dt.datetime) and key.endswith("_ict"):
                    day_str = val.strftime("%Y-%m-%d")
                    val_str = day_str if key in ("date_ict", "window_start_ict") else val.strftime("%Y-%m-%dT%H:%M:%S+07:00")
                elif isinstance(val, dt.date) and key.endswith("_ict"):
                    val_str = val.strftime("%Y-%m-%d")
                elif val is None or str(val).strip() in ("None", "nan"):
                    val_str = ""
                else:
                    val_str = str(val).strip()
                if key == "canonical_url" and cell.hyperlink and cell.hyperlink.target:
                    val_str = str(cell.hyperlink.target).strip()
                if key == "canonical_url" and not (val_str.startswith("https://") or val_str.startswith("http://")):
                    val_str = ""
                row_dict[key] = val_str
            if row_dict.get(required[0]):
                rows.append(row_dict)
        return rows

    def _parse_geo_scenarios(self, wb: openpyxl.Workbook) -> List[Dict[str, Any]]:
        """
        Parses Scenario_Daily + Scenario_Analysis + Scenario_Evidence if present,
        otherwise parses Geo_Scenarios tab or falls back to DEFAULT_GEO_SCENARIOS.
        """
        if "Scenario_Daily" in wb.sheetnames:
            try:
                daily = [
                    row for row in self._parse_scenario_table(wb, "Scenario_Daily", [
                        "review_id", "date_ict", "zone_id", "zone_th", "window_start_ict", "cutoff_at_ict",
                        "decision", "analysis_id", "carry_from_analysis_id", "decision_reason_th",
                        "coverage_state", "source_timing_state", "prepared_at_ict"
                    ])
                    if re.match(r"^\d{4}-\d{2}-\d{2}$", row["date_ict"]) and row["cutoff_at_ict"].startswith(row["date_ict"] + "T")
                ]
                def unique_by(items: List[Dict[str, str]], key: str) -> Dict[str, Optional[Dict[str, str]]]:
                    out: Dict[str, Optional[Dict[str, str]]] = {}
                    for item in items:
                        k = item[key]
                        out[k] = None if k in out else item
                    return out

                analysis = unique_by(self._parse_scenario_table(wb, "Scenario_Analysis", [
                    "analysis_id", "review_id", "date_ict", "zone_id", "headline_th", "confirmed_facts_th",
                    "why_new_th", "escalation_trigger_th", "escalation_if_then_th", "deescalation_trigger_th",
                    "deescalation_if_then_th", "watch_indicators_th", "confidence", "limitations_th",
                    "prepared_at_ict", "evidence_ids"
                ]), "analysis_id")
                evidence = unique_by(self._parse_scenario_table(wb, "Scenario_Evidence", [
                    "evidence_id", "review_id", "analysis_id", "publisher", "source_date_or_time",
                    "canonical_url", "supports_th", "timing_assessment"
                ]), "evidence_id")
                by_review = unique_by(daily, "review_id")
                daily_evidence: Dict[str, List[str]] = {}
                for item in evidence.values():
                    if not item or not by_review.get(item["review_id"]):
                        continue
                    daily_evidence.setdefault(item["review_id"], []).append(item["evidence_id"])

                joined: List[Dict[str, Any]] = []
                for day in daily:
                    if by_review.get(day["review_id"]) is not day:
                        continue
                    carry = day["decision"] == "CARRY_FORWARD"
                    candidate = analysis.get(day["carry_from_analysis_id"] if carry else day["analysis_id"])
                    origin = by_review.get(candidate["review_id"]) if candidate else None
                    valid_record = (
                        candidate and origin
                        and origin["zone_id"] == day["zone_id"]
                        and candidate["zone_id"] == day["zone_id"]
                        and origin["date_ict"] == candidate["date_ict"]
                        and origin["analysis_id"] == candidate["analysis_id"]
                        and origin["decision"] == "NEW_SCENARIO"
                        and (origin["date_ict"] < day["date_ict"] if carry else (day["decision"] == "NEW_SCENARIO" and origin["review_id"] == day["review_id"]))
                    )
                    record = candidate if valid_record else None
                    ids: List[str] = list(daily_evidence.get(day["review_id"], []))
                    if record:
                        for eid in re.split(r"[,;\s]+", record.get("evidence_ids", "")):
                            if eid and eid not in ids:
                                ids.append(eid)
                    sources: List[Dict[str, Any]] = []
                    for eid in ids:
                        item = evidence.get(eid)
                        source_day = by_review.get(item["review_id"]) if item else None
                        if (
                            not item or not source_day
                            or source_day["zone_id"] != day["zone_id"]
                            or source_day["date_ict"] > day["date_ict"]
                            or (item["review_id"] != day["review_id"] and (not record or source_day["date_ict"] > record["date_ict"]))
                            or (item["analysis_id"] and (not record or item["analysis_id"] != record["analysis_id"]))
                        ):
                            continue
                        sources.append({**item, "reviewed_on": source_day["date_ict"]})
                    joined.append({**day, "analysis": record, "evidence": sources})
                if joined:
                    return joined
            except Exception as e:
                print(f"[Parser Warning] Failed parsing Scenario_Daily tabs: {e}")

        # Find matching sheet name
        target_sheet_name = None
        for name in wb.sheetnames:
            clean = name.strip().lower()
            if clean in ('geo_scenarios', 'geoscenarios', 'scenarios', 'ภูมิรัฐศาสตร์', 'ภูมิรัฐศาสตร์_scenarios'):
                target_sheet_name = name
                break

        if not target_sheet_name:
            return DEFAULT_GEO_SCENARIOS

        try:
            ws = wb[target_sheet_name]
            if ws.max_row < 2:
                return DEFAULT_GEO_SCENARIOS

            # Find header row
            header_row_idx = 1
            for r in range(1, min(6, ws.max_row + 1)):
                row_vals = [str(ws.cell(row=r, column=c).value or '').lower() for c in range(1, ws.max_column + 1)]
                if any('id' in v or 'hotspot' in v or 'event' in v for v in row_vals):
                    header_row_idx = r
                    break

            headers = [str(ws.cell(row=header_row_idx, column=c).value or '').strip() for c in range(1, ws.max_column + 1)]
            
            # Normalize headers
            col_map = {}
            for idx, h in enumerate(headers):
                if not h:
                    continue
                h_clean = h.lower().replace(" ", "_").replace("-", "_")
                col_map[h_clean] = idx + 1

            def get_col_val(r_idx: int, *keys: str) -> str:
                for k in keys:
                    for col_key, col_num in col_map.items():
                        if k in col_key:
                            v = ws.cell(row=r_idx, column=col_num).value
                            if v is not None and str(v).strip() not in ('None', 'nan', ''):
                                return str(v).strip()
                return ""

            parsed_list = []
            for r in range(header_row_idx + 1, ws.max_row + 1):
                s_id = get_col_val(r, "hotspot_id", "id")
                if not s_id:
                    continue

                name = get_col_val(r, "hotspot_name", "name") or s_id
                region = get_col_val(r, "region") or "Global"
                severity_str = get_col_val(r, "severity", "level")
                try:
                    severity = int(float(severity_str)) if severity_str else 3
                except Exception:
                    severity = 3

                parsed_list.append({
                    "id": s_id.lower(),
                    "name": name,
                    "region": region,
                    "severity": severity,
                    "tension_level": get_col_val(r, "tension_level", "tension", "status") or "สถานการณ์ตึงเครียด",
                    "event_a": get_col_val(r, "event_a", "event", "headline"),
                    "energy_impact": get_col_val(r, "energy_impact", "energy"),
                    "inflation_impact": get_col_val(r, "inflation_impact", "inflation"),
                    "equities_impact": get_col_val(r, "equities_impact", "equities", "stock"),
                    "safe_haven_impact": get_col_val(r, "safe_haven_impact", "safe_haven", "safehaven", "gold"),
                    "action_cash_pct": get_col_val(r, "action_cash_pct", "cash") or "25%",
                    "action_portfolio": get_col_val(r, "action_portfolio", "portfolio"),
                    "action_hedge": get_col_val(r, "action_hedge", "hedge"),
                    "action_supply_chain": get_col_val(r, "action_supply_chain", "supply_chain", "supply"),
                    "action_crypto": get_col_val(r, "action_crypto", "crypto"),
                    "event_b": get_col_val(r, "event_b", "deescalation_event"),
                    "deescalation_impact": get_col_val(r, "deescalation_impact"),
                    "last_updated": get_col_val(r, "last_updated", "updated", "date") or dt.date.today().isoformat(),
                    "synced_from_sheet": True
                })

            if parsed_list:
                return parsed_list
            return DEFAULT_GEO_SCENARIOS
        except Exception as e:
            print(f"[Parser Warning] Failed parsing Geo_Scenarios tab: {e}. Using defaults.")
            return DEFAULT_GEO_SCENARIOS

    @staticmethod
    def _parse_datetime(pub_val: Any, date_val: Any) -> Optional[dt.datetime]:
        for val in (pub_val, date_val):
            if val is None or str(val).strip() in ('', 'None', 'nan'):
                continue
            if isinstance(val, (dt.datetime, dt.date)):
                if isinstance(val, dt.datetime):
                    return val
                return dt.datetime(val.year, val.month, val.day)
            try:
                parsed = pd.to_datetime(val, errors="coerce")
                if pd.notna(parsed):
                    return parsed.to_pydatetime()
            except Exception:
                pass
        return None
