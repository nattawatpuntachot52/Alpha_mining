import datetime as dt
import json
import os
import re
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from app.config import CACHE_DIR, DEFAULT_INTERVAL, DEFAULT_SYMBOL


class MarketDataProvider:
    """Range-aware Binance candles with request-local freshness metadata."""

    API_URL = "https://api.binance.com/api/v3/klines"
    CACHE_TTL_SECONDS = 60
    PAGE_LIMIT = 1000
    MAX_PAGES = 100
    INTERVAL_MS = {
        "1s": 1000, "1m": 60000, "3m": 180000, "5m": 300000,
        "15m": 900000, "30m": 1800000, "1h": 3600000, "2h": 7200000,
        "4h": 14400000, "6h": 21600000, "8h": 28800000,
        "12h": 43200000, "1d": 86400000, "3d": 259200000,
        "1w": 604800000,
    }

    def __init__(self, cache_dir: Optional[Path] = None):
        self.cache_dir = Path(cache_dir) if cache_dir else CACHE_DIR
        self._lock = threading.RLock()

    def get_klines(
        self, symbol: str = DEFAULT_SYMBOL, interval: str = DEFAULT_INTERVAL,
        start_ms: Optional[int] = None, end_ms: Optional[int] = None,
        force_fetch: bool = False,
    ) -> List[Dict[str, Any]]:
        """Preserve the original list interface for existing callers."""
        return self.get_klines_result(symbol, interval, start_ms, end_ms, force_fetch)["candles"]

    def get_klines_result(
        self, symbol: str = DEFAULT_SYMBOL, interval: str = DEFAULT_INTERVAL,
        start_ms: Optional[int] = None, end_ms: Optional[int] = None,
        force_fetch: bool = False,
    ) -> Dict[str, Any]:
        symbol = symbol.upper()
        if not re.fullmatch(r"[A-Z0-9]{1,30}", symbol):
            raise ValueError("Invalid trading symbol")
        if interval not in self.INTERVAL_MS and interval != "1M":
            raise ValueError("Unsupported candle interval")
        now_ms = int(time.time() * 1000)
        start_ms = int(start_ms) if start_ms is not None else int(
            dt.datetime(2026, 10, 8, tzinfo=dt.timezone.utc).timestamp() * 1000
        )
        end_ms = int(end_ms) if end_ms is not None else now_ms
        if start_ms < 0 or end_ms < start_ms:
            raise ValueError("start_ms and end_ms must define a non-negative ordered range")
        expected = self._expected_opens(start_ms, min(end_ms, now_ms), interval)

        with self._lock:
            cache_file = self.cache_dir / f"klines_{symbol}_{interval}.json"
            cached, unfinalized = self._read_cache(cache_file)
            cache_by_time = {c["time"]: c for c in cached}
            required = set(expected) if force_fetch else set(expected) - cache_by_time.keys()
            # Keep provisional candles tracked even when a later request appends
            # new data without including the old open tail in its own range.
            expected_set = set(expected)
            for candle_time, fetched_at in unfinalized.items():
                closed_at = self._next_open(candle_time, interval)
                if candle_time in expected_set and (not fetched_at or (
                    fetched_at < closed_at
                    and (now_ms >= closed_at or now_ms - fetched_at >= self.CACHE_TTL_SECONDS * 1000)
                )):
                    required.add(candle_time)

            ranges = []
            for candle_time in expected:
                if candle_time not in required:
                    continue
                if ranges and self._next_open(ranges[-1][1], interval) == candle_time:
                    ranges[-1][1] = candle_time
                else:
                    ranges.append([candle_time, candle_time])

            fetched = []
            errors = []
            pages_left = self.MAX_PAGES
            for range_start, range_end in ranges:
                if pages_left <= 0:
                    errors.append("Binance pagination request limit reached")
                    break
                batch, error, pages_used = self._fetch_from_binance(
                    symbol, interval, range_start, range_end, pages_left
                )
                fetched.extend(batch)
                pages_left -= pages_used
                if error:
                    errors.append(error)
                    break

            merged = self._normalize_candles(cached + fetched)
            cache_error = None
            if fetched:
                for value in fetched:
                    if self._next_open(value["time"], interval) > now_ms:
                        unfinalized[value["time"]] = now_ms
                    else:
                        unfinalized.pop(value["time"], None)
                try:
                    self._save_cache(cache_file, merged, now_ms, unfinalized)
                except OSError as exc:
                    cache_error = str(exc)
            candles = [c for c in merged if start_ms <= c["time"] <= min(end_ms, now_ms)]
            returned_times = {c["time"] for c in candles}
            complete = set(expected).issubset(returned_times)
            future_range = end_ms > now_ms
            fetched_times = {c["time"] for c in fetched}
            stale = bool(errors) or not complete or not required.issubset(fetched_times) or future_range
            if fetched:
                source = "binance+cache" if returned_times - fetched_times else "binance"
            else:
                source = "cache_fallback" if ranges and candles else "cache" if candles else "none"
            return {
                "candles": candles,
                "freshness": {
                    "source": source,
                    "status": "unavailable" if not candles else "stale" if stale else "fresh",
                    "stale": stale or not bool(candles),
                    "coverage_complete": complete and not future_range,
                    "requested_range": {"start_ms": start_ms, "end_ms": end_ms},
                    "returned_range": {
                        "start_ms": candles[0]["time"] if candles else None,
                        "end_ms": candles[-1]["time"] if candles else None,
                    },
                    "last_candle_time": candles[-1]["time"] if candles else None,
                    "as_of_ms": now_ms,
                    "cache_ttl_seconds": self.CACHE_TTL_SECONDS,
                    "fetch_error": "; ".join(errors) or None,
                    "cache_write_error": cache_error,
                },
            }

    @staticmethod
    def _normalize_candles(candles):
        normalized = {}
        for candle in candles:
            try:
                item = {"time": int(candle["time"])}
                item.update({key: float(candle[key]) for key in ("open", "high", "low", "close", "volume")})
                normalized[item["time"]] = item
            except (KeyError, TypeError, ValueError):
                continue
        return [normalized[key] for key in sorted(normalized)]

    def _read_cache(self, cache_file):
        try:
            with cache_file.open("r", encoding="utf-8") as handle:
                payload = json.load(handle)
            if isinstance(payload, list):
                candles = self._normalize_candles(payload)
                return candles, {candles[-1]["time"]: 0} if candles else {}
            if isinstance(payload, dict) and isinstance(payload.get("candles"), list):
                candles = self._normalize_candles(payload["candles"])
                if isinstance(payload.get("unfinalized"), dict):
                    pending = {int(key): value for key, value in payload["unfinalized"].items()
                               if isinstance(value, int)}
                else:
                    fetched_at = payload.get("last_candle_fetched_at_ms")
                    pending = {candles[-1]["time"]: fetched_at if isinstance(fetched_at, int) else 0} if candles else {}
                return candles, pending
        except (OSError, ValueError):
            pass
        return [], {}

    def _save_cache(self, cache_file, candles, fetched_at, unfinalized=None):
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        temporary_path = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=self.cache_dir, delete=False) as handle:
                temporary_path = Path(handle.name)
                pending = unfinalized if unfinalized is not None else {candles[-1]["time"]: fetched_at}
                json.dump({"version": 2, "candles": candles,
                           "unfinalized": pending}, handle, ensure_ascii=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_path, cache_file)
        finally:
            if temporary_path is not None and temporary_path.exists():
                temporary_path.unlink()

    def _floor_open(self, timestamp_ms, interval):
        if interval == "1M":
            value = dt.datetime.fromtimestamp(timestamp_ms / 1000, tz=dt.timezone.utc)
            return int(value.replace(day=1, hour=0, minute=0, second=0, microsecond=0).timestamp() * 1000)
        step = self.INTERVAL_MS[interval]
        offset = 4 * 86400000 if interval == "1w" else 0  # Monday UTC
        return ((timestamp_ms - offset) // step) * step + offset

    def _next_open(self, timestamp_ms, interval):
        if interval != "1M":
            return timestamp_ms + self.INTERVAL_MS[interval]
        value = dt.datetime.fromtimestamp(timestamp_ms / 1000, tz=dt.timezone.utc)
        year, month = (value.year + 1, 1) if value.month == 12 else (value.year, value.month + 1)
        return int(value.replace(year=year, month=month, day=1).timestamp() * 1000)

    def _expected_opens(self, start_ms, end_ms, interval):
        cursor = self._floor_open(start_ms, interval)
        if cursor < start_ms:
            cursor = self._next_open(cursor, interval)
        result = []
        while cursor <= end_ms:
            if len(result) >= self.MAX_PAGES * self.PAGE_LIMIT:
                raise ValueError("Requested candle range exceeds the pagination limit")
            result.append(cursor)
            cursor = self._next_open(cursor, interval)
        return result

    def _fetch_from_binance(self, symbol, interval, start_ms, end_ms, max_pages):
        results = []
        cursor = start_ms
        pages_used = 0
        try:
            while cursor <= end_ms and pages_used < max_pages:
                pages_used += 1
                response = requests.get(self.API_URL, params={
                    "symbol": symbol, "interval": interval, "startTime": cursor,
                    "endTime": end_ms, "limit": self.PAGE_LIMIT,
                }, timeout=12)
                response.raise_for_status()
                raw = response.json()
                if not isinstance(raw, list):
                    raise ValueError("Invalid Binance candle response")
                if not raw:
                    break
                page = self._normalize_candles([
                    {"time": c[0], "open": c[1], "high": c[2],
                     "low": c[3], "close": c[4], "volume": c[5]} for c in raw
                ])
                bounded = [c for c in page if cursor <= c["time"] <= end_ms]
                if not bounded:
                    raise ValueError("Binance pagination did not advance")
                results.extend(bounded)
                cursor = self._next_open(bounded[-1]["time"], interval)
                if len(raw) < self.PAGE_LIMIT:
                    break
            if cursor <= end_ms and pages_used >= max_pages:
                return results, "Binance pagination request limit reached", pages_used
            return results, None, pages_used
        except (requests.RequestException, ValueError, TypeError, KeyError, IndexError) as exc:
            return results, str(exc), pages_used


market_data = MarketDataProvider()
