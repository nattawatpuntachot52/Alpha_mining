import asyncio
import threading
import os
import time
import datetime as dt
from pathlib import Path
from typing import Dict, Any, Optional
from app.config import EXCEL_PATH, REALTIME_SYNC_INTERVAL_SECONDS
from app.parser import FactnewsParser

class FactnewsWatcher:
    """
    Real-time synchronization engine for Factnews.
    Pulls live news updates from Google Sheets every 60 seconds (or on-demand),
    tracks updates, and caches data in-memory.
    """

    def __init__(self, excel_path: Optional[Path] = None):
        self.excel_path = Path(excel_path) if excel_path else EXCEL_PATH
        self.parser = FactnewsParser(self.excel_path)
        self._cached_data: Optional[Dict[str, Any]] = None
        self._last_sync_time: Optional[dt.datetime] = None
        self._last_event_count: int = 0
        self._is_running: bool = False
        self._sync_count: int = 0
        self._last_error: Optional[str] = None
        self._sync_lock = threading.Lock()
        self._sync_task: Optional[asyncio.Task] = None

    def get_data(self) -> Dict[str, Any]:
        """Returns cached data, refreshing if not yet loaded."""
        if self._cached_data is None:
            self.sync_now()
        return self._cached_data or {}

    def sync_now(self, prefer_live: bool = True) -> Dict[str, Any]:
        """Forced instant sync; synchronous callers also serialize parser access."""
        with self._sync_lock:
            try:
                data = self.parser.parse(prefer_live=prefer_live)
                current_count = data.get("total_count", 0)

                self._last_sync_time = dt.datetime.now()
                self._sync_count += 1
                freshness = data.get("freshness", {})
                self._last_error = freshness.get("fetch_error") or freshness.get("cache_write_error")
                self._cached_data = data
                self._last_event_count = current_count
                return data
            except Exception as e:
                self._last_error = str(e)
                print(f"[Watcher Error] Sync failed: {e}")
                if self._cached_data:
                    return self._cached_data
                raise

    async def sync_async(self, prefer_live: bool = True) -> Dict[str, Any]:
        """Offload sync work and share the current sync with concurrent callers."""
        if self._sync_task is None or self._sync_task.done():
            self._sync_task = asyncio.create_task(
                asyncio.to_thread(self.sync_now, prefer_live=prefer_live)
            )
        task = self._sync_task
        try:
            # A cancelled request must not cancel work shared with other callers.
            return await asyncio.shield(task)
        except asyncio.CancelledError:
            # Threads cannot be stopped mid-parse. Drain this one before closing
            # its caller so shutdown never leaves an orphaned sync task behind.
            try:
                await asyncio.shield(task)
            except Exception:
                pass
            raise

    async def start_background_watcher(self, check_interval_seconds: int = REALTIME_SYNC_INTERVAL_SECONDS):
        """Poll after each interval; lifespan owns the single initial sync."""
        self._is_running = True
        try:
            while self._is_running:
                await asyncio.sleep(check_interval_seconds)
                if not self._is_running:
                    break
                try:
                    await self.sync_async(prefer_live=True)
                except Exception as e:
                    print(f"[Watcher Realtime Polling Error]: {e}")
        finally:
            self._is_running = False

    def stop(self):
        self._is_running = False

    def get_status(self) -> Dict[str, Any]:
        freshness = (self._cached_data or {}).get("freshness", {})
        warning = (self._last_error is not None or freshness.get("stale", False)
                   or freshness.get("status") in {"stale", "degraded"})
        return {
            "source": self.parser.last_fetch_source,
            "sync_count": self._sync_count,
            "reload_count": self._sync_count,
            "file_exists": self.excel_path.exists(),
            "total_events": self._last_event_count,
            "last_sync_time": self._last_sync_time.strftime("%Y-%m-%d %H:%M:%S") if self._last_sync_time else None,
            "sync_interval_seconds": REALTIME_SYNC_INTERVAL_SECONDS,
            "status": "warning" if warning else "online",
            "last_error": self._last_error,
            "is_syncing": self._sync_task is not None and not self._sync_task.done(),
            "freshness": freshness
        }

# Global singleton
watcher = FactnewsWatcher()
