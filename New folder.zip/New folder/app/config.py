import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

EXCEL_FILENAME = "Factnews — ข่าวอัปเดต 60 นาที.xlsx"
EXCEL_PATH = BASE_DIR / EXCEL_FILENAME

STATIC_DIR = BASE_DIR / "static"
CACHE_DIR = BASE_DIR / "data"

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 8000

# Google Sheets Realtime Configuration
GOOGLE_SPREADSHEET_ID = "1JOknhrZ5PPLsOOIIS55sfaUiRAsCvYdy3tFLr1H7CG8"
GOOGLE_SHEET_GID = "83454173"  # คริปโต tab gid
GOOGLE_SHEET_XLSX_URL = f"https://docs.google.com/spreadsheets/d/{GOOGLE_SPREADSHEET_ID}/export?format=xlsx"
GOOGLE_SHEET_EDIT_URL = f"https://docs.google.com/spreadsheets/d/{GOOGLE_SPREADSHEET_ID}/edit?gid={GOOGLE_SHEET_GID}#gid={GOOGLE_SHEET_GID}"

# Realtime sync interval (e.g. 60 seconds)
REALTIME_SYNC_INTERVAL_SECONDS = 60

# Market data defaults
DEFAULT_SYMBOL = "BTCUSDT"
DEFAULT_INTERVAL = "1h"
