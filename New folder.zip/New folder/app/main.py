import asyncio
from contextlib import asynccontextmanager, suppress
from typing import Optional
from fastapi import FastAPI, Query, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from app.config import STATIC_DIR, DEFAULT_SYMBOL, DEFAULT_INTERVAL, REALTIME_SYNC_INTERVAL_SECONDS
from app.watcher import watcher
from app.market_data import market_data

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: initial sync from Google Sheets and start background polling
    await watcher.sync_async(prefer_live=True)
    watcher_task = asyncio.create_task(watcher.start_background_watcher(check_interval_seconds=REALTIME_SYNC_INTERVAL_SECONDS))
    try:
        yield
    finally:
        # Await cancellation, including any blocking sync already in progress.
        watcher.stop()
        watcher_task.cancel()
        with suppress(asyncio.CancelledError):
            await watcher_task

app = FastAPI(
    title="WRITE TIME — Event Radar (Realtime)",
    description="Real-time news radar powered live by WRITE TIME Intelligence and Binance API",
    version="2.1.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/status")
async def get_status():
    """Returns real-time sync status and health metrics."""
    return watcher.get_status()

@app.get("/api/events")
async def get_events():
    """Returns all current news events, categories, and sync metadata."""
    try:
        data = watcher.get_data()
        return JSONResponse(content=data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/sync")
@app.post("/api/refresh")
async def trigger_sync():
    """Manually forces an instant real-time sync with news feed."""
    try:
        data = await watcher.sync_async(prefer_live=True)
        return {
            "status": "success",
            "message": "Data successfully synchronized live",
            "source": data.get("source", "Live Realtime Feed"),
            "total_count": data.get("total_count", 0),
            "last_sync_time": data.get("last_sync_time")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Sync failed: {e}")

@app.get("/api/prices")
async def get_prices(
    symbol: str = Query(DEFAULT_SYMBOL, description="Trading pair symbol e.g. BTCUSDT, ETHUSDT"),
    interval: str = Query(DEFAULT_INTERVAL, description="Kline interval e.g. 1h, 4h, 1d"),
    start_ms: Optional[int] = Query(None, description="Start timestamp in milliseconds"),
    end_ms: Optional[int] = Query(None, description="End timestamp in milliseconds")
):
    """Returns market price candles (e.g. BTCUSDT) for overlay on the timeline."""
    try:
        result = market_data.get_klines_result(symbol, interval, start_ms, end_ms)
        klines = result["candles"]
        return {
            "symbol": symbol.upper(),
            "interval": interval,
            "count": len(klines),
            "candles": klines,
            "freshness": result["freshness"]
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch market data: {e}")

# Mount Static Files
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

@app.get("/")
async def serve_index():
    index_path = STATIC_DIR / "index.html"
    if index_path.exists():
        return FileResponse(index_path)
    return {"message": "Factnews Event Radar API running. index.html not found yet."}
