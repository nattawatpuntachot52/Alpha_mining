import sys
import uvicorn

# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

from app.config import SERVER_HOST, SERVER_PORT

if __name__ == "__main__":
    print(f"[*] Starting Factnews Event Radar 2.0 on http://{SERVER_HOST}:{SERVER_PORT}")
    print(f"[*] Watching Excel file: Factnews — ข่าวอัปเดต 60 นาที.xlsx")
    print(f"[*] Open your browser and navigate to: http://localhost:{SERVER_PORT}")
    uvicorn.run("app.main:app", host=SERVER_HOST, port=SERVER_PORT, reload=False)
