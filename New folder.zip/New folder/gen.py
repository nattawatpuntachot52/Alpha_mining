# Prototype generator script
import json, os

artifact_dir = r'C:\Users\admin\.gemini\antigravity\brain\a8ea452c-ad6b-4a73-9204-892b7273b394'
os.makedirs(artifact_dir, exist_ok=True)
output_html_path = os.path.join(artifact_dir, 'factnews_dashboard_prototype.html')

with open('parsed_factnews.json', 'r', encoding='utf-8') as f:
    events = json.load(f)

print(f'Loaded {len(events)} events')
